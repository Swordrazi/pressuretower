Array.prototype.__yy_owner = 0; 
var JSON_game = {
	Extensions: [],
	ExtensionOptions:{
	},
	Sounds: [
	],
	AudioGroups: [
	    {
		name:"audiogroup_default",
		enabled: true,
	    }	],
	Sprites: [
	    {
		pName: "spr_button",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
 bboxRight: 63, bboxBottom: 63, playbackspeed:0,		TPEntryIndex: [ 26, 27],
sequence: {
			pName: "spr_button",
			playback: 1,
			playbackSpeed: 0,
			playbackSpeedType: 0,
			length: 2,
			xorigin: 0,
			yorigin: 0,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
,
{
key: 1,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 1
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
,
nineslice: {
	nLeft: 4,
	nTop: 4,
	nRight: 4,
	nBottom: 4,
	nEnabled: true,
	nTilemode: [
0,
0,
0,
0,
0
	]
}
	    },
	    {
		pName: "spr_gear",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
		xOrigin: 32,yOrigin: 32,
		bboxLeft: 4, bboxRight: 59, bboxTop: 4, bboxBottom: 59, playbackspeed:30,		TPEntryIndex: [ 50],
sequence: {
			pName: "spr_gear",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 32,
			yorigin: 32,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_crushed_paper",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
		xOrigin: 32,yOrigin: 32,
		bboxLeft: 4, bboxRight: 51, bboxTop: 12, bboxBottom: 63, playbackspeed:30,		TPEntryIndex: [ 53],
sequence: {
			pName: "spr_crushed_paper",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 32,
			yorigin: 32,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_ScrapBin",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
 bboxRight: 63, bboxBottom: 63, playbackspeed:30,		TPEntryIndex: [ 28],
sequence: {
			pName: "spr_ScrapBin",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 0,
			yorigin: 0,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_wood",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
		xOrigin: 32,yOrigin: 32,
 bboxRight: 63, bboxBottom: 63, playbackspeed:30,		TPEntryIndex: [ 40],
sequence: {
			pName: "spr_wood",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 32,
			yorigin: 32,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_paper",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
		xOrigin: 32,yOrigin: 32,
		bboxLeft: 4, bboxRight: 63, bboxTop: 20, bboxBottom: 63, playbackspeed:30,		TPEntryIndex: [ 52],
sequence: {
			pName: "spr_paper",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 32,
			yorigin: 32,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_storage_gears",
		width: 64, height: 64,
 bboxMode: 2,
		transparent: false,
		smooth: false,
		preload: false,
		bboxLeft: 12, bboxRight: 51, bboxTop: 12, bboxBottom: 51, playbackspeed:30,		TPEntryIndex: [ 39],
sequence: {
			pName: "spr_storage_gears",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 0,
			yorigin: 0,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
,
nineslice: {
	nLeft: 12,
	nTop: 12,
	nRight: 12,
	nBottom: 12,
	nEnabled: true,
	nTilemode: [
0,
0,
0,
0,
1
	]
}
	    },
	    {
		pName: "spr_arrow",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
		xOrigin: 32,yOrigin: 32,
		bboxLeft: 4, bboxRight: 59, bboxTop: 4, bboxBottom: 59, playbackspeed:30,		TPEntryIndex: [ 49],
sequence: {
			pName: "spr_arrow",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 32,
			yorigin: 32,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_pressurizer_pipe",
		width: 128, height: 128,
		transparent: false,
		smooth: false,
		preload: false,
		xOrigin: 64,yOrigin: 64,
		bboxLeft: 24, bboxRight: 103, bboxBottom: 127, playbackspeed:30,		TPEntryIndex: [ 17],
sequence: {
			pName: "spr_pressurizer_pipe",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 64,
			yorigin: 64,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_bg_sorter",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
 bboxRight: 63, bboxBottom: 63, playbackspeed:30,		TPEntryIndex: [ 25],
sequence: {
			pName: "spr_bg_sorter",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 0,
			yorigin: 0,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "o_Placeholder",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
 bboxRight: 63, bboxBottom: 63, playbackspeed:30,		TPEntryIndex: [ 18],
sequence: {
			pName: "o_Placeholder",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 0,
			yorigin: 0,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_bg_factory",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
 bboxRight: 63, bboxBottom: 63, playbackspeed:30,		TPEntryIndex: [ 23],
sequence: {
			pName: "spr_bg_factory",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 0,
			yorigin: 0,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_crushed_wood",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
		xOrigin: 32,yOrigin: 32,
 bboxRight: 63, bboxTop: 40, bboxBottom: 63, playbackspeed:30,		TPEntryIndex: [ 62],
sequence: {
			pName: "spr_crushed_wood",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 32,
			yorigin: 32,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_Sorter",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
		xOrigin: 32,yOrigin: 32,
 bboxRight: 63, bboxBottom: 63, playbackspeed:0,		TPEntryIndex: [ 30, 29, 34, 33, 37, 31, 32, 35, 38, 36],
sequence: {
			pName: "spr_Sorter",
			playback: 1,
			playbackSpeed: 0,
			playbackSpeedType: 0,
			length: 10,
			xorigin: 32,
			yorigin: 32,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
,
{
key: 1,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 1
}
}
}
,
{
key: 2,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 2
}
}
}
,
{
key: 3,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 3
}
}
}
,
{
key: 4,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 4
}
}
}
,
{
key: 5,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 5
}
}
}
,
{
key: 6,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 6
}
}
}
,
{
key: 7,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 7
}
}
}
,
{
key: 8,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 8
}
}
}
,
{
key: 9,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 9
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_bg_crusher",
		width: 64, height: 160,
		transparent: false,
		smooth: false,
		preload: false,
 bboxRight: 63, bboxBottom: 159, playbackspeed:10,		TPEntryIndex: [ 7, 12, 5, 9, 15, 16, 6, 10, 13, 11, 14, 8],
sequence: {
			pName: "spr_bg_crusher",
			playback: 1,
			playbackSpeed: 10,
			playbackSpeedType: 0,
			length: 12,
			xorigin: 0,
			yorigin: 0,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
,
{
key: 1,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 1
}
}
}
,
{
key: 2,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 2
}
}
}
,
{
key: 3,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 3
}
}
}
,
{
key: 4,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 4
}
}
}
,
{
key: 5,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 5
}
}
}
,
{
key: 6,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 6
}
}
}
,
{
key: 7,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 7
}
}
}
,
{
key: 8,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 8
}
}
}
,
{
key: 9,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 9
}
}
}
,
{
key: 10,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 10
}
}
}
,
{
key: 11,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 11
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_pressurizer",
		width: 128, height: 128,
		transparent: false,
		smooth: false,
		preload: false,
		xOrigin: 64,yOrigin: 64,
 bboxRight: 127, bboxBottom: 127, playbackspeed:30,		TPEntryIndex: [ 4],
sequence: {
			pName: "spr_pressurizer",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 64,
			yorigin: 64,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_bg_conveyorbelt",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
 bboxRight: 63, bboxTop: 40, bboxBottom: 63, playbackspeed:10,		TPEntryIndex: [ 57, 56, 55, 58, 61, 54, 59, 60],
sequence: {
			pName: "spr_bg_conveyorbelt",
			playback: 1,
			playbackSpeed: 10,
			playbackSpeedType: 0,
			length: 8,
			xorigin: 0,
			yorigin: 0,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
,
{
key: 1,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 1
}
}
}
,
{
key: 2,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 2
}
}
}
,
{
key: 3,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 3
}
}
}
,
{
key: 4,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 4
}
}
}
,
{
key: 5,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 5
}
}
}
,
{
key: 6,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 6
}
}
}
,
{
key: 7,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 7
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_bg_gearing",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
 bboxRight: 63, bboxBottom: 63, playbackspeed:30,		TPEntryIndex: [ 24],
sequence: {
			pName: "spr_bg_gearing",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 0,
			yorigin: 0,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    },
	    {
		pName: "spr_bg_pipethingy",
		width: 64, height: 64,
		transparent: false,
		smooth: false,
		preload: false,
		bboxLeft: 8, bboxRight: 55, bboxBottom: 63, playbackspeed:30,		TPEntryIndex: [ 51],
sequence: {
			pName: "spr_bg_pipethingy",
			playback: 1,
			playbackSpeed: 30,
			playbackSpeedType: 0,
			length: 1,
			xorigin: 0,
			yorigin: 0,
			volume: 1,
keyframeStore: [
]
,
			tracks: [
				{
	modelName: "GMSpriteFramesTrack",
	pName: "frames",
	builtinName: 0,
	traits: 0,
	creationTrack: 0,
	tags: [
	],
	ownedResourceModels: [
	],
	tracks: [
	]
,
keyframeStore: [
{
key: 0,
length: 1,
stretch: false,
disabled: false,
channels: {
0:
{
imageIndex: 0
}
}
}
]
				}
			],
		sequenceEvents: [
		]
,
momentsKeystore: [
]
}
	    }	],
	EmbeddedEntries: {"fallbacktexture" : 0, "pt_shape_circle" : 41, "pt_shape_cloud" : 48, "pt_shape_disk" : 42, "pt_shape_explosion" : 19, "pt_shape_flare" : 20, "pt_shape_line" : 63, "pt_shape_pixel" : 64, "pt_shape_ring" : 43, "pt_shape_smoke" : 21, "pt_shape_snow" : 45, "pt_shape_spark" : 22, "pt_shape_sphere" : 46, "pt_shape_square" : 44, "pt_shape_star" : 47, "FONT_builtin" : 3},
	Backgrounds: [
	],
	Paths: [
	],
	Shaders: [
		{
			 name:"__yy_sdf_shader",


			 Vertex:"#define LOWPREC lowp\n#define	MATRIX_VIEW 					0\n#define	MATRIX_PROJECTION 				1\n#define	MATRIX_WORLD 					2\n#define	MATRIX_WORLD_VIEW 				3\n#define	MATRIX_WORLD_VIEW_PROJECTION 	4\n#define	MATRICES_MAX					5\n\nuniform mat4 gm_Matrices[MATRICES_MAX]; \n\nuniform bool gm_LightingEnabled;\nuniform bool gm_VS_FogEnabled;\nuniform float gm_FogStart;\nuniform float gm_RcpFogRange;\n\n#define MAX_VS_LIGHTS	8\n#define MIRROR_WIN32_LIGHTING_EQUATION\n\n\n//#define	MAX_VS_LIGHTS					8\nuniform vec4   gm_AmbientColour;							// rgb=colour, a=1\nuniform vec4   gm_Lights_Direction[MAX_VS_LIGHTS];		// normalised direction\nuniform vec4   gm_Lights_PosRange[MAX_VS_LIGHTS];			// X,Y,Z position,  W range\nuniform vec4   gm_Lights_Colour[MAX_VS_LIGHTS];			// rgb=colour, a=1\n\nfloat CalcFogFactor(vec4 pos)\n{\n	if (gm_VS_FogEnabled)\n	{\n		vec4 viewpos = gm_Matrices[MATRIX_WORLD_VIEW] * pos;\n		float fogfactor = ((viewpos.z - gm_FogStart) * gm_RcpFogRange);\n		return fogfactor;\n	}\n	else\n	{\n		return 0.0;\n	}\n}\n\nvec4 DoDirLight(vec3 ws_normal, vec4 dir, vec4 diffusecol)\n{\n	float dotresult = dot(ws_normal, dir.xyz);\n	dotresult = min(dotresult, dir.w);			// the w component is 1 if the directional light is active, or 0 if it isn't\n	dotresult = max(0.0, dotresult);\n\n	return dotresult * diffusecol;\n}\n\nvec4 DoPointLight(vec3 ws_pos, vec3 ws_normal, vec4 posrange, vec4 diffusecol)\n{\n	vec3 diffvec = ws_pos - posrange.xyz;\n	float veclen = length(diffvec);\n	diffvec /= veclen;	// normalise\n	float atten;\n	if (posrange.w == 0.0)		// the w component of posrange is 0 if the point light is disabled - if we don't catch it here we might end up generating INFs or NaNs\n	{\n		atten = 0.0;\n	}\n	else\n	{\n#ifdef MIRROR_WIN32_LIGHTING_EQUATION\n	// This is based on the Win32 D3D and OpenGL falloff model, where:\n	// Attenuation = 1.0f / (factor0 + (d * factor1) + (d*d * factor2))\n	// For some reason, factor0 is set to 0.0f while factor1 is set to 1.0f/lightrange (on both D3D and OpenGL)\n	// This'll result in no visible falloff as 1.0f / (d / lightrange) will always be larger than 1.0f (if the vertex is within range)\n	\n		atten = 1.0 / (veclen / posrange.w);\n		if (veclen > posrange.w)\n		{\n			atten = 0.0;\n		}	\n#else\n		atten = clamp( (1.0 - (veclen / posrange.w)), 0.0, 1.0);		// storing 1.0f/range instead would save a rcp\n#endif\n	}\n	float dotresult = dot(ws_normal, diffvec);\n	dotresult = max(0.0, dotresult);\n\n	return dotresult * atten * diffusecol;\n}\n\nvec4 DoLighting(vec4 vertexcolour, vec4 objectspacepos, vec3 objectspacenormal)\n{\n	if (gm_LightingEnabled)\n	{\n		// Normally we'd have the light positions\\directions back-transformed from world to object space\n		// But to keep things simple for the moment we'll just transform the normal to world space\n		vec4 objectspacenormal4 = vec4(objectspacenormal, 0.0);\n		vec3 ws_normal;\n		ws_normal = (gm_Matrices[MATRIX_WORLD] * objectspacenormal4).xyz;\n		ws_normal = normalize(ws_normal);\n\n		vec3 ws_pos;\n		ws_pos = (gm_Matrices[MATRIX_WORLD] * objectspacepos).xyz;\n\n		// Accumulate lighting from different light types\n		vec4 accumcol = vec4(0.0, 0.0, 0.0, 0.0);		\n		for(int i = 0; i < MAX_VS_LIGHTS; i++)\n		{\n			accumcol += DoDirLight(ws_normal, gm_Lights_Direction[i], gm_Lights_Colour[i]);\n		}\n\n		for(int i = 0; i < MAX_VS_LIGHTS; i++)\n		{\n			accumcol += DoPointLight(ws_pos, ws_normal, gm_Lights_PosRange[i], gm_Lights_Colour[i]);\n		}\n\n		accumcol *= vertexcolour;\n		accumcol += gm_AmbientColour;\n		accumcol = min(vec4(1.0, 1.0, 1.0, 1.0), accumcol);\n		accumcol.a = vertexcolour.a;\n		return accumcol;\n	}\n	else\n	{\n		return vertexcolour;\n	}\n}\n\n#define _YY_GLSLES_ 1\n//\n// SDF vertex shader\n//\nattribute vec3 in_Position;                  // (x,y,z)\n//attribute vec3 in_Normal;                  // (x,y,z)     unused in this shader.\nattribute vec4 in_Colour;                    // (r,g,b,a)\nattribute vec2 in_TextureCoord;              // (u,v)\n\nvarying vec2 v_vTexcoord;\nvarying vec4 v_vColour;\n\nvoid main()\n{\n    vec4 object_space_pos = vec4( in_Position.x, in_Position.y, in_Position.z, 1.0);\n    gl_Position = gm_Matrices[MATRIX_WORLD_VIEW_PROJECTION] * object_space_pos;\n    \n    v_vColour = in_Colour;\n    v_vTexcoord = in_TextureCoord;\n}\n",


			 Fragment:"precision mediump float;\n#define LOWPREC lowp\n// Uniforms look like they're shared between vertex and fragment shaders in GLSL, so we have to be careful to avoid name clashes\n\nuniform sampler2D gm_BaseTexture;\n\nuniform bool gm_PS_FogEnabled;\nuniform vec4 gm_FogColour;\nuniform bool gm_AlphaTestEnabled;\nuniform float gm_AlphaRefValue;\n\nvoid DoAlphaTest(vec4 SrcColour)\n{\n	if (gm_AlphaTestEnabled)\n	{\n		if (SrcColour.a <= gm_AlphaRefValue)\n		{\n			discard;\n		}\n	}\n}\n\nvoid DoFog(inout vec4 SrcColour, float fogval)\n{\n	if (gm_PS_FogEnabled)\n	{\n		SrcColour = mix(SrcColour, gm_FogColour, clamp(fogval, 0.0, 1.0)); \n	}\n}\n\n#define _YY_GLSLES_ 1\n//\n// SDF fragment shader\n//\nvarying vec2 v_vTexcoord;\nvarying vec4 v_vColour;\n\nvoid main()\n{\n	vec4 texcol = texture2D( gm_BaseTexture, v_vTexcoord );\n	\n	float spread = fwidth(texcol.a);	\n	spread = max(spread * 0.75, 0.001);	\n	texcol.a = smoothstep(0.5 - spread, 0.5 + spread, texcol.a);			\n	\n	vec4 combinedcol = v_vColour * texcol;\n	DoAlphaTest(combinedcol);	\n			\n    gl_FragColor = combinedcol;\n}\n",


			 Attributes:["in_Position","in_Colour","in_TextureCoord"]
		}
,
		{
			 name:"__yy_sdf_effect_shader",


			 Vertex:"#define LOWPREC lowp\n#define	MATRIX_VIEW 					0\n#define	MATRIX_PROJECTION 				1\n#define	MATRIX_WORLD 					2\n#define	MATRIX_WORLD_VIEW 				3\n#define	MATRIX_WORLD_VIEW_PROJECTION 	4\n#define	MATRICES_MAX					5\n\nuniform mat4 gm_Matrices[MATRICES_MAX]; \n\nuniform bool gm_LightingEnabled;\nuniform bool gm_VS_FogEnabled;\nuniform float gm_FogStart;\nuniform float gm_RcpFogRange;\n\n#define MAX_VS_LIGHTS	8\n#define MIRROR_WIN32_LIGHTING_EQUATION\n\n\n//#define	MAX_VS_LIGHTS					8\nuniform vec4   gm_AmbientColour;							// rgb=colour, a=1\nuniform vec4   gm_Lights_Direction[MAX_VS_LIGHTS];		// normalised direction\nuniform vec4   gm_Lights_PosRange[MAX_VS_LIGHTS];			// X,Y,Z position,  W range\nuniform vec4   gm_Lights_Colour[MAX_VS_LIGHTS];			// rgb=colour, a=1\n\nfloat CalcFogFactor(vec4 pos)\n{\n	if (gm_VS_FogEnabled)\n	{\n		vec4 viewpos = gm_Matrices[MATRIX_WORLD_VIEW] * pos;\n		float fogfactor = ((viewpos.z - gm_FogStart) * gm_RcpFogRange);\n		return fogfactor;\n	}\n	else\n	{\n		return 0.0;\n	}\n}\n\nvec4 DoDirLight(vec3 ws_normal, vec4 dir, vec4 diffusecol)\n{\n	float dotresult = dot(ws_normal, dir.xyz);\n	dotresult = min(dotresult, dir.w);			// the w component is 1 if the directional light is active, or 0 if it isn't\n	dotresult = max(0.0, dotresult);\n\n	return dotresult * diffusecol;\n}\n\nvec4 DoPointLight(vec3 ws_pos, vec3 ws_normal, vec4 posrange, vec4 diffusecol)\n{\n	vec3 diffvec = ws_pos - posrange.xyz;\n	float veclen = length(diffvec);\n	diffvec /= veclen;	// normalise\n	float atten;\n	if (posrange.w == 0.0)		// the w component of posrange is 0 if the point light is disabled - if we don't catch it here we might end up generating INFs or NaNs\n	{\n		atten = 0.0;\n	}\n	else\n	{\n#ifdef MIRROR_WIN32_LIGHTING_EQUATION\n	// This is based on the Win32 D3D and OpenGL falloff model, where:\n	// Attenuation = 1.0f / (factor0 + (d * factor1) + (d*d * factor2))\n	// For some reason, factor0 is set to 0.0f while factor1 is set to 1.0f/lightrange (on both D3D and OpenGL)\n	// This'll result in no visible falloff as 1.0f / (d / lightrange) will always be larger than 1.0f (if the vertex is within range)\n	\n		atten = 1.0 / (veclen / posrange.w);\n		if (veclen > posrange.w)\n		{\n			atten = 0.0;\n		}	\n#else\n		atten = clamp( (1.0 - (veclen / posrange.w)), 0.0, 1.0);		// storing 1.0f/range instead would save a rcp\n#endif\n	}\n	float dotresult = dot(ws_normal, diffvec);\n	dotresult = max(0.0, dotresult);\n\n	return dotresult * atten * diffusecol;\n}\n\nvec4 DoLighting(vec4 vertexcolour, vec4 objectspacepos, vec3 objectspacenormal)\n{\n	if (gm_LightingEnabled)\n	{\n		// Normally we'd have the light positions\\directions back-transformed from world to object space\n		// But to keep things simple for the moment we'll just transform the normal to world space\n		vec4 objectspacenormal4 = vec4(objectspacenormal, 0.0);\n		vec3 ws_normal;\n		ws_normal = (gm_Matrices[MATRIX_WORLD] * objectspacenormal4).xyz;\n		ws_normal = normalize(ws_normal);\n\n		vec3 ws_pos;\n		ws_pos = (gm_Matrices[MATRIX_WORLD] * objectspacepos).xyz;\n\n		// Accumulate lighting from different light types\n		vec4 accumcol = vec4(0.0, 0.0, 0.0, 0.0);		\n		for(int i = 0; i < MAX_VS_LIGHTS; i++)\n		{\n			accumcol += DoDirLight(ws_normal, gm_Lights_Direction[i], gm_Lights_Colour[i]);\n		}\n\n		for(int i = 0; i < MAX_VS_LIGHTS; i++)\n		{\n			accumcol += DoPointLight(ws_pos, ws_normal, gm_Lights_PosRange[i], gm_Lights_Colour[i]);\n		}\n\n		accumcol *= vertexcolour;\n		accumcol += gm_AmbientColour;\n		accumcol = min(vec4(1.0, 1.0, 1.0, 1.0), accumcol);\n		accumcol.a = vertexcolour.a;\n		return accumcol;\n	}\n	else\n	{\n		return vertexcolour;\n	}\n}\n\n#define _YY_GLSLES_ 1\n//\n// Simple passthrough vertex shader\n//\nattribute vec3 in_Position;                  // (x,y,z)\n//attribute vec3 in_Normal;                  // (x,y,z)     unused in this shader.\nattribute vec4 in_Colour;                    // (r,g,b,a)\nattribute vec2 in_TextureCoord;              // (u,v)\n\nvarying vec2 v_vTexcoord;\nvarying vec4 v_vColour;\n\nvoid main()\n{\n    vec4 object_space_pos = vec4( in_Position.x, in_Position.y, in_Position.z, 1.0);\n    gl_Position = gm_Matrices[MATRIX_WORLD_VIEW_PROJECTION] * object_space_pos;\n    \n    v_vColour = in_Colour;\n    v_vTexcoord = in_TextureCoord;\n}\n",


			 Fragment:"precision mediump float;\n#define LOWPREC lowp\n// Uniforms look like they're shared between vertex and fragment shaders in GLSL, so we have to be careful to avoid name clashes\n\nuniform sampler2D gm_BaseTexture;\n\nuniform bool gm_PS_FogEnabled;\nuniform vec4 gm_FogColour;\nuniform bool gm_AlphaTestEnabled;\nuniform float gm_AlphaRefValue;\n\nvoid DoAlphaTest(vec4 SrcColour)\n{\n	if (gm_AlphaTestEnabled)\n	{\n		if (SrcColour.a <= gm_AlphaRefValue)\n		{\n			discard;\n		}\n	}\n}\n\nvoid DoFog(inout vec4 SrcColour, float fogval)\n{\n	if (gm_PS_FogEnabled)\n	{\n		SrcColour = mix(SrcColour, gm_FogColour, clamp(fogval, 0.0, 1.0)); \n	}\n}\n\n#define _YY_GLSLES_ 1\n//\n// SDF (with effects) fragment shader\n//\nvarying vec2 v_vTexcoord;\nvarying vec4 v_vColour;\n\n// SDF values are measured from 0 (at the outer edge) to 1 which is the innermost point that can be represented\nuniform bool gm_SDF_DrawGlow;				// whether the glow effect is enabled\nuniform vec2 gm_SDF_Glow_MinMax;			// the SDF range across which the glow fades\nuniform vec4 gm_SDF_Glow_Col;				// the colour of the glow\n\nuniform bool gm_SDF_DrawOutline;			// whether the outline effect is enabled\nuniform float gm_SDF_Outline_Thresh;		// the SDF distance which represents the outer edge of the outline\nuniform vec4 gm_SDF_Outline_Col;			// the colour of the outline\n\nuniform float gm_SDF_Core_Thresh;			// the SDF distance which represents the outer edge the shape\nuniform vec4 gm_SDF_Core_Col;				// the colour of the core part of the shape\n\nvoid main()\n{\n	vec4 texcol = texture2D( gm_BaseTexture, v_vTexcoord );\n		\n	float pixelspread = fwidth(texcol.a);	\n	pixelspread = max(pixelspread * 0.75, 0.001);	\n	\n	float blendfactor;\n	vec4 currcol = vec4(0.0, 0.0, 0.0, -1.0);\n	\n	// Handle glow effect\n	if (gm_SDF_DrawGlow)\n	{		\n		if (texcol.a > gm_SDF_Glow_MinMax.x)\n		{\n			currcol = gm_SDF_Glow_Col;\n			currcol.a *= smoothstep(gm_SDF_Glow_MinMax.x, gm_SDF_Glow_MinMax.y, texcol.a);\n		}\n	}	\n	\n	// Handle outline effect\n	if (gm_SDF_DrawOutline)\n	{\n		if (texcol.a > (gm_SDF_Outline_Thresh - pixelspread))\n		{			\n			blendfactor = smoothstep(gm_SDF_Outline_Thresh - pixelspread, gm_SDF_Outline_Thresh + pixelspread, texcol.a);\n			if (currcol.a < 0.0)\n			{\n				currcol = vec4(gm_SDF_Outline_Col.r,gm_SDF_Outline_Col.g,gm_SDF_Outline_Col.b, 0.0);\n			}\n			currcol = mix(currcol, gm_SDF_Outline_Col, blendfactor);\n		}\n	}\n	\n	// Handle inner core\n	blendfactor = smoothstep(gm_SDF_Core_Thresh - pixelspread, gm_SDF_Core_Thresh + pixelspread, texcol.a);\n	\n	if (currcol.a < 0.0)\n	{\n		currcol = vec4(gm_SDF_Core_Col.r,gm_SDF_Core_Col.g,gm_SDF_Core_Col.b, 0.0);\n	}\n	texcol = mix(currcol, gm_SDF_Core_Col, blendfactor);	\n	\n	vec4 combinedcol = v_vColour * texcol;\n	DoAlphaTest(combinedcol);	\n			\n    gl_FragColor = combinedcol;\n}\n",


			 Attributes:["in_Position","in_Colour","in_TextureCoord"]
		}
,
		{
			 name:"__yy_sdf_blur_shader",


			 Vertex:"#define LOWPREC lowp\n#define	MATRIX_VIEW 					0\n#define	MATRIX_PROJECTION 				1\n#define	MATRIX_WORLD 					2\n#define	MATRIX_WORLD_VIEW 				3\n#define	MATRIX_WORLD_VIEW_PROJECTION 	4\n#define	MATRICES_MAX					5\n\nuniform mat4 gm_Matrices[MATRICES_MAX]; \n\nuniform bool gm_LightingEnabled;\nuniform bool gm_VS_FogEnabled;\nuniform float gm_FogStart;\nuniform float gm_RcpFogRange;\n\n#define MAX_VS_LIGHTS	8\n#define MIRROR_WIN32_LIGHTING_EQUATION\n\n\n//#define	MAX_VS_LIGHTS					8\nuniform vec4   gm_AmbientColour;							// rgb=colour, a=1\nuniform vec4   gm_Lights_Direction[MAX_VS_LIGHTS];		// normalised direction\nuniform vec4   gm_Lights_PosRange[MAX_VS_LIGHTS];			// X,Y,Z position,  W range\nuniform vec4   gm_Lights_Colour[MAX_VS_LIGHTS];			// rgb=colour, a=1\n\nfloat CalcFogFactor(vec4 pos)\n{\n	if (gm_VS_FogEnabled)\n	{\n		vec4 viewpos = gm_Matrices[MATRIX_WORLD_VIEW] * pos;\n		float fogfactor = ((viewpos.z - gm_FogStart) * gm_RcpFogRange);\n		return fogfactor;\n	}\n	else\n	{\n		return 0.0;\n	}\n}\n\nvec4 DoDirLight(vec3 ws_normal, vec4 dir, vec4 diffusecol)\n{\n	float dotresult = dot(ws_normal, dir.xyz);\n	dotresult = min(dotresult, dir.w);			// the w component is 1 if the directional light is active, or 0 if it isn't\n	dotresult = max(0.0, dotresult);\n\n	return dotresult * diffusecol;\n}\n\nvec4 DoPointLight(vec3 ws_pos, vec3 ws_normal, vec4 posrange, vec4 diffusecol)\n{\n	vec3 diffvec = ws_pos - posrange.xyz;\n	float veclen = length(diffvec);\n	diffvec /= veclen;	// normalise\n	float atten;\n	if (posrange.w == 0.0)		// the w component of posrange is 0 if the point light is disabled - if we don't catch it here we might end up generating INFs or NaNs\n	{\n		atten = 0.0;\n	}\n	else\n	{\n#ifdef MIRROR_WIN32_LIGHTING_EQUATION\n	// This is based on the Win32 D3D and OpenGL falloff model, where:\n	// Attenuation = 1.0f / (factor0 + (d * factor1) + (d*d * factor2))\n	// For some reason, factor0 is set to 0.0f while factor1 is set to 1.0f/lightrange (on both D3D and OpenGL)\n	// This'll result in no visible falloff as 1.0f / (d / lightrange) will always be larger than 1.0f (if the vertex is within range)\n	\n		atten = 1.0 / (veclen / posrange.w);\n		if (veclen > posrange.w)\n		{\n			atten = 0.0;\n		}	\n#else\n		atten = clamp( (1.0 - (veclen / posrange.w)), 0.0, 1.0);		// storing 1.0f/range instead would save a rcp\n#endif\n	}\n	float dotresult = dot(ws_normal, diffvec);\n	dotresult = max(0.0, dotresult);\n\n	return dotresult * atten * diffusecol;\n}\n\nvec4 DoLighting(vec4 vertexcolour, vec4 objectspacepos, vec3 objectspacenormal)\n{\n	if (gm_LightingEnabled)\n	{\n		// Normally we'd have the light positions\\directions back-transformed from world to object space\n		// But to keep things simple for the moment we'll just transform the normal to world space\n		vec4 objectspacenormal4 = vec4(objectspacenormal, 0.0);\n		vec3 ws_normal;\n		ws_normal = (gm_Matrices[MATRIX_WORLD] * objectspacenormal4).xyz;\n		ws_normal = normalize(ws_normal);\n\n		vec3 ws_pos;\n		ws_pos = (gm_Matrices[MATRIX_WORLD] * objectspacepos).xyz;\n\n		// Accumulate lighting from different light types\n		vec4 accumcol = vec4(0.0, 0.0, 0.0, 0.0);		\n		for(int i = 0; i < MAX_VS_LIGHTS; i++)\n		{\n			accumcol += DoDirLight(ws_normal, gm_Lights_Direction[i], gm_Lights_Colour[i]);\n		}\n\n		for(int i = 0; i < MAX_VS_LIGHTS; i++)\n		{\n			accumcol += DoPointLight(ws_pos, ws_normal, gm_Lights_PosRange[i], gm_Lights_Colour[i]);\n		}\n\n		accumcol *= vertexcolour;\n		accumcol += gm_AmbientColour;\n		accumcol = min(vec4(1.0, 1.0, 1.0, 1.0), accumcol);\n		accumcol.a = vertexcolour.a;\n		return accumcol;\n	}\n	else\n	{\n		return vertexcolour;\n	}\n}\n\n#define _YY_GLSLES_ 1\n//\n// Simple passthrough vertex shader\n//\nattribute vec3 in_Position;                  // (x,y,z)\n//attribute vec3 in_Normal;                  // (x,y,z)     unused in this shader.\nattribute vec4 in_Colour;                    // (r,g,b,a)\nattribute vec2 in_TextureCoord;              // (u,v)\n\nvarying vec2 v_vTexcoord;\nvarying vec4 v_vColour;\n\nvoid main()\n{\n    vec4 object_space_pos = vec4( in_Position.x, in_Position.y, in_Position.z, 1.0);\n    gl_Position = gm_Matrices[MATRIX_WORLD_VIEW_PROJECTION] * object_space_pos;\n    \n    v_vColour = in_Colour;\n    v_vTexcoord = in_TextureCoord;\n}\n",


			 Fragment:"precision mediump float;\n#define LOWPREC lowp\n// Uniforms look like they're shared between vertex and fragment shaders in GLSL, so we have to be careful to avoid name clashes\n\nuniform sampler2D gm_BaseTexture;\n\nuniform bool gm_PS_FogEnabled;\nuniform vec4 gm_FogColour;\nuniform bool gm_AlphaTestEnabled;\nuniform float gm_AlphaRefValue;\n\nvoid DoAlphaTest(vec4 SrcColour)\n{\n	if (gm_AlphaTestEnabled)\n	{\n		if (SrcColour.a <= gm_AlphaRefValue)\n		{\n			discard;\n		}\n	}\n}\n\nvoid DoFog(inout vec4 SrcColour, float fogval)\n{\n	if (gm_PS_FogEnabled)\n	{\n		SrcColour = mix(SrcColour, gm_FogColour, clamp(fogval, 0.0, 1.0)); \n	}\n}\n\n#define _YY_GLSLES_ 1\n//\n// SDF (with blur) fragment shader\n//\nvarying vec2 v_vTexcoord;\nvarying vec4 v_vColour;\n\n// SDF values are measured from 0 (at the outer edge) to 1 which is the innermost point that can be represented\nuniform vec2 gm_SDF_Blur_MinMax;			// the range across which to filter the SDF\nuniform vec4 gm_SDF_Blur_Col;				// the colour tint of the blurred text\n\nvoid main()\n{\n	vec4 texcol = texture2D( gm_BaseTexture, v_vTexcoord );	\n	vec4 currcol = gm_SDF_Blur_Col;\n		\n	currcol.a *= smoothstep(gm_SDF_Blur_MinMax.x, gm_SDF_Blur_MinMax.y, texcol.a);		\n	\n	vec4 combinedcol = v_vColour * currcol;\n	DoAlphaTest(combinedcol);	\n\n    gl_FragColor = combinedcol;\n}\n",


			 Attributes:["in_Position","in_Colour","in_TextureCoord"]
		}
	],
	Fonts: [
		{ pName: "font1", size: 10, bold: false, italic: false, first: 32, last: 9647, charset: 0, antialias: 0, fontname: "Nokia Cellphone FC", ascenderOffset: 0, ascender: 13, sdfSpread: 0, lineHeight: 18, TPageEntry: 1, scaleX: 1, scaleY: 1, glyphs: [
			{ i: 32, c: " ", x: 2, y: 2, w: 5, h: 18, shift: 5, offset: 0 },
			{ i: 33, c: "!", x: 128, y: 42, w: 3, h: 18, shift: 5, offset: 0 },
			{ i: 34, c: "\"", x: 121, y: 42, w: 5, h: 18, shift: 7, offset: 0 },
			{ i: 35, c: "#", x: 111, y: 42, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 36, c: "$", x: 101, y: 42, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 37, c: "%", x: 89, y: 42, w: 10, h: 18, shift: 12, offset: 0 },
			{ i: 38, c: "&", x: 77, y: 42, w: 10, h: 18, shift: 12, offset: 0 },
			{ i: 39, c: "'", x: 73, y: 42, w: 2, h: 18, shift: 4, offset: 0 },
			{ i: 40, c: "(", x: 66, y: 42, w: 5, h: 18, shift: 7, offset: 0 },
			{ i: 41, c: ")", x: 59, y: 42, w: 5, h: 18, shift: 7, offset: 0 },
			{ i: 42, c: "*", x: 133, y: 42, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 43, c: "+", x: 49, y: 42, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 44, c: ",", x: 34, y: 42, w: 3, h: 18, shift: 5, offset: 0 },
			{ i: 45, c: "-", x: 25, y: 42, w: 7, h: 18, shift: 9, offset: 0 },
			{ i: 46, c: ".", x: 20, y: 42, w: 3, h: 18, shift: 5, offset: 0 },
			{ i: 47, c: "/", x: 12, y: 42, w: 6, h: 18, shift: 7, offset: 0 },
			{ i: 48, c: "0", x: 2, y: 42, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 49, c: "1", x: 248, y: 22, w: 5, h: 18, shift: 7, offset: 0 },
			{ i: 50, c: "2", x: 238, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 51, c: "3", x: 228, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 52, c: "4", x: 218, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 53, c: "5", x: 39, y: 42, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 54, c: "6", x: 143, y: 42, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 55, c: "7", x: 153, y: 42, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 56, c: "8", x: 163, y: 42, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 57, c: "9", x: 112, y: 62, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 58, c: ":", x: 107, y: 62, w: 3, h: 18, shift: 5, offset: 0 },
			{ i: 59, c: ";", x: 102, y: 62, w: 3, h: 18, shift: 5, offset: 0 },
			{ i: 60, c: "<", x: 93, y: 62, w: 7, h: 18, shift: 9, offset: 0 },
			{ i: 61, c: "=", x: 84, y: 62, w: 7, h: 18, shift: 9, offset: 0 },
			{ i: 62, c: ">", x: 75, y: 62, w: 7, h: 18, shift: 9, offset: 0 },
			{ i: 63, c: "?", x: 65, y: 62, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 64, c: "@", x: 53, y: 62, w: 10, h: 18, shift: 12, offset: 0 },
			{ i: 65, c: "A", x: 43, y: 62, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 66, c: "B", x: 33, y: 62, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 67, c: "C", x: 23, y: 62, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 68, c: "D", x: 13, y: 62, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 69, c: "E", x: 2, y: 62, w: 9, h: 18, shift: 10, offset: 0 },
			{ i: 70, c: "F", x: 242, y: 42, w: 9, h: 18, shift: 10, offset: 0 },
			{ i: 71, c: "G", x: 232, y: 42, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 72, c: "H", x: 222, y: 42, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 73, c: "I", x: 217, y: 42, w: 3, h: 18, shift: 5, offset: 0 },
			{ i: 74, c: "J", x: 208, y: 42, w: 7, h: 18, shift: 9, offset: 0 },
			{ i: 75, c: "K", x: 196, y: 42, w: 10, h: 18, shift: 12, offset: 0 },
			{ i: 76, c: "L", x: 187, y: 42, w: 7, h: 18, shift: 8, offset: 0 },
			{ i: 77, c: "M", x: 173, y: 42, w: 12, h: 18, shift: 14, offset: 0 },
			{ i: 78, c: "N", x: 206, y: 22, w: 10, h: 18, shift: 12, offset: 0 },
			{ i: 79, c: "O", x: 194, y: 22, w: 10, h: 18, shift: 12, offset: 0 },
			{ i: 80, c: "P", x: 184, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 81, c: "Q", x: 212, y: 2, w: 10, h: 18, shift: 12, offset: 0 },
			{ i: 82, c: "R", x: 195, y: 2, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 83, c: "S", x: 186, y: 2, w: 7, h: 18, shift: 9, offset: 0 },
			{ i: 84, c: "T", x: 174, y: 2, w: 10, h: 18, shift: 12, offset: 0 },
			{ i: 85, c: "U", x: 164, y: 2, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 86, c: "V", x: 152, y: 2, w: 10, h: 18, shift: 12, offset: 0 },
			{ i: 87, c: "W", x: 139, y: 2, w: 11, h: 18, shift: 13, offset: 0 },
			{ i: 88, c: "X", x: 127, y: 2, w: 10, h: 18, shift: 12, offset: 0 },
			{ i: 89, c: "Y", x: 115, y: 2, w: 10, h: 18, shift: 12, offset: 0 },
			{ i: 90, c: "Z", x: 105, y: 2, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 91, c: "[", x: 205, y: 2, w: 5, h: 18, shift: 7, offset: 0 },
			{ i: 92, c: "\\", x: 97, y: 2, w: 6, h: 18, shift: 7, offset: 0 },
			{ i: 93, c: "]", x: 83, y: 2, w: 5, h: 18, shift: 7, offset: 0 },
			{ i: 94, c: "^", x: 75, y: 2, w: 6, h: 18, shift: 7, offset: 0 },
			{ i: 95, c: "_", x: 63, y: 2, w: 10, h: 18, shift: 10, offset: 0 },
			{ i: 96, c: "`", x: 58, y: 2, w: 3, h: 18, shift: 5, offset: 0 },
			{ i: 97, c: "a", x: 48, y: 2, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 98, c: "b", x: 38, y: 2, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 99, c: "c", x: 29, y: 2, w: 7, h: 18, shift: 9, offset: 0 },
			{ i: 100, c: "d", x: 19, y: 2, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 101, c: "e", x: 9, y: 2, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 102, c: "f", x: 90, y: 2, w: 5, h: 18, shift: 7, offset: 0 },
			{ i: 103, c: "g", x: 224, y: 2, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 104, c: "h", x: 72, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 105, c: "i", x: 234, y: 2, w: 3, h: 18, shift: 5, offset: 0 },
			{ i: 106, c: "j", x: 168, y: 22, w: 5, h: 18, shift: 7, offset: 0 },
			{ i: 107, c: "k", x: 158, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 108, c: "l", x: 153, y: 22, w: 3, h: 18, shift: 5, offset: 0 },
			{ i: 109, c: "m", x: 138, y: 22, w: 13, h: 18, shift: 15, offset: 0 },
			{ i: 110, c: "n", x: 128, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 111, c: "o", x: 118, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 112, c: "p", x: 108, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 113, c: "q", x: 98, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 114, c: "r", x: 89, y: 22, w: 7, h: 18, shift: 9, offset: 0 },
			{ i: 115, c: "s", x: 175, y: 22, w: 7, h: 18, shift: 9, offset: 0 },
			{ i: 116, c: "t", x: 82, y: 22, w: 5, h: 18, shift: 7, offset: 0 },
			{ i: 117, c: "u", x: 62, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 118, c: "v", x: 52, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 119, c: "w", x: 39, y: 22, w: 11, h: 18, shift: 13, offset: 0 },
			{ i: 120, c: "x", x: 29, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 121, c: "y", x: 19, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 122, c: "z", x: 9, y: 22, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 123, c: "{", x: 2, y: 22, w: 5, h: 18, shift: 7, offset: 0 },
			{ i: 124, c: "|", x: 246, y: 2, w: 3, h: 18, shift: 5, offset: 0 },
			{ i: 125, c: "}", x: 239, y: 2, w: 5, h: 18, shift: 7, offset: 0 },
			{ i: 126, c: "~", x: 122, y: 62, w: 8, h: 18, shift: 10, offset: 0 },
			{ i: 9647, c: "▯", x: 132, y: 62, w: 7, h: 18, shift: 13, offset: 3 },
			],
		},
		{ pName: "font2", size: 9, bold: false, italic: false, first: 32, last: 9647, charset: 0, antialias: 0, fontname: "Nokia Cellphone FC", ascenderOffset: 0, ascender: 13, sdfSpread: 0, lineHeight: 17, TPageEntry: 2, scaleX: 1, scaleY: 1, glyphs: [
			{ i: 32, c: " ", x: 2, y: 2, w: 5, h: 17, shift: 5, offset: 0 },
			{ i: 33, c: "!", x: 114, y: 40, w: 3, h: 17, shift: 5, offset: 0 },
			{ i: 34, c: "\"", x: 107, y: 40, w: 5, h: 17, shift: 6, offset: 0 },
			{ i: 35, c: "#", x: 97, y: 40, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 36, c: "$", x: 88, y: 40, w: 7, h: 17, shift: 9, offset: 0 },
			{ i: 37, c: "%", x: 77, y: 40, w: 9, h: 17, shift: 11, offset: 0 },
			{ i: 38, c: "&", x: 66, y: 40, w: 9, h: 17, shift: 11, offset: 0 },
			{ i: 39, c: "'", x: 62, y: 40, w: 2, h: 17, shift: 3, offset: 0 },
			{ i: 40, c: "(", x: 55, y: 40, w: 5, h: 17, shift: 7, offset: 0 },
			{ i: 41, c: ")", x: 48, y: 40, w: 5, h: 17, shift: 6, offset: 0 },
			{ i: 42, c: "*", x: 119, y: 40, w: 8, h: 17, shift: 9, offset: 0 },
			{ i: 43, c: "+", x: 38, y: 40, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 44, c: ",", x: 23, y: 40, w: 3, h: 17, shift: 5, offset: 0 },
			{ i: 45, c: "-", x: 15, y: 40, w: 6, h: 17, shift: 8, offset: 0 },
			{ i: 46, c: ".", x: 10, y: 40, w: 3, h: 17, shift: 5, offset: 0 },
			{ i: 47, c: "/", x: 2, y: 40, w: 6, h: 17, shift: 7, offset: 0 },
			{ i: 48, c: "0", x: 243, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 49, c: "1", x: 236, y: 21, w: 5, h: 17, shift: 7, offset: 0 },
			{ i: 50, c: "2", x: 226, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 51, c: "3", x: 216, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 52, c: "4", x: 206, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 53, c: "5", x: 28, y: 40, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 54, c: "6", x: 129, y: 40, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 55, c: "7", x: 139, y: 40, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 56, c: "8", x: 149, y: 40, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 57, c: "9", x: 87, y: 59, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 58, c: ":", x: 82, y: 59, w: 3, h: 17, shift: 5, offset: 0 },
			{ i: 59, c: ";", x: 77, y: 59, w: 3, h: 17, shift: 5, offset: 0 },
			{ i: 60, c: "<", x: 69, y: 59, w: 6, h: 17, shift: 8, offset: 0 },
			{ i: 61, c: "=", x: 61, y: 59, w: 6, h: 17, shift: 8, offset: 0 },
			{ i: 62, c: ">", x: 53, y: 59, w: 6, h: 17, shift: 8, offset: 0 },
			{ i: 63, c: "?", x: 43, y: 59, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 64, c: "@", x: 32, y: 59, w: 9, h: 17, shift: 11, offset: 0 },
			{ i: 65, c: "A", x: 22, y: 59, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 66, c: "B", x: 12, y: 59, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 67, c: "C", x: 2, y: 59, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 68, c: "D", x: 244, y: 40, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 69, c: "E", x: 234, y: 40, w: 8, h: 17, shift: 9, offset: 0 },
			{ i: 70, c: "F", x: 224, y: 40, w: 8, h: 17, shift: 9, offset: 0 },
			{ i: 71, c: "G", x: 214, y: 40, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 72, c: "H", x: 204, y: 40, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 73, c: "I", x: 199, y: 40, w: 3, h: 17, shift: 5, offset: 0 },
			{ i: 74, c: "J", x: 191, y: 40, w: 6, h: 17, shift: 8, offset: 0 },
			{ i: 75, c: "K", x: 180, y: 40, w: 9, h: 17, shift: 11, offset: 0 },
			{ i: 76, c: "L", x: 172, y: 40, w: 6, h: 17, shift: 8, offset: 0 },
			{ i: 77, c: "M", x: 159, y: 40, w: 11, h: 17, shift: 12, offset: 0 },
			{ i: 78, c: "N", x: 195, y: 21, w: 9, h: 17, shift: 11, offset: 0 },
			{ i: 79, c: "O", x: 184, y: 21, w: 9, h: 17, shift: 11, offset: 0 },
			{ i: 80, c: "P", x: 174, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 81, c: "Q", x: 204, y: 2, w: 9, h: 17, shift: 11, offset: 0 },
			{ i: 82, c: "R", x: 188, y: 2, w: 7, h: 17, shift: 9, offset: 0 },
			{ i: 83, c: "S", x: 180, y: 2, w: 6, h: 17, shift: 8, offset: 0 },
			{ i: 84, c: "T", x: 169, y: 2, w: 9, h: 17, shift: 11, offset: 0 },
			{ i: 85, c: "U", x: 159, y: 2, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 86, c: "V", x: 148, y: 2, w: 9, h: 17, shift: 11, offset: 0 },
			{ i: 87, c: "W", x: 135, y: 2, w: 11, h: 17, shift: 13, offset: 0 },
			{ i: 88, c: "X", x: 124, y: 2, w: 9, h: 17, shift: 11, offset: 0 },
			{ i: 89, c: "Y", x: 113, y: 2, w: 9, h: 17, shift: 11, offset: 0 },
			{ i: 90, c: "Z", x: 103, y: 2, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 91, c: "[", x: 197, y: 2, w: 5, h: 17, shift: 6, offset: 0 },
			{ i: 92, c: "\\", x: 95, y: 2, w: 6, h: 17, shift: 7, offset: 0 },
			{ i: 93, c: "]", x: 81, y: 2, w: 5, h: 17, shift: 7, offset: 0 },
			{ i: 94, c: "^", x: 73, y: 2, w: 6, h: 17, shift: 7, offset: 0 },
			{ i: 95, c: "_", x: 62, y: 2, w: 9, h: 17, shift: 9, offset: 0 },
			{ i: 96, c: "`", x: 57, y: 2, w: 3, h: 17, shift: 5, offset: 0 },
			{ i: 97, c: "a", x: 47, y: 2, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 98, c: "b", x: 37, y: 2, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 99, c: "c", x: 29, y: 2, w: 6, h: 17, shift: 8, offset: 0 },
			{ i: 100, c: "d", x: 19, y: 2, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 101, c: "e", x: 9, y: 2, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 102, c: "f", x: 88, y: 2, w: 5, h: 17, shift: 7, offset: 0 },
			{ i: 103, c: "g", x: 215, y: 2, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 104, c: "h", x: 65, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 105, c: "i", x: 225, y: 2, w: 3, h: 17, shift: 5, offset: 0 },
			{ i: 106, c: "j", x: 159, y: 21, w: 5, h: 17, shift: 7, offset: 0 },
			{ i: 107, c: "k", x: 149, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 108, c: "l", x: 144, y: 21, w: 3, h: 17, shift: 5, offset: 0 },
			{ i: 109, c: "m", x: 130, y: 21, w: 12, h: 17, shift: 14, offset: 0 },
			{ i: 110, c: "n", x: 120, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 111, c: "o", x: 110, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 112, c: "p", x: 100, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 113, c: "q", x: 90, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 114, c: "r", x: 82, y: 21, w: 6, h: 17, shift: 8, offset: 0 },
			{ i: 115, c: "s", x: 166, y: 21, w: 6, h: 17, shift: 8, offset: 0 },
			{ i: 116, c: "t", x: 75, y: 21, w: 5, h: 17, shift: 7, offset: 0 },
			{ i: 117, c: "u", x: 55, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 118, c: "v", x: 45, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 119, c: "w", x: 32, y: 21, w: 11, h: 17, shift: 13, offset: 0 },
			{ i: 120, c: "x", x: 22, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 121, c: "y", x: 12, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 122, c: "z", x: 2, y: 21, w: 8, h: 17, shift: 10, offset: 0 },
			{ i: 123, c: "{", x: 242, y: 2, w: 5, h: 17, shift: 6, offset: 0 },
			{ i: 124, c: "|", x: 237, y: 2, w: 3, h: 17, shift: 5, offset: 0 },
			{ i: 125, c: "}", x: 230, y: 2, w: 5, h: 17, shift: 7, offset: 0 },
			{ i: 126, c: "~", x: 97, y: 59, w: 8, h: 17, shift: 9, offset: 0 },
			{ i: 9647, c: "▯", x: 107, y: 59, w: 7, h: 17, shift: 12, offset: 2 },
			],
		}	],
	EmbeddedFonts: [
,
		{ pName: "FONT_builtin", size: 11, bold: false, italic: false, first: 32, last: 9647, charset: 0, antialias: 1, fontname: "Roboto Mono", ascenderOffset: 0, ascender: 0, sdfSpread: 0, lineHeight: 0, TPageEntry: 3, scaleX: 1, scaleY: 1, glyphs: [
			{ i: 32, c: " ", x: 2, y: 2, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 33, c: "!", x: 127, y: 44, w: 3, h: 19, shift: 9, offset: 3 },
			{ i: 34, c: "\"", x: 120, y: 44, w: 5, h: 19, shift: 9, offset: 2 },
			{ i: 35, c: "#", x: 109, y: 44, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 36, c: "$", x: 100, y: 44, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 37, c: "%", x: 89, y: 44, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 38, c: "&", x: 78, y: 44, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 39, c: "'", x: 74, y: 44, w: 2, h: 19, shift: 9, offset: 3 },
			{ i: 40, c: "(", x: 67, y: 44, w: 5, h: 19, shift: 9, offset: 2 },
			{ i: 41, c: ")", x: 60, y: 44, w: 5, h: 19, shift: 9, offset: 2 },
			{ i: 42, c: "*", x: 132, y: 44, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 43, c: "+", x: 49, y: 44, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 44, c: ",", x: 34, y: 44, w: 3, h: 19, shift: 9, offset: 2 },
			{ i: 45, c: "-", x: 25, y: 44, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 46, c: ".", x: 20, y: 44, w: 3, h: 19, shift: 9, offset: 3 },
			{ i: 47, c: "/", x: 11, y: 44, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 48, c: "0", x: 2, y: 44, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 49, c: "1", x: 245, y: 23, w: 5, h: 19, shift: 9, offset: 1 },
			{ i: 50, c: "2", x: 235, y: 23, w: 8, h: 19, shift: 9, offset: 0 },
			{ i: 51, c: "3", x: 225, y: 23, w: 8, h: 19, shift: 9, offset: 0 },
			{ i: 52, c: "4", x: 214, y: 23, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 53, c: "5", x: 39, y: 44, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 54, c: "6", x: 142, y: 44, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 55, c: "7", x: 151, y: 44, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 56, c: "8", x: 162, y: 44, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 57, c: "9", x: 110, y: 65, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 58, c: ":", x: 105, y: 65, w: 3, h: 19, shift: 9, offset: 3 },
			{ i: 59, c: ";", x: 100, y: 65, w: 3, h: 19, shift: 9, offset: 3 },
			{ i: 60, c: "<", x: 91, y: 65, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 61, c: "=", x: 82, y: 65, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 62, c: ">", x: 73, y: 65, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 63, c: "?", x: 64, y: 65, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 64, c: "@", x: 53, y: 65, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 65, c: "A", x: 42, y: 65, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 66, c: "B", x: 32, y: 65, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 67, c: "C", x: 21, y: 65, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 68, c: "D", x: 11, y: 65, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 69, c: "E", x: 2, y: 65, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 70, c: "F", x: 241, y: 44, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 71, c: "G", x: 230, y: 44, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 72, c: "H", x: 221, y: 44, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 73, c: "I", x: 212, y: 44, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 74, c: "J", x: 202, y: 44, w: 8, h: 19, shift: 9, offset: 0 },
			{ i: 75, c: "K", x: 192, y: 44, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 76, c: "L", x: 182, y: 44, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 77, c: "M", x: 172, y: 44, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 78, c: "N", x: 205, y: 23, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 79, c: "O", x: 194, y: 23, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 80, c: "P", x: 184, y: 23, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 81, c: "Q", x: 208, y: 2, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 82, c: "R", x: 192, y: 2, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 83, c: "S", x: 181, y: 2, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 84, c: "T", x: 170, y: 2, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 85, c: "U", x: 161, y: 2, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 86, c: "V", x: 150, y: 2, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 87, c: "W", x: 139, y: 2, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 88, c: "X", x: 128, y: 2, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 89, c: "Y", x: 117, y: 2, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 90, c: "Z", x: 107, y: 2, w: 8, h: 19, shift: 9, offset: 0 },
			{ i: 91, c: "[", x: 202, y: 2, w: 4, h: 19, shift: 9, offset: 3 },
			{ i: 92, c: "\\", x: 98, y: 2, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 93, c: "]", x: 82, y: 2, w: 4, h: 19, shift: 9, offset: 2 },
			{ i: 94, c: "^", x: 73, y: 2, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 95, c: "_", x: 64, y: 2, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 96, c: "`", x: 59, y: 2, w: 3, h: 19, shift: 9, offset: 3 },
			{ i: 97, c: "a", x: 50, y: 2, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 98, c: "b", x: 41, y: 2, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 99, c: "c", x: 32, y: 2, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 100, c: "d", x: 23, y: 2, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 101, c: "e", x: 13, y: 2, w: 8, h: 19, shift: 9, offset: 0 },
			{ i: 102, c: "f", x: 88, y: 2, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 103, c: "g", x: 219, y: 2, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 104, c: "h", x: 72, y: 23, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 105, c: "i", x: 228, y: 2, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 106, c: "j", x: 167, y: 23, w: 6, h: 19, shift: 9, offset: 1 },
			{ i: 107, c: "k", x: 157, y: 23, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 108, c: "l", x: 147, y: 23, w: 8, h: 19, shift: 9, offset: 1 },
			{ i: 109, c: "m", x: 136, y: 23, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 110, c: "n", x: 127, y: 23, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 111, c: "o", x: 116, y: 23, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 112, c: "p", x: 107, y: 23, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 113, c: "q", x: 98, y: 23, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 114, c: "r", x: 90, y: 23, w: 6, h: 19, shift: 9, offset: 2 },
			{ i: 115, c: "s", x: 175, y: 23, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 116, c: "t", x: 81, y: 23, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 117, c: "u", x: 63, y: 23, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 118, c: "v", x: 52, y: 23, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 119, c: "w", x: 41, y: 23, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 120, c: "x", x: 30, y: 23, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 121, c: "y", x: 19, y: 23, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 122, c: "z", x: 10, y: 23, w: 7, h: 19, shift: 9, offset: 1 },
			{ i: 123, c: "{", x: 2, y: 23, w: 6, h: 19, shift: 9, offset: 2 },
			{ i: 124, c: "|", x: 246, y: 2, w: 3, h: 19, shift: 9, offset: 3 },
			{ i: 125, c: "}", x: 238, y: 2, w: 6, h: 19, shift: 9, offset: 2 },
			{ i: 126, c: "~", x: 119, y: 65, w: 9, h: 19, shift: 9, offset: 0 },
			{ i: 9647, c: "▯", x: 130, y: 65, w: 5, h: 19, shift: 8, offset: 1 },
			],
		}	],
	Timelines: [
	],
	Triggers: [{ }],
	GMObjects: [
		{			pName: "o_Storeplace",  spriteIndex: -1,  visible: true,  persistent: true,  parent: -100,  CreateEvent: gml_Object_o_Storeplace_Create_0,
 ObjAlarm0: gml_Object_o_Storeplace_Alarm_0,
 EndGameEvent: gml_Object_o_Storeplace_Other_3,
 StartGameEvent: gml_Object_o_Storeplace_Other_2,
 DrawGUI: gml_Object_o_Storeplace_Draw_64,
 KeyPressed_F1: gml_Object_o_Storeplace_KeyPress_112,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_spawner",  spriteIndex: -1,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_spawner_Create_0,
 ObjAlarm0: gml_Object_o_spawner_Alarm_0,
 StepNormalEvent: gml_Object_o_spawner_Step_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_paper_20",  visible: true,  persistent: true,  parent: 42,  CreateEvent: gml_Object_o_button_paper_20_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_wood_14",  visible: true,  persistent: true,  parent: 16,  CreateEvent: gml_Object_o_button_wood_14_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_ArrowToFactory",  spriteIndex: 7,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_ArrowToFactory_Create_0,
 StepNormalEvent: gml_Object_o_ArrowToFactory_Step_0,
 LeftButtonPressed: gml_Object_o_ArrowToFactory_Mouse_4,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_bg_crusher",  spriteIndex: 14,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_bg_crusher_Create_0,
 StepNormalEvent: gml_Object_o_bg_crusher_Step_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_item",  spriteIndex: 5,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_item_Create_0,
 StepNormalEvent: gml_Object_o_item_Step_0,
 DrawEvent: gml_Object_o_item_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_Sorter",  spriteIndex: 13,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_Sorter_Create_0,
 StepNormalEvent: gml_Object_o_Sorter_Step_0,
 LeftButtonPressed: gml_Object_o_Sorter_Mouse_4,
 DrawEvent: gml_Object_o_Sorter_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_1_text",  spriteIndex: -1,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_button_1_text_Create_0,
 StepNormalEvent: gml_Object_o_button_1_text_Step_0,
 DrawEvent: gml_Object_o_button_1_text_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_Pressurizer",  spriteIndex: 15,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_Pressurizer_Create_0,
 ObjAlarm0: gml_Object_o_Pressurizer_Alarm_0,
 StepNormalEvent: gml_Object_o_Pressurizer_Step_0,
 MouseLeave: gml_Object_o_Pressurizer_Mouse_11,
 LeftButtonPressed: gml_Object_o_Pressurizer_Mouse_4,
 DrawEvent: gml_Object_o_Pressurizer_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_paper_menu",  visible: true,  persistent: true,  parent: 35,  CreateEvent: gml_Object_o_button_paper_menu_Create_0,
 StepEndEvent: gml_Object_o_button_paper_menu_Step_2,
 LeftButtonPressed: gml_Object_o_button_paper_menu_Mouse_4,
 DrawEvent: gml_Object_o_button_paper_menu_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_1",  visible: true,  parent: 35,  CreateEvent: gml_Object_o_button_1_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_auto_19",  visible: true,  persistent: true,  parent: 26,  CreateEvent: gml_Object_o_button_auto_19_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_paper_16",  visible: true,  persistent: true,  parent: 42,  CreateEvent: gml_Object_o_button_paper_16_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_Autoclicker",  spriteIndex: -1,  visible: true,  persistent: true,  parent: -100,  CreateEvent: gml_Object_o_Autoclicker_Create_0,
 ObjAlarm0: gml_Object_o_Autoclicker_Alarm_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_paper_12",  visible: true,  persistent: true,  parent: 42,  CreateEvent: gml_Object_o_button_paper_12_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_wood",  persistent: true,  parent: 35,  StepEndEvent: gml_Object_o_button_wood_Step_2,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_stop",  spriteIndex: 10,  parent: -100,  TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_2",  visible: true,  parent: 35,  CreateEvent: gml_Object_o_button_2_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_wood_6",  visible: true,  persistent: true,  parent: 16,  CreateEvent: gml_Object_o_button_wood_6_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_paper_15",  visible: true,  persistent: true,  parent: 42,  CreateEvent: gml_Object_o_button_paper_15_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_wood_9",  visible: true,  persistent: true,  parent: 16,  CreateEvent: gml_Object_o_button_wood_9_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_wood_18",  visible: true,  persistent: true,  parent: 16,  CreateEvent: gml_Object_o_button_wood_18_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_PressurizerPipe",  spriteIndex: 8,  visible: true,  parent: -100,  TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_auto_menu",  visible: true,  persistent: true,  parent: 35,  CreateEvent: gml_Object_o_button_auto_menu_Create_0,
 StepEndEvent: gml_Object_o_button_auto_menu_Step_2,
 LeftButtonPressed: gml_Object_o_button_auto_menu_Mouse_4,
 DrawEvent: gml_Object_o_button_auto_menu_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_bg_pipethingy",  spriteIndex: 18,  visible: true,  parent: -100,  TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_auto",  persistent: true,  parent: 35,  StepEndEvent: gml_Object_o_button_auto_Step_2,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_paper_5",  visible: true,  persistent: true,  parent: 42,  CreateEvent: gml_Object_o_button_paper_5_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_paper_4",  visible: true,  persistent: true,  parent: 42,  CreateEvent: gml_Object_o_button_paper_4_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_bg_conveyorbelt",  spriteIndex: 16,  visible: true,  parent: -100,  TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_SorterGiver",  spriteIndex: 6,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_SorterGiver_Create_0,
 StepNormalEvent: gml_Object_o_SorterGiver_Step_0,
 LeftButtonPressed: gml_Object_o_SorterGiver_Mouse_4,
 DrawEvent: gml_Object_o_SorterGiver_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_paper_7",  visible: true,  persistent: true,  parent: 42,  CreateEvent: gml_Object_o_button_paper_7_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_GearStorage",  spriteIndex: 6,  visible: true,  persistent: true,  parent: -100,  CreateEvent: gml_Object_o_GearStorage_Create_0,
 StepNormalEvent: gml_Object_o_GearStorage_Step_0,
 StartRoomEvent: gml_Object_o_GearStorage_Other_4,
 DrawEvent: gml_Object_o_GearStorage_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_auto_3",  visible: true,  persistent: true,  parent: 26,  CreateEvent: gml_Object_o_button_auto_3_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_ScrapBin",  spriteIndex: 3,  visible: true,  parent: -100,  TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button",  spriteIndex: -1,  persistent: true,  parent: -100,  CreateEvent: gml_Object_o_button_Create_0,
 ObjAlarm0: gml_Object_o_button_Alarm_0,
 StepNormalEvent: gml_Object_o_button_Step_0,
 LeftButtonPressed: gml_Object_o_button_Mouse_4,
 MouseEnter: gml_Object_o_button_Mouse_10,
 MouseLeave: gml_Object_o_button_Mouse_11,
 DrawEvent: gml_Object_o_button_Draw_0,
 DrawGUI: gml_Object_o_button_Draw_64,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_Giver",  spriteIndex: -1,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_Giver_Create_0,
 StepNormalEvent: gml_Object_o_Giver_Step_0,
 DrawEvent: gml_Object_o_Giver_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_paper_13",  visible: true,  persistent: true,  parent: 42,  CreateEvent: gml_Object_o_button_paper_13_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_GearSlot",  spriteIndex: 4,  visible: true,  persistent: true,  parent: -100,  CreateEvent: gml_Object_o_GearSlot_Create_0,
 StepNormalEvent: gml_Object_o_GearSlot_Step_0,
 DrawEvent: gml_Object_o_GearSlot_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_wood_10",  visible: true,  persistent: true,  parent: 16,  CreateEvent: gml_Object_o_button_wood_10_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_GearSlotDown",  spriteIndex: 7,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_GearSlotDown_Create_0,
 LeftButtonPressed: gml_Object_o_GearSlotDown_Mouse_4,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_wood_17",  visible: true,  persistent: true,  parent: 16,  CreateEvent: gml_Object_o_button_wood_17_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_paper",  persistent: true,  parent: 35,  StepEndEvent: gml_Object_o_button_paper_Step_2,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_ArrowToSorting",  spriteIndex: 7,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_ArrowToSorting_Create_0,
 StepNormalEvent: gml_Object_o_ArrowToSorting_Step_0,
 LeftButtonPressed: gml_Object_o_ArrowToSorting_Mouse_4,
 DrawEvent: gml_Object_o_ArrowToSorting_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_ArrowToGearing",  spriteIndex: 7,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_ArrowToGearing_Create_0,
 StepNormalEvent: gml_Object_o_ArrowToGearing_Step_0,
 LeftButtonPressed: gml_Object_o_ArrowToGearing_Mouse_4,
 DrawEvent: gml_Object_o_ArrowToGearing_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_wood_8",  visible: true,  persistent: true,  parent: 16,  CreateEvent: gml_Object_o_button_wood_8_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_GearSlotUp",  spriteIndex: 7,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_GearSlotUp_Create_0,
 LeftButtonPressed: gml_Object_o_GearSlotUp_Mouse_4,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_destroyer",  spriteIndex: 10,  visible: true,  parent: -100,  TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_wood_menu",  visible: true,  persistent: true,  parent: 35,  CreateEvent: gml_Object_o_button_wood_menu_Create_0,
 StepEndEvent: gml_Object_o_button_wood_menu_Step_2,
 LeftButtonPressed: gml_Object_o_button_wood_menu_Mouse_4,
 DrawEvent: gml_Object_o_button_wood_menu_Draw_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_button_auto_11",  visible: true,  persistent: true,  parent: 26,  CreateEvent: gml_Object_o_button_auto_11_Create_0,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_Throwables",  spriteIndex: -1,  visible: true,  parent: -100,  CreateEvent: gml_Object_o_Throwables_Create_0,
 StepNormalEvent: gml_Object_o_Throwables_Step_0,
 LeftButtonPressed: gml_Object_o_Throwables_Mouse_4,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_GearSystem",  spriteIndex: -1,  visible: true,  persistent: true,  parent: 50,  CreateEvent: gml_Object_o_GearSystem_Create_0,
 StepNormalEvent: gml_Object_o_GearSystem_Step_0,
 MouseEnter: gml_Object_o_GearSystem_Mouse_10,
 MouseLeave: gml_Object_o_GearSystem_Mouse_11,
 DrawGUI: gml_Object_o_GearSystem_Draw_64,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 },
		{			pName: "o_Gears",  spriteIndex: 1,  visible: true,  parent: 51,  CreateEvent: gml_Object_o_Gears_Create_0,
 ObjAlarm0: gml_Object_o_Gears_Alarm_0,
 StepNormalEvent: gml_Object_o_Gears_Step_0,
 LeftButtonPressed: gml_Object_o_Gears_Mouse_4,
 TriggerEvents: [  ],
 CollisionEvents: [  ]
 }	],
	AnimCurves: [
	],
	Sequences: [
	],
	FiltersAndEffectDefs: [
	],
	PSEmitters: [
	],
	ParticleSystems: [
	],
	GMRooms: [
		{	
			pName:"Room1"
			, width:960
			, height:544
			, speed:0
			, persistent:true
			, colour:0
			, LayerCount:9
			, showColour:false
			, enableViews:true
			, viewClearScreen:false
			, backgrounds:[
			]
			, views:[
				{ visible:true, wview:960, hview:544, wport:1920, hport:1088 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 }			]
			, pInstances:[
				{x:32, y:0, index:14, id:100025, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:0, y:0, index:0, id:100026, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:32, index:24, id:100000, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:96, y:32, index:10, id:100001, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:128, index:28, id:100013, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:1120, y:96, index:26, id:100002, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:1024, y:96, index:42, id:100003, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:128, index:33, id:100021, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:192, index:27, id:100014, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:1216, y:96, index:16, id:100004, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:160, y:32, index:48, id:100005, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:608, y:256, index:11, id:100030, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:416, index:18, id:100031, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:256, index:31, id:100015, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:192, index:49, id:100022, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:-64, y:480, index:29, id:100034, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:0, y:480, index:29, id:100035, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:64, y:480, index:29, id:100036, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:128, y:480, index:29, id:100037, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:192, y:480, index:29, id:100038, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:256, y:480, index:29, id:100039, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:320, y:480, index:29, id:100040, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:384, y:480, index:29, id:100041, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:448, y:480, index:29, id:100042, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:512, y:480, index:29, id:100043, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:576, y:480, index:29, id:100044, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:640, y:480, index:29, id:100045, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:704, y:480, index:29, id:100046, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:768, y:480, index:29, id:100047, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:832, y:480, index:29, id:100048, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:896, y:480, index:29, id:100049, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:960, y:480, index:29, id:100050, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:704, y:384, index:5, id:100024, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:1024, y:448, index:47, id:100051, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:768, y:448, index:17, id:100052, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:-64, y:448, index:1, id:100053, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:704, y:320, index:25, id:100054, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:704, y:256, index:25, id:100055, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:704, y:192, index:25, id:100056, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:704, y:128, index:25, id:100057, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:704, y:64, index:25, id:100058, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:704, y:0, index:25, id:100059, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:192, index:39, id:100006, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:128, index:19, id:100007, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:256, index:45, id:100008, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:320, index:21, id:100009, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:64, y:0, index:51, id:100027, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:640, y:64, index:44, id:100028, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:128, y:192, index:38, id:100032, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:352, y:128, index:32, id:100033, rotation:0, scaleX:5, scaleY:3, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:64, y:224, index:43, id:100029, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:320, index:15, id:100016, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:384, index:3, id:100010, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:384, index:37, id:100017, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:448, index:20, id:100018, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:448, index:41, id:100011, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:320, y:128, index:13, id:100019, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:320, y:128, index:22, id:100012, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:256, index:12, id:100023, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:320, y:192, index:2, id:100020, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 }			]
			, tiles:[
			]	
			, layers:[
				{pName:"Menu_Buttons", id:1, type:2, depth:10, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:6, iinstIDs:[100000,100001,100002,100003,100004,100005] },
				{pName:"Wood_Buttons", id:2, type:2, depth:-290, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:7, iinstIDs:[100006,100007,100008,100009,100010,100011,100012] },
				{pName:"Paper_Buttons", id:3, type:2, depth:-190, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:8, iinstIDs:[100013,100014,100015,100016,100017,100018,100019,100020] },
				{pName:"Auto_Buttons", id:4, type:2, depth:-90, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:3, iinstIDs:[100021,100022,100023] },
				{pName:"Menu", id:0, type:2, depth:-390, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] },
				{pName:"Instances_1", id:5, type:2, depth:110, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:6, iinstIDs:[100024,100025,100026,100027,100028,100029] },
				{pName:"Instances", id:6, type:2, depth:210, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:4, iinstIDs:[100030,100031,100032,100033] },
				{pName:"Setting", id:7, type:2, depth:310, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:26, iinstIDs:[100034,100035,100036,100037,100038,100039,100040,100041,100042,100043,100044,100045,100046,100047,100048,100049,100050,100051,100052,100053,100054,100055,100056,100057,100058,100059] },
				{pName:"Background", id:8, type:1, depth:410, x:12, y:10, hspeed:0.5, vspeed:0.125, visible:1, effectEnabled:1, effectType:"", effectProperties:[], bvisible:true, bforeground:false, bindex:11, bhtiled:true, bvtiled:true, bstretch:false, bblend:-6710887, bimage_index:0, bimage_speed:30 }			]	
		}	,
		{	
			pName:"BaseRoom"
			, width:960
			, height:544
			, speed:0
			, colour:0
			, LayerCount:5
			, showColour:false
			, enableViews:true
			, viewClearScreen:false
			, backgrounds:[
			]
			, views:[
				{ visible:true, wview:960, hview:544, wport:1920, hport:1088 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 }			]
			, pInstances:[
				{x:32, y:128, index:28, id:100067, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:192, index:27, id:100068, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:128, index:33, id:100075, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:32, index:24, id:100078, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:96, y:32, index:10, id:100079, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:1120, y:96, index:26, id:100080, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:1024, y:96, index:42, id:100081, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:1216, y:96, index:16, id:100082, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:160, y:32, index:48, id:100083, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:192, index:49, id:100076, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:256, index:31, id:100069, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:192, index:39, id:100060, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:128, index:19, id:100061, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:256, index:45, id:100062, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:320, index:21, id:100063, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:320, index:15, id:100070, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:384, index:37, id:100071, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:384, index:3, id:100064, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:448, index:20, id:100072, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:320, y:128, index:13, id:100073, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:448, index:41, id:100065, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:320, y:128, index:22, id:100066, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:32, y:256, index:12, id:100077, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:320, y:192, index:2, id:100074, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 }			]
			, tiles:[
			]	
			, layers:[
				{pName:"Wood_Buttons", id:10, type:2, depth:-290, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:7, iinstIDs:[100060,100061,100062,100063,100064,100065,100066] },
				{pName:"Paper_Buttons", id:11, type:2, depth:-190, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:8, iinstIDs:[100067,100068,100069,100070,100071,100072,100073,100074] },
				{pName:"Auto_Buttons", id:12, type:2, depth:-90, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:3, iinstIDs:[100075,100076,100077] },
				{pName:"Menu_Buttons", id:13, type:2, depth:10, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:6, iinstIDs:[100078,100079,100080,100081,100082,100083] },
				{pName:"Menu", id:9, type:2, depth:-390, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] }			]	
		}	,
		{	
			pName:"Room2"
			, width:960
			, height:544
			, speed:0
			, persistent:true
			, colour:0
			, LayerCount:8
			, showColour:false
			, enableViews:true
			, viewClearScreen:false
			, backgrounds:[
			]
			, views:[
				{ visible:true, wview:960, hview:544, wport:1920, hport:1088 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 }			]
			, pInstances:[
				{x:800, y:-96, index:23, id:100084, rotation:0, scaleX:2.25, scaleY:2, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:800, y:160, index:23, id:100085, rotation:0, scaleX:2.25, scaleY:2, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:608, y:480, index:4, id:100086, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:256, y:256, index:40, id:100087, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:256, y:128, index:46, id:100088, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:800, y:416, index:9, id:100089, rotation:0, scaleX:2.25, scaleY:2.25, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:576, y:0, index:34, id:100090, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 }			]
			, tiles:[
			]	
			, layers:[
				{pName:"Wood_Buttons", id:15, type:2, depth:-290, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] },
				{pName:"Paper_Buttons", id:16, type:2, depth:-190, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] },
				{pName:"Auto_Buttons", id:17, type:2, depth:-90, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] },
				{pName:"Menu_Buttons", id:18, type:2, depth:10, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] },
				{pName:"Menu", id:14, type:2, depth:-390, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] },
				{pName:"Instances_1", id:19, type:2, depth:110, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] },
				{pName:"Instances", id:20, type:2, depth:210, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:7, iinstIDs:[100084,100085,100086,100087,100088,100089,100090] },
				{pName:"Backgrounds_1", id:21, type:1, depth:310, x:12, y:10, hspeed:0.125, vspeed:0.25, visible:1, effectEnabled:1, effectType:"", effectProperties:[], bvisible:true, bforeground:false, bindex:17, bhtiled:true, bvtiled:true, bstretch:false, bblend:-8421505, bimage_index:0, bimage_speed:30 }			]	
		}	,
		{	
			pName:"Room3"
			, width:960
			, height:544
			, speed:0
			, colour:0
			, LayerCount:8
			, showColour:false
			, enableViews:true
			, viewClearScreen:false
			, backgrounds:[
			]
			, views:[
				{ visible:true, wview:960, hview:544, wport:1920, hport:1088 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 },
				{ wview:1366, hview:768, wport:1366, hport:768 }			]
			, pInstances:[
				{x:896, y:288, index:4, id:100091, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:96, y:96, index:7, id:100092, pCode: gml_RoomCC_Room3_1_Create, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:96, y:192, index:7, id:100093, pCode: gml_RoomCC_Room3_2_Create, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:96, y:288, index:7, id:100094, pCode: gml_RoomCC_Room3_3_Create, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:96, y:384, index:7, id:100095, pCode: gml_RoomCC_Room3_4_Create, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:96, y:480, index:7, id:100096, pCode: gml_RoomCC_Room3_5_Create, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:192, y:96, index:7, id:100097, pCode: gml_RoomCC_Room3_6_Create, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:192, y:192, index:7, id:100098, pCode: gml_RoomCC_Room3_7_Create, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:192, y:288, index:7, id:100099, pCode: gml_RoomCC_Room3_8_Create, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:192, y:384, index:7, id:100100, pCode: gml_RoomCC_Room3_9_Create, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:192, y:480, index:7, id:100101, pCode: gml_RoomCC_Room3_10_Create, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:736, y:416, index:30, id:100102, pCode: gml_RoomCC_Room3_11_Create, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:640, y:416, index:30, id:100103, pCode: gml_RoomCC_Room3_12_Create, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 },
				{x:576, y:288, index:36, id:100104, rotation:0, scaleX:1, scaleY:1, imageSpeed:1, imageIndex:0, colour:4294967295 }			]
			, tiles:[
			]	
			, layers:[
				{pName:"Wood_Buttons", id:23, type:2, depth:-290, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] },
				{pName:"Paper_Buttons", id:24, type:2, depth:-190, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] },
				{pName:"Auto_Buttons", id:25, type:2, depth:-90, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] },
				{pName:"Menu_Buttons", id:26, type:2, depth:10, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] },
				{pName:"Menu", id:22, type:2, depth:-390, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:0, iinstIDs:[] },
				{pName:"Instances_1", id:27, type:2, depth:110, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:1, iinstIDs:[100091] },
				{pName:"Instances", id:28, type:2, depth:210, x:0, y:0, hspeed:0, vspeed:0, visible:1, effectEnabled:1, effectType:"", effectProperties:[], icount:13, iinstIDs:[100092,100093,100094,100095,100096,100097,100098,100099,100100,100101,100102,100103,100104] },
				{pName:"Backgrounds_1", id:29, type:1, depth:310, x:91, y:82, hspeed:-0.125, vspeed:0.75, visible:1, effectEnabled:1, effectType:"", effectProperties:[], bvisible:true, bforeground:false, bindex:9, bhtiled:true, bvtiled:true, bstretch:false, bblend:-8355712, bimage_index:0, bimage_speed:30 }			]	
		}		],
	RoomOrder: [0,1,2,3	],
	TPageEntries: [
		{ x:0, y:0, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:0},
		{ x:2, y:2, w:256, h:128, XOffset:0, YOffset:0, CropWidth:256, CropHeight:128, ow:256, oh:128, tp:1},
		{ x:2, y:134, w:256, h:128, XOffset:0, YOffset:0, CropWidth:256, CropHeight:128, ow:256, oh:128, tp:1},
		{ x:4, y:268, w:256, h:128, XOffset:0, YOffset:0, CropWidth:256, CropHeight:128, ow:256, oh:128, tp:1},
		{ x:2, y:402, w:128, h:128, XOffset:0, YOffset:0, CropWidth:128, CropHeight:128, ow:128, oh:128, tp:1},
		{ x:134, y:402, w:64, h:160, XOffset:0, YOffset:0, CropWidth:64, CropHeight:160, ow:64, oh:160, tp:1},
		{ x:2, y:534, w:64, h:160, XOffset:0, YOffset:0, CropWidth:64, CropHeight:160, ow:64, oh:160, tp:1},
		{ x:70, y:566, w:64, h:160, XOffset:0, YOffset:0, CropWidth:64, CropHeight:160, ow:64, oh:160, tp:1},
		{ x:138, y:566, w:64, h:160, XOffset:0, YOffset:0, CropWidth:64, CropHeight:160, ow:64, oh:160, tp:1},
		{ x:2, y:698, w:64, h:160, XOffset:0, YOffset:0, CropWidth:64, CropHeight:160, ow:64, oh:160, tp:1},
		{ x:70, y:730, w:64, h:160, XOffset:0, YOffset:0, CropWidth:64, CropHeight:160, ow:64, oh:160, tp:1},
		{ x:2, y:862, w:64, h:160, XOffset:0, YOffset:0, CropWidth:64, CropHeight:160, ow:64, oh:160, tp:1},
		{ x:138, y:730, w:64, h:160, XOffset:0, YOffset:0, CropWidth:64, CropHeight:160, ow:64, oh:160, tp:1},
		{ x:202, y:402, w:64, h:160, XOffset:0, YOffset:0, CropWidth:64, CropHeight:160, ow:64, oh:160, tp:1},
		{ x:206, y:566, w:64, h:160, XOffset:0, YOffset:0, CropWidth:64, CropHeight:160, ow:64, oh:160, tp:1},
		{ x:206, y:730, w:64, h:160, XOffset:0, YOffset:0, CropWidth:64, CropHeight:160, ow:64, oh:160, tp:1},
		{ x:274, y:2, w:64, h:160, XOffset:0, YOffset:0, CropWidth:64, CropHeight:160, ow:64, oh:160, tp:1},
		{ x:274, y:166, w:80, h:128, XOffset:24, YOffset:0, CropWidth:80, CropHeight:128, ow:128, oh:128, tp:1},
		{ x:274, y:298, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:276, y:368, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:276, y:440, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:276, y:512, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:276, y:584, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:274, y:654, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:274, y:722, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:274, y:790, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:274, y:858, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:70, y:894, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:138, y:894, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:206, y:894, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:274, y:926, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:358, y:2, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:358, y:70, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:358, y:138, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:426, y:2, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:426, y:70, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:426, y:138, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:358, y:206, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:426, y:206, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:358, y:274, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:426, y:274, w:64, h:64, XOffset:0, YOffset:0, CropWidth:64, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:348, y:344, w:62, h:62, XOffset:1, YOffset:1, CropWidth:62, CropHeight:62, ow:64, oh:64, tp:1},
		{ x:348, y:414, w:62, h:62, XOffset:1, YOffset:1, CropWidth:62, CropHeight:62, ow:64, oh:64, tp:1},
		{ x:348, y:484, w:62, h:62, XOffset:1, YOffset:1, CropWidth:62, CropHeight:62, ow:64, oh:64, tp:1},
		{ x:348, y:554, w:62, h:62, XOffset:1, YOffset:1, CropWidth:62, CropHeight:62, ow:64, oh:64, tp:1},
		{ x:348, y:624, w:60, h:64, XOffset:2, YOffset:0, CropWidth:60, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:344, y:696, w:61, h:61, XOffset:2, YOffset:2, CropWidth:61, CropHeight:61, ow:64, oh:64, tp:1},
		{ x:344, y:765, w:62, h:60, XOffset:1, YOffset:1, CropWidth:62, CropHeight:60, ow:64, oh:64, tp:1},
		{ x:344, y:833, w:57, h:57, XOffset:3, YOffset:4, CropWidth:57, CropHeight:57, ow:64, oh:64, tp:1},
		{ x:342, y:896, w:56, h:56, XOffset:4, YOffset:4, CropWidth:56, CropHeight:56, ow:64, oh:64, tp:1},
		{ x:342, y:956, w:56, h:56, XOffset:4, YOffset:4, CropWidth:56, CropHeight:56, ow:64, oh:64, tp:1},
		{ x:416, y:342, w:48, h:64, XOffset:8, YOffset:0, CropWidth:48, CropHeight:64, ow:64, oh:64, tp:1},
		{ x:416, y:410, w:60, h:44, XOffset:4, YOffset:20, CropWidth:60, CropHeight:44, ow:64, oh:64, tp:1},
		{ x:416, y:458, w:48, h:52, XOffset:4, YOffset:12, CropWidth:48, CropHeight:52, ow:64, oh:64, tp:1},
		{ x:416, y:514, w:64, h:24, XOffset:0, YOffset:40, CropWidth:64, CropHeight:24, ow:64, oh:64, tp:1},
		{ x:416, y:542, w:64, h:24, XOffset:0, YOffset:40, CropWidth:64, CropHeight:24, ow:64, oh:64, tp:1},
		{ x:416, y:570, w:64, h:24, XOffset:0, YOffset:40, CropWidth:64, CropHeight:24, ow:64, oh:64, tp:1},
		{ x:70, y:994, w:64, h:24, XOffset:0, YOffset:40, CropWidth:64, CropHeight:24, ow:64, oh:64, tp:1},
		{ x:138, y:962, w:64, h:24, XOffset:0, YOffset:40, CropWidth:64, CropHeight:24, ow:64, oh:64, tp:1},
		{ x:138, y:994, w:64, h:24, XOffset:0, YOffset:40, CropWidth:64, CropHeight:24, ow:64, oh:64, tp:1},
		{ x:206, y:962, w:64, h:24, XOffset:0, YOffset:40, CropWidth:64, CropHeight:24, ow:64, oh:64, tp:1},
		{ x:70, y:962, w:64, h:24, XOffset:0, YOffset:40, CropWidth:64, CropHeight:24, ow:64, oh:64, tp:1},
		{ x:206, y:994, w:64, h:24, XOffset:0, YOffset:40, CropWidth:64, CropHeight:24, ow:64, oh:64, tp:1},
		{ x:418, y:600, w:62, h:10, XOffset:1, YOffset:27, CropWidth:62, CropHeight:10, ow:64, oh:64, tp:1},
		{ x:404, y:898, w:1, h:1, XOffset:31, YOffset:31, CropWidth:1, CropHeight:1, ow:64, oh:64, tp:1}	],
	Textures: ["PressureTower_texture_0.png", "PressureTower_texture_1.png"],
	TexturesBlocks:[ {MipsToGenerate: 0}
,
{MipsToGenerate: 0}
],
	TextureGroupInfo: [		{		pName: "__YY__0fallbacktexture.png_YYG_AUTO_GEN_TEX_GROUP_NAME_", 		TextureIDs: [0		],		SpriteIDs: [		],		SpineSpriteIDs: [		],		FontIDs: [		],		TilesetIDs: [		]}
,
		{		pName: "Default", 		TextureIDs: [1		],		SpriteIDs: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18		],		SpineSpriteIDs: [		],		FontIDs: [0,1		],		TilesetIDs: [		]}
],
	FeatureFlags: {"filt+fx" : "filt+fx", "gx_mod_wallpaper" : "gx_mod_wallpaper", "nullish" : "nullish", "login_sso" : "login_sso", "operagx-yyc" : "operagx-yyc", "mqtt" : "mqtt", "audio-fx" : "audio-fx", "intellisense" : "intellisense", "test" : "test", "custom_env" : "custom_env", "filt+fx" : "filt+fx", "gx_mod_wallpaper" : "gx_mod_wallpaper", "gx_mod_gamestrip" : "gx_mod_gamestrip", "live_wallpaper_subscription" : "live_wallpaper_subscription" },
	Options: {
		debugMode: false,
		AssetCompilerMajorVersion: 2,
		AssetCompilerMinorVersion: 0,
		AssetCompilerBuildVersion: 0,
		GameSpeed: 60,
		DrawColour: 4294967295,
		xscreensize: 1920,
		yscreensize: 1088,
		gameId: 0,
		gameGuid: "120e6f79-06a5-430d-9f97-2e19e1e71834",
		fullScreen: false,
		interpolatePixels: false,
		showCursor: true,
		scale: 1,
		allowFullScreenKey: true,
		freezeOnLostFocus: false,
		showLoadingBar: false,
		displayErrors: false,
		writeErrors: false,
		abortErrors: false,
		variableErrors: true,
		outputDebugToConsole: false,
		WebGL: 1,
		WebGLPreserveDrawingBuffer: 0,
		CollisionCompatibility: false,
		UseNewAudio: true,
		GameDir: "PressureFactory",
		Config: "Default",
		ViewColour: 0,
		CreateEventOrder: false,
		UseParticles: true,
		UseBuiltinFont: true,
		LocalRunAlert: false,
		crc : 0,
		ProjectName : "PressureTower",
		md5 : [ 252, 126, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ],
		MajorVersion: 0,

		MinorVersion: 0,

		BuildVersion: 8,

		RevisionVersion: 0,

		DisplayName: "PressureFactory",

		UseFBExtension: false,
		tm : 1707168146
,		AllowStatistics: "True"
}
};


// #####################################################################################################
// // Script assets have changed for v2.3.0 see 
// // https://help.yoyogames.com/hc/en-us/articles/360005277377 for more information 
// function gear_activate(gear_id, item_id){
// 	var gear = o_GearSlot.gears_in[gear_id][item_id]; 
// 	switch(gear.id_) {
// 		default: 
// 			show_debug_message(gear); 
// 		break; 
// 		case 1: 
// 			//Strength Gear [" + string(level_) + "]\nBuffs the Strength of the Resource by: " + string(value_) 
// 			item_database[item_id].item_crushing_power += gear.value_; 
// 		break; 
// 		case 2: 
// 			//description = "Critical Gear [" + string(level_) + "]\nBuffs Critical Clicking Chance by: " + string(value_); 
// 			global.crit_chance_ += gear.value_; 
// 		break; 
// 		case 3: 
// 			//description = "Clicking Gear [" + string(level_) + "]\nBuffs Clicking Strength by: " + string(value_); 
// 			o_Storeplace.clicking_power += gear.value_;  
// 		break; 
// 		case 4: 
// 			//description = "Gear of Value [" + string(level_) + "]\nBuffs the Value of the Material by: " + string(value_); 
// 			item_database[item_id].item_value += gear.value_; 
// 		break; 
// 	} 
// }
function gml_GlobalScript_Script_Gears( _inst, _other ){
(_inst.gmlgear_activate = __yy_method( _inst, gml_Script_gear_activate));
}
function gml_Script_gear_activate( _inst, _other, argument0, argument1){ 
{
var gmlgear = yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index(argument0, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index(argument1, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[ ~~argument0 ])];
var ___sw2___ = yyInst(_inst,_other,gmlgear).gmlid_; 
var ___swc3___ = -1;
if (yyCompareVal(___sw2___,1,g_GMLMathEpsilon, false)==0) {
___swc3___ = 1;
}
else if (yyCompareVal(___sw2___,2,g_GMLMathEpsilon, false)==0) {
___swc3___ = 2;
}
else if (yyCompareVal(___sw2___,3,g_GMLMathEpsilon, false)==0) {
___swc3___ = 3;
}
else if (yyCompareVal(___sw2___,4,g_GMLMathEpsilon, false)==0) {
___swc3___ = 4;
}
switch( ___swc3___ ) {
default: {
show_debug_message( gmlgear );
break;
}
case 1: {
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(argument1, _inst.gmlitem_database)]).gmlitem_crushing_power=yyfplus(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(argument1, _inst.gmlitem_database)]).gmlitem_crushing_power,yyInst(_inst,_other,gmlgear).gmlvalue_);
break;
}
case 2: {
global.gmlcrit_chance_=yyfplus(global.gmlcrit_chance_,yyInst(_inst,_other,gmlgear).gmlvalue_);
break;
}
case 3: {
yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlclicking_power=yyfplus(yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlclicking_power,yyInst(_inst,_other,gmlgear).gmlvalue_);
break;
}
case 4: {
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(argument1, _inst.gmlitem_database)]).gmlitem_value=yyfplus(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(argument1, _inst.gmlitem_database)]).gmlitem_value,yyInst(_inst,_other,gmlgear).gmlvalue_);
break;
}
}
;
}
}


// #####################################################################################################
// // Script assets have changed for v2.3.0 see 
// // https://help.yoyogames.com/hc/en-us/articles/360005277377 for more information 
// function load(_save, _variable, _variable_string){ 
// 	if (variable_struct_exists(_save,_variable_string)) { 
// 		_variable = variable_struct_get(_save, _variable_string); 
// 	} 
// } 
//  
// function find_button(_id){ 
// 	with (o_button) { 
// 		if (_id == id.id_) { 
// 			return id;	 
// 		} 
// 	} 
// }
function gml_GlobalScript_Script_Storeplace( _inst, _other ){
(_inst.gmlload = __yy_method( _inst, gml_Script_load));
(_inst.gmlfind_button = __yy_method( _inst, gml_Script_find_button));
}
function gml_Script_load( _inst, _other, argument0, argument1, argument2){ 
{
if ( yyGetBool(variable_struct_exists( argument0, argument2 ))) {{
argument1=variable_struct_get( argument0, argument2 );
}
;}
;
}
}

function gml_Script_find_button( _inst, _other, argument0){ 
{
{
var __yy__v0 = GetWithArray(YYASSET_REF(0x00000023) );
for( var __yy__v1 in __yy__v0 ) {
 if (!__yy__v0.hasOwnProperty(__yy__v1)) continue;
 var __yy__v2 = __yy__v0[__yy__v1];
{
if ( yyfequal(argument0,yyInst(_inst,_other,__yy__v2.id).gmlid_)) {{
return __yy__v2.id;
}
;}
;
}
}
}
;
}
}


// #####################################################################################################
// // Script assets have changed for v2.3.0 see 
// // https://help.yoyogames.com/hc/en-us/articles/360005277377 for more information 
// function check_cost(item_id, cost){
// 	if (o_Storeplace.item_database[item_id].item_amount >= cost) {
// 		return true; 
// 	} else { 
// 		return false;	 
// 	} 
// } 
//  
// function unlock_button(unlock_id){ 
// 	o_Storeplace.button_unlock[unlock_id] = true; 
// }
function gml_GlobalScript_Script_Button( _inst, _other ){
(_inst.gmlcheck_cost = __yy_method( _inst, gml_Script_check_cost));
(_inst.gmlunlock_button = __yy_method( _inst, gml_Script_unlock_button));
}
function gml_Script_check_cost( _inst, _other, argument0, argument1){ 
{
if ( yyfgreaterequal(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(argument0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,argument1)) {{
return true;
}
;}
 else {{
return false;
}
;};
}
}

function gml_Script_unlock_button( _inst, _other, argument0){ 
{
yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock = __yy_gml_array_check( yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock, 921409278 );
yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock[__yy_gml_array_check_index_set(argument0)]=true;
}
}


// #####################################################################################################
// randomize(); 
//  
// //STATS 
// global.crit_chance_ = 0; 
// global.crit_damage_ = 100; 
// global.crush_power = 0; 
// global.maximum_crush_needed = 10; 
//  
// item = function(_item_sprite, _item_base_crushing_power, _item_sprite_crushed, _item_value, _amount, _item_unlock, _item_belt) constructor { 
// 	item_sprite = _item_sprite; 
// 	item_base_crushing_power = _item_base_crushing_power; 
// 	item_sprite_crushed = _item_sprite_crushed; 
// 	item_base_value = _item_value; 
// 	item_amount = _amount; 
// 	item_unlock = _item_unlock; 
// 	item_crushing_power = item_base_crushing_power; 
// 	item_value = item_base_value; 
// 	item_on_belt = 0; 
// 	item_belt = _item_belt; 
// } 
//  
// item_database = array_create(2); 
// item_database[0] = new item(spr_paper, 5, spr_crushed_paper, 1, 0, true, 10); 
// item_database[1] = new item(spr_wood, 50, spr_crushed_wood, 1, 0, false, 0); 
//  
// button_unlock = array_create(6, false); 
//  
// clicking_power = 1; 
//  
// max_button = 0; 
//  
// alarm_set(0,60); 
//  
// //PRESTIGE 
// global.xp_ = 0;
function gml_Object_o_Storeplace_Create_0( _inst, _other )
{
randomize(  );
global.gmlcrit_chance_=0;
global.gmlcrit_damage_=100;
global.gmlcrush_power=0;
global.gmlmaximum_crush_needed=10;
_inst.gmlitem=__yy_method( _inst, gml_Script_anon_148_gml_Object_o_Storeplace_Create_0);
_inst.gmlitem_database=array_create( 2 );
_inst.gmlitem_database = __yy_gml_array_check( _inst.gmlitem_database, 194376697 );
_inst.gmlitem_database[__yy_gml_array_check_index_set(0)]=__yy_gml_object_create( _inst, __yyg_call_method(_inst.gmlitem),YYASSET_REF(0x01000005),5,YYASSET_REF(0x01000002),1,0,true,10);
_inst.gmlitem_database[__yy_gml_array_check_index_set(1)]=__yy_gml_object_create( _inst, __yyg_call_method(_inst.gmlitem),YYASSET_REF(0x01000004),50,YYASSET_REF(0x0100000C),1,0,false,0);
_inst.gmlbutton_unlock=array_create( 6, false );
_inst.gmlclicking_power=1;
_inst.gmlmax_button=0;
alarm_set( _inst , 0, 60 );
global.gmlxp_=0;
}
function gml_Script_anon_148_gml_Object_o_Storeplace_Create_0( _inst, _other, argument0, argument1, argument2, argument3, argument4, argument5, argument6){ 
if (_inst.__yyIsGMLObject) { _inst.__type = "gml_Script_anon@148@gml_Object_o_Storeplace_Create_0"; }
if (gml_Script_anon_148_gml_Object_o_Storeplace_Create_0.prototype.__type === undefined) { gml_Script_anon_148_gml_Object_o_Storeplace_Create_0.prototype.__type = "gml_Script_anon@148@gml_Object_o_Storeplace_Create_0"; }{ 
if (_inst.__yyIsGMLObject) Object.setPrototypeOf( _inst, gml_Script_anon_148_gml_Object_o_Storeplace_Create_0.prototype);
{
_inst.gmlitem_sprite=argument0;
_inst.gmlitem_base_crushing_power=argument1;
_inst.gmlitem_sprite_crushed=argument2;
_inst.gmlitem_base_value=argument3;
_inst.gmlitem_amount=argument4;
_inst.gmlitem_unlock=argument5;
_inst.gmlitem_crushing_power=_inst.gmlitem_base_crushing_power;
_inst.gmlitem_value=_inst.gmlitem_base_value;
_inst.gmlitem_on_belt=0;
_inst.gmlitem_belt=argument6;
}
}
}


// #####################################################################################################
// //CLICKING POWER 
// clicking_power = 1; 
// clicking_power += (find_button(9).level*(1+find_button(12).level))*10; 
//  
// // Gears Setup 
// item_database[0].item_on_belt = 0; 
// item_database[1].item_on_belt = 0; 
// if (instance_exists(o_item)) { 
// 	with (o_item) { 
// 		o_Storeplace.item_database[id_].item_on_belt++; 
// 	} 
// } 
//  
// //PAPER STRENGTH 
// item_database[0].item_crushing_power = item_database[0].item_base_crushing_power; 
// item_database[0].item_crushing_power += find_button(4).level*(find_button(4).level+5); 
// item_database[0].item_crushing_power -= find_button(7).level*5; 
// item_database[0].item_crushing_power += find_button(20).level*find_button(20).level*125; 
//  
// //PAPER VALUE 
// item_database[0].item_value = item_database[0].item_base_value; 
// item_database[0].item_value += find_button(4).level; 
//  
// ///Gears for Paper 
// repeat(item_database[0].item_on_belt) { 
// 	for (var i = 0; i < o_GearSlot.gear_slots; i++) { 
// 		if (o_GearSlot.gears_in[i][0] != -1) { 
// 			gear_activate(i, 0); 
// 		} 
// 	} 
// } 
//  
// item_database[0].item_crushing_power = round(item_database[0].item_crushing_power); 
//  
// //WOOD STRENGTH 
// item_database[1].item_crushing_power = item_database[1].item_base_crushing_power; 
// item_database[1].item_crushing_power += item_database[1].item_amount*(10+find_button(6).level)*find_button(6).level; 
// item_database[1].item_crushing_power += find_button(8).level*15; 
//  
// //PAPER VALUE 
// item_database[1].item_value = item_database[1].item_base_value; 
// item_database[1].item_value += find_button(8).level*2; 
//  
// ///Gears for Wood 
// repeat(item_database[1].item_on_belt) { 
// 	for (var i = 0; i < o_GearSlot.gear_slots; i++) { 
// 		if (o_GearSlot.gears_in[i][1] != -1) { 
// 			gear_activate(i, 1); 
// 		} 
// 	} 
// } 
//  
// item_database[1].item_crushing_power = round(item_database[1].item_crushing_power); 
//  
// alarm_set(0,60);
function gml_Object_o_Storeplace_Alarm_0( _inst, _other )
{
_inst.gmlclicking_power=1;
_inst.gmlclicking_power=yyfplus(_inst.gmlclicking_power,yyftime(__yy_gml_errCheck(yyftime(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 9 )).gmllevel),__yy_gml_errCheck(yyfplus(1,__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 12 )).gmllevel))))),10));
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_on_belt=0;
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_on_belt=0;
if ( yyGetBool(instance_exists( YYASSET_REF(0x00000006) ))) {{
{
var __yy__v3 = GetWithArray(YYASSET_REF(0x00000006) );
for( var __yy__v4 in __yy__v3 ) {
 if (!__yy__v3.hasOwnProperty(__yy__v4)) continue;
 var __yy__v5 = __yy__v3[__yy__v4];
{
( g_yyPrePostObject__ = yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(__yy__v5.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_on_belt, yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(__yy__v5.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_on_belt = (g_yyPrePostObject__ instanceof Long ? yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(__yy__v5.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_on_belt.add(1) : ++yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(__yy__v5.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_on_belt), g_yyPrePostObject__);
}
}
}
;
}
;}
;
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_crushing_power=yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_base_crushing_power;
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_crushing_power=yyfplus(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_crushing_power,yyftime(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 4 )).gmllevel),__yy_gml_errCheck(yyfplus(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 4 )).gmllevel),5))));
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_crushing_power=yyfminus(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_crushing_power,yyftime(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 7 )).gmllevel),5));
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_crushing_power=yyfplus(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_crushing_power,yyftime(yyftime(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 20 )).gmllevel),__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 20 )).gmllevel)),125));
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_value=yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_base_value;
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_value=yyfplus(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_value,yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 4 )).gmllevel);
for( var __yy__v6=0, __yy__v7=yyGetInt32(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_on_belt); __yy__v6<__yy__v7; __yy__v6++) {{
var gmli = 0 ; for (; yyfless(gmli,yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfnotequal(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[ ~~gmli ])],(-1))) {{
gml_Script_gear_activate( _inst , _other , gmli, 0 );
}
;}
;
}
};
}
}
;
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_crushing_power=round( yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_crushing_power );
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_crushing_power=yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_base_crushing_power;
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_crushing_power=yyfplus(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_crushing_power,yyftime(yyftime(__yy_gml_errCheck(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_amount),__yy_gml_errCheck(yyfplus(10,__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 6 )).gmllevel)))),__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 6 )).gmllevel)));
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_crushing_power=yyfplus(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_crushing_power,yyftime(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 8 )).gmllevel),15));
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_value=yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_base_value;
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_value=yyfplus(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_value,yyftime(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 8 )).gmllevel),2));
for( var __yy__v8=0, __yy__v9=yyGetInt32(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_on_belt); __yy__v8<__yy__v9; __yy__v8++) {{
var gmli = 0 ; for (; yyfless(gmli,yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfnotequal(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[ ~~gmli ])],(-1))) {{
gml_Script_gear_activate( _inst , _other , gmli, 1 );
}
;}
;
}
};
}
}
;
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_crushing_power=round( yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_crushing_power );
alarm_set( _inst , 0, 60 );
}

// #####################################################################################################
//  
// // MATERIALS 
// var _saveData = array_create(0); 
//  
// for (var i = 0; i < array_length(item_database); i++) { 
// 	var _saveMaterial = { 
// 		item_base_crushing_power : item_database[i].item_base_crushing_power, 
// 		item_value : item_database[i].item_value, 
// 		item_amount : item_database[i].item_amount, 
// 		item_unlock : item_database[i].item_unlock, 
// 		item_belt : item_database[i].item_belt, 
// 	} 
// 	array_push(_saveData, _saveMaterial); 
// } 
//  
// var _string = json_stringify(_saveData); 
// var _buffer = buffer_create(string_byte_length(_string)+1, buffer_fixed, 1); 
// buffer_write(_buffer, buffer_string, _string); 
// show_debug_message(buffer_read(_buffer,buffer_string)); 
// buffer_save(_buffer, "materialsave.factory"); 
// buffer_delete(_buffer); 
//  
// // BUTTONS 
// _saveData = array_create(0); 
//  
// with (o_button) { 
// 	if (id_ != 0) { 
// 		var _saveButton = { 
// 			id_ : id_, 
// 			level : level, 
// 			cost : cost, 
// 			unlock : unlock, 
// 		} 
// 		array_push(_saveData, _saveButton); 
// 	} 
// } 
//  
// _string = json_stringify(_saveData); 
// _buffer = buffer_create(string_byte_length(_string)+1, buffer_fixed, 1); 
// buffer_write(_buffer, buffer_string, _string); 
// buffer_save(_buffer, "buttonsave.factory"); 
// buffer_delete(_buffer); 
//  
// // AUTOMATION 
// _saveData = array_create(0); 
//  
// with (o_Autoclicker) { 
// 	var _saveAutomation = { 
// 		auto_crush_speed : auto_crush_speed, 
// 	} 
// 	array_push(_saveData, _saveAutomation); 
// } 
//  
// _string = json_stringify(_saveData); 
// _buffer = buffer_create(string_byte_length(_string)+1, buffer_fixed, 1); 
// buffer_write(_buffer, buffer_string, _string); 
// buffer_save(_buffer, "autosave.factory"); 
// buffer_delete(_buffer); 
//  
// // ORDER 
// _saveData = array_create(0); 
//  
// for (var i = 0; i < array_length(global.order); i++) { 
// 	var _saveOrder = global.order[i]; 
// 	 
// 	array_push(_saveData, _saveOrder); 
// } 
// for (var i = 0; i < array_length(o_Storeplace.button_unlock); i++) { 
// 	var _saveOrder = o_Storeplace.button_unlock[i]; 
// 	 
// 	array_push(_saveData, _saveOrder); 
// } 
//  
// array_push(_saveData, max_button); 
//  
// _string = json_stringify(_saveData); 
// _buffer = buffer_create(string_byte_length(_string)+1, buffer_fixed, 1); 
// buffer_write(_buffer, buffer_string, _string); 
// buffer_save(_buffer, "ordersave.factory"); 
// buffer_delete(_buffer); 
//  
// // GEARS 
// _saveData = array_create(0); 
// for (var i2 = 0; i2 < o_GearSlot.item_amount; i2++) { 
// 	for (var i = 0; i < o_GearSlot.gear_slots; i++) { 
// 		var _saveGear_inSlot = o_GearSlot.gears_in[i][i2]; 
// 		array_push(_saveData, _saveGear_inSlot); 
// 	} 
// } 
//  
// for (var i = 0; i < array_length(o_GearStorage.gears_in); i++) { 
// 	var _saveGear_inStorage = o_GearStorage.gears_in[i]; 
// 	 
// 	array_push(_saveData, _saveGear_inStorage); 
// } 
//  
// array_push(_saveData, global.xp_); 
//  
// _string = json_stringify(_saveData); 
// _buffer = buffer_create(string_byte_length(_string)+1, buffer_fixed, 1); 
// buffer_write(_buffer, buffer_string, _string); 
// buffer_save(_buffer, "gearsave.factory"); 
// buffer_delete(_buffer);
function gml_Object_o_Storeplace_Other_3( _inst, _other )
{
var gml_saveData = array_create( 0 );
var gmli = 0 ; for (; yyfless(gmli,array_length( _inst.gmlitem_database )) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
var gml_saveMaterial = __yy_gml_object_create( _inst, (gml_Object_o_Storeplace_Other_3.prototype.gml___struct___0 = __yy_method( _inst, gml_Script____struct___0_gml_Object_o_Storeplace_Other_3)),yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(gmli, _inst.gmlitem_database)]).gmlitem_base_crushing_power,yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(gmli, _inst.gmlitem_database)]).gmlitem_value,yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(gmli, _inst.gmlitem_database)]).gmlitem_amount,yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(gmli, _inst.gmlitem_database)]).gmlitem_unlock,yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(gmli, _inst.gmlitem_database)]).gmlitem_belt);
array_push( gml_saveData, gml_saveMaterial );
}
};
var gml_string = json_stringify( gml_saveData );
var gml_buffer = buffer_create( yyfplus(__yy_gml_errCheck(string_byte_length( gml_string )),1), 0, 1 );
buffer_write( gml_buffer, 11, gml_string );
show_debug_message( buffer_read( gml_buffer, 11 ) );
buffer_save( gml_buffer, "materialsave.factory" );
buffer_delete( gml_buffer );
gml_saveData=array_create( 0 );
{
var __yy__v10 = GetWithArray(YYASSET_REF(0x00000023) );
for( var __yy__v11 in __yy__v10 ) {
 if (!__yy__v10.hasOwnProperty(__yy__v11)) continue;
 var __yy__v12 = __yy__v10[__yy__v11];
{
if ( yyfnotequal(__yy__v12.gmlid_,0)) {{
var gml_saveButton = __yy_gml_object_create( __yy__v12, (gml_Object_o_Storeplace_Other_3.prototype.gml___struct___1 = __yy_method( __yy__v12, gml_Script____struct___1_gml_Object_o_Storeplace_Other_3)),__yy__v12.gmlid_,__yy__v12.gmllevel,__yy__v12.gmlcost,__yy__v12.gmlunlock);
array_push( gml_saveData, gml_saveButton );
}
;}
;
}
}
}
;
gml_string=json_stringify( gml_saveData );
gml_buffer=buffer_create( yyfplus(__yy_gml_errCheck(string_byte_length( gml_string )),1), 0, 1 );
buffer_write( gml_buffer, 11, gml_string );
buffer_save( gml_buffer, "buttonsave.factory" );
buffer_delete( gml_buffer );
gml_saveData=array_create( 0 );
{
var __yy__v13 = GetWithArray(YYASSET_REF(0x0000000E) );
for( var __yy__v14 in __yy__v13 ) {
 if (!__yy__v13.hasOwnProperty(__yy__v14)) continue;
 var __yy__v15 = __yy__v13[__yy__v14];
{
var gml_saveAutomation = __yy_gml_object_create( __yy__v15, (gml_Object_o_Storeplace_Other_3.prototype.gml___struct___2 = __yy_method( __yy__v15, gml_Script____struct___2_gml_Object_o_Storeplace_Other_3)),__yy__v15.gmlauto_crush_speed);
array_push( gml_saveData, gml_saveAutomation );
}
}
}
;
gml_string=json_stringify( gml_saveData );
gml_buffer=buffer_create( yyfplus(__yy_gml_errCheck(string_byte_length( gml_string )),1), 0, 1 );
buffer_write( gml_buffer, 11, gml_string );
buffer_save( gml_buffer, "autosave.factory" );
buffer_delete( gml_buffer );
gml_saveData=array_create( 0 );
var gmli = 0 ; for (; yyfless(gmli,array_length( global.gmlorder )) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
var gml_saveOrder = global.gmlorder[__yy_gml_array_check_index(gmli, global.gmlorder)];
array_push( gml_saveData, gml_saveOrder );
}
};
var gmli = 0 ; for (; yyfless(gmli,array_length( yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock )) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
var gml_saveOrder = yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock)];
array_push( gml_saveData, gml_saveOrder );
}
};
array_push( gml_saveData, _inst.gmlmax_button );
gml_string=json_stringify( gml_saveData );
gml_buffer=buffer_create( yyfplus(__yy_gml_errCheck(string_byte_length( gml_string )),1), 0, 1 );
buffer_write( gml_buffer, 11, gml_string );
buffer_save( gml_buffer, "ordersave.factory" );
buffer_delete( gml_buffer );
gml_saveData=array_create( 0 );
var gmli2 = 0 ; for (; yyfless(gmli2,yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlitem_amount) ; ( g_yyPrePostObject__ = gmli2, gmli2 = (g_yyPrePostObject__ instanceof Long ? gmli2.add(1) : ++gmli2), g_yyPrePostObject__)) {{
var gmli = 0 ; for (; yyfless(gmli,yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
var gml_saveGear_inSlot = yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index(gmli2, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[ ~~gmli ])];
array_push( gml_saveData, gml_saveGear_inSlot );
}
};
}
};
var gmli = 0 ; for (; yyfless(gmli,array_length( yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in )) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
var gml_saveGear_inStorage = yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in)];
array_push( gml_saveData, gml_saveGear_inStorage );
}
};
array_push( gml_saveData, global.gmlxp_ );
gml_string=json_stringify( gml_saveData );
gml_buffer=buffer_create( yyfplus(__yy_gml_errCheck(string_byte_length( gml_string )),1), 0, 1 );
buffer_write( gml_buffer, 11, gml_string );
buffer_save( gml_buffer, "gearsave.factory" );
buffer_delete( gml_buffer );
}
function gml_Script____struct___0_gml_Object_o_Storeplace_Other_3( _inst, _other){ 
if (_inst.__yyIsGMLObject) { _inst.__type = "gml_Script____struct___0@gml_Object_o_Storeplace_Other_3"; }
if (gml_Script____struct___0_gml_Object_o_Storeplace_Other_3.prototype.__type === undefined) { gml_Script____struct___0_gml_Object_o_Storeplace_Other_3.prototype.__type = "gml_Script____struct___0@gml_Object_o_Storeplace_Other_3"; }{ 
if (_inst.__yyIsGMLObject) Object.setPrototypeOf( _inst, gml_Script____struct___0_gml_Object_o_Storeplace_Other_3.prototype);
{ var $$args = Array.prototype.slice.call(arguments);
{
_inst.gmlitem_base_crushing_power=$$args[__yy_gml_array_check_index(2+ (0), $$args)];
_inst.gmlitem_value=$$args[__yy_gml_array_check_index(2+ (1), $$args)];
_inst.gmlitem_amount=$$args[__yy_gml_array_check_index(2+ (2), $$args)];
_inst.gmlitem_unlock=$$args[__yy_gml_array_check_index(2+ (3), $$args)];
_inst.gmlitem_belt=$$args[__yy_gml_array_check_index(2+ (4), $$args)];
}
}
}
}

function gml_Script____struct___1_gml_Object_o_Storeplace_Other_3( _inst, _other){ 
if (_inst.__yyIsGMLObject) { _inst.__type = "gml_Script____struct___1@gml_Object_o_Storeplace_Other_3"; }
if (gml_Script____struct___1_gml_Object_o_Storeplace_Other_3.prototype.__type === undefined) { gml_Script____struct___1_gml_Object_o_Storeplace_Other_3.prototype.__type = "gml_Script____struct___1@gml_Object_o_Storeplace_Other_3"; }{ 
if (_inst.__yyIsGMLObject) Object.setPrototypeOf( _inst, gml_Script____struct___1_gml_Object_o_Storeplace_Other_3.prototype);
{ var $$args = Array.prototype.slice.call(arguments);
{
_inst.gmlid_=$$args[__yy_gml_array_check_index(2+ (0), $$args)];
_inst.gmllevel=$$args[__yy_gml_array_check_index(2+ (1), $$args)];
_inst.gmlcost=$$args[__yy_gml_array_check_index(2+ (2), $$args)];
_inst.gmlunlock=$$args[__yy_gml_array_check_index(2+ (3), $$args)];
}
}
}
}

function gml_Script____struct___2_gml_Object_o_Storeplace_Other_3( _inst, _other){ 
if (_inst.__yyIsGMLObject) { _inst.__type = "gml_Script____struct___2@gml_Object_o_Storeplace_Other_3"; }
if (gml_Script____struct___2_gml_Object_o_Storeplace_Other_3.prototype.__type === undefined) { gml_Script____struct___2_gml_Object_o_Storeplace_Other_3.prototype.__type = "gml_Script____struct___2@gml_Object_o_Storeplace_Other_3"; }{ 
if (_inst.__yyIsGMLObject) Object.setPrototypeOf( _inst, gml_Script____struct___2_gml_Object_o_Storeplace_Other_3.prototype);
{ var $$args = Array.prototype.slice.call(arguments);
{
_inst.gmlauto_crush_speed=$$args[__yy_gml_array_check_index(2+ (0), $$args)];
}
}
}
}


// #####################################################################################################
// show_debug_message(file_exists("materialsave.factory")); 
// if (file_exists("materialsave.factory")) { 
// 	var _buffer = buffer_load("materialsave.factory"); 
// 	var _string = buffer_read( _buffer, buffer_string); 
// 	buffer_delete(_buffer); 
// 	 
// 	var _loadData = json_parse(_string); 
// 	 
// 	for (var i = 0; i < array_length(item_database); i++) { 
// 		if (array_length(_loadData) > 0) { 
// 			var _loadMaterial = array_shift(_loadData); 
// 			if (variable_struct_exists(_loadMaterial,string(nameof(item_base_crushing_power)))) { 
// 				item_database[i].item_base_crushing_power = _loadMaterial.item_base_crushing_power; 
// 			} 
// 			if (variable_struct_exists(_loadMaterial,string(nameof(item_value)))) { 
// 				item_database[i].item_value = _loadMaterial.item_value; 
// 			} 
// 			if (variable_struct_exists(_loadMaterial,string(nameof(item_amount)))) { 
// 				item_database[i].item_amount = _loadMaterial.item_amount; 
// 			} 
// 			if (variable_struct_exists(_loadMaterial,string(nameof(item_unlock)))) { 
// 				item_database[i].item_unlock = _loadMaterial.item_unlock; 
// 			} 
// 			if (variable_struct_exists(_loadMaterial,string(nameof(item_belt)))) { 
// 				item_database[i].item_belt = _loadMaterial.item_belt; 
// 			} 
// 		} 
// 	} 
// } 
//  
//  
// if (file_exists("buttonsave.factory")) { 
// 	var _buffer = buffer_load("buttonsave.factory"); 
// 	var _string = buffer_read( _buffer, buffer_string); 
// 	buffer_delete(_buffer); 
// 	 
// 	var _loadData = json_parse(_string); 
// 	 
// 	max_button = instance_number(o_button); 
// 	 
// 	for (var i = 1; i <= max_button; i++) { 
// 		with (o_button) { 
// 			if (array_length(_loadData) > 0 && id_ != 0) { 
// 				var _loadButton = array_pop(_loadData); 
// 				show_debug_message(string(array_length(_loadData)) + " " + string(id_) + " " + string(_loadButton.id_)) 
// 				if (id_ == _loadButton.id_) { 
// 					if (variable_struct_exists(_loadButton,string(nameof(id_)))) { 
// 						id_ = _loadButton.id_ 
// 					} 
// 					if (variable_struct_exists(_loadButton,string(nameof(unlock)))) { 
// 						unlock = _loadButton.unlock; 
// 					} 
// 					if (variable_struct_exists(_loadButton,string(nameof(cost)))) { 
// 						cost = _loadButton.cost 
// 					} 
// 					if (variable_struct_exists(_loadButton,string(nameof(level)))) { 
// 						level = _loadButton.level 
// 					} 
// 					break; 
// 				} else { 
// 					array_push(_loadData,_loadButton)	 
// 				} 
// 			 
// 			} 
// 		} 
// 	} 
// } 
//  
// if (file_exists("autosave.factory")) { 
// 	var _buffer = buffer_load("autosave.factory"); 
// 	var _string = buffer_read( _buffer, buffer_string); 
// 	buffer_delete(_buffer); 
// 	 
// 	var _loadData = json_parse(_string); 
// 	 
// 	with (o_Autoclicker) { 
// 		var _loadAuto = array_pop(_loadData); 
// 		if (variable_struct_exists(_loadAuto,string(nameof(auto_crush_speed)))) { 
// 			auto_crush_speed = _loadAuto.auto_crush_speed; 
// 		} 
// 	} 
// } 
//  
// if (file_exists("ordersave.factory")) { 
// 	var _buffer = buffer_load("ordersave.factory"); 
// 	var _string = buffer_read( _buffer, buffer_string); 
// 	buffer_delete(_buffer); 
// 	 
// 	var _loadData = json_parse(_string); 
// 	 
// 	max_button = array_pop(_loadData); 
// 	 
// 	for (var i = array_length(o_Storeplace.button_unlock); i > 0; i--) { 
// 		var _loadOrder = array_pop(_loadData); 
// 		o_Storeplace.button_unlock[i-1] = _loadOrder; 
// 	} 
// 	for (var i = array_length(global.order); i > 0; i--) { 
// 		var _loadOrder = array_pop(_loadData); 
// 		global.order[i-1] = _loadOrder; 
// 	} 
// } 
//  
// if (file_exists("gearsave.factory")) { 
// 	var _buffer = buffer_load("gearsave.factory"); 
// 	var _string = buffer_read( _buffer, buffer_string); 
// 	buffer_delete(_buffer); 
// 	 
// 	var _loadData = json_parse(_string); 
// 	 
// 	global.xp_ = array_pop(_loadData); 
// 	 
// 	for (var i = 0; i < array_length(o_GearStorage.gears_in); i++) { 
// 		var _loadGear_inStorage = array_pop(_loadData); 
// 		o_GearStorage.gears_in[i] = _loadGear_inStorage; 
// 		//show_debug_message(_loadGear_inStorage) 
// 	} 
// 	 
// 	for (var i2 = 0; i2 < o_GearSlot.item_amount; i2++) { 
// 		for (var i = 0; i < array_length(o_GearSlot.gears_in); i++) { 
// 			var _loadGear_inSlot = array_shift(_loadData); 
// 			o_GearSlot.gears_in[i][i2] = _loadGear_inSlot; 
// 			//show_debug_message(_loadGear_inSlot)	 
// 		} 
// 	} 
// 		 
// 	o_GearSlot.amount_left = 0; 
// 	for (var i = 0; i < o_GearSlot.gear_slots; i++) { 
// 		if (o_GearSlot.gears_in[i][0] == -1) { 
// 			o_GearSlot.amount_left++; 
// 		} 
// 	} 
// }
function gml_Object_o_Storeplace_Other_2( _inst, _other )
{
show_debug_message( file_exists( "materialsave.factory" ) );
if ( yyGetBool(file_exists( "materialsave.factory" ))) {{
var gml_buffer = buffer_load( "materialsave.factory" );
var gml_string = buffer_read( gml_buffer, 11 );
buffer_delete( gml_buffer );
var gml_loadData = json_parse( gml_string );
var gmli = 0 ; for (; yyfless(gmli,array_length( _inst.gmlitem_database )) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfgreater(array_length( gml_loadData ),0)) {{
var gml_loadMaterial = array_shift( gml_loadData );
if ( yyGetBool(variable_struct_exists( gml_loadMaterial, string( "item_base_crushing_power" ) ))) {{
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(gmli, _inst.gmlitem_database)]).gmlitem_base_crushing_power=yyInst(_inst,_other,gml_loadMaterial).gmlitem_base_crushing_power;
}
;}
;
if ( yyGetBool(variable_struct_exists( gml_loadMaterial, string( "item_value" ) ))) {{
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(gmli, _inst.gmlitem_database)]).gmlitem_value=yyInst(_inst,_other,gml_loadMaterial).gmlitem_value;
}
;}
;
if ( yyGetBool(variable_struct_exists( gml_loadMaterial, string( "item_amount" ) ))) {{
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(gmli, _inst.gmlitem_database)]).gmlitem_amount=yyInst(_inst,_other,gml_loadMaterial).gmlitem_amount;
}
;}
;
if ( yyGetBool(variable_struct_exists( gml_loadMaterial, string( "item_unlock" ) ))) {{
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(gmli, _inst.gmlitem_database)]).gmlitem_unlock=yyInst(_inst,_other,gml_loadMaterial).gmlitem_unlock;
}
;}
;
if ( yyGetBool(variable_struct_exists( gml_loadMaterial, string( "item_belt" ) ))) {{
yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(gmli, _inst.gmlitem_database)]).gmlitem_belt=yyInst(_inst,_other,gml_loadMaterial).gmlitem_belt;
}
;}
;
}
;}
;
}
};
}
;}
;
if ( yyGetBool(file_exists( "buttonsave.factory" ))) {{
var gml_buffer = buffer_load( "buttonsave.factory" );
var gml_string = buffer_read( gml_buffer, 11 );
buffer_delete( gml_buffer );
var gml_loadData = json_parse( gml_string );
_inst.gmlmax_button=instance_number( YYASSET_REF(0x00000023) );
var gmli = 1 ; for (; yyflessequal(gmli,_inst.gmlmax_button) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
{
var __yy__v16 = GetWithArray(YYASSET_REF(0x00000023) );
for( var __yy__v17 in __yy__v16 ) {
 if (!__yy__v16.hasOwnProperty(__yy__v17)) continue;
 var __yy__v18 = __yy__v16[__yy__v17];
{
if ( (yyGetBool(yyfgreater(array_length( gml_loadData ),0))) && (yyGetBool(yyfnotequal(__yy__v18.gmlid_,0)))) {{
var gml_loadButton = array_pop( gml_loadData );
show_debug_message( yyfplus(yyfplus(yyfplus(yyfplus(__yy_gml_errCheck(string( array_length( gml_loadData ) ))," "),__yy_gml_errCheck(string( __yy__v18.gmlid_ )))," "),__yy_gml_errCheck(string( yyInst(_inst,_other,gml_loadButton).gmlid_ ))) );
if ( yyfequal(__yy__v18.gmlid_,yyInst(_inst,_other,gml_loadButton).gmlid_)) {{
if ( yyGetBool(variable_struct_exists( gml_loadButton, string( "id_" ) ))) {{
__yy__v18.gmlid_=yyInst(_inst,_other,gml_loadButton).gmlid_;
}
;}
;
if ( yyGetBool(variable_struct_exists( gml_loadButton, string( "unlock" ) ))) {{
__yy__v18.gmlunlock=yyInst(_inst,_other,gml_loadButton).gmlunlock;
}
;}
;
if ( yyGetBool(variable_struct_exists( gml_loadButton, string( "cost" ) ))) {{
__yy__v18.gmlcost=yyInst(_inst,_other,gml_loadButton).gmlcost;
}
;}
;
if ( yyGetBool(variable_struct_exists( gml_loadButton, string( "level" ) ))) {{
__yy__v18.gmllevel=yyInst(_inst,_other,gml_loadButton).gmllevel;
}
;}
;
break;
}
;}
 else {{
array_push( gml_loadData, gml_loadButton );
}
;};
}
;}
;
}
}
}
;
}
};
}
;}
;
if ( yyGetBool(file_exists( "autosave.factory" ))) {{
var gml_buffer = buffer_load( "autosave.factory" );
var gml_string = buffer_read( gml_buffer, 11 );
buffer_delete( gml_buffer );
var gml_loadData = json_parse( gml_string );
{
var __yy__v19 = GetWithArray(YYASSET_REF(0x0000000E) );
for( var __yy__v20 in __yy__v19 ) {
 if (!__yy__v19.hasOwnProperty(__yy__v20)) continue;
 var __yy__v21 = __yy__v19[__yy__v20];
{
var gml_loadAuto = array_pop( gml_loadData );
if ( yyGetBool(variable_struct_exists( gml_loadAuto, string( "auto_crush_speed" ) ))) {{
__yy__v21.gmlauto_crush_speed=yyInst(_inst,_other,gml_loadAuto).gmlauto_crush_speed;
}
;}
;
}
}
}
;
}
;}
;
if ( yyGetBool(file_exists( "ordersave.factory" ))) {{
var gml_buffer = buffer_load( "ordersave.factory" );
var gml_string = buffer_read( gml_buffer, 11 );
buffer_delete( gml_buffer );
var gml_loadData = json_parse( gml_string );
_inst.gmlmax_button=array_pop( gml_loadData );
var gmli = array_length( yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock ) ; for (; yyfgreater(gmli,0) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.subtract(1) : --gmli), g_yyPrePostObject__)) {{
var gml_loadOrder = array_pop( gml_loadData );
yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock = __yy_gml_array_check( yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock, 921409278 );
yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock[__yy_gml_array_check_index_set(yyfminus(__yy_gml_errCheck(gmli),1))]=gml_loadOrder;
}
};
var gmli = array_length( global.gmlorder ) ; for (; yyfgreater(gmli,0) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.subtract(1) : --gmli), g_yyPrePostObject__)) {{
var gml_loadOrder = array_pop( gml_loadData );
global.gmlorder = __yy_gml_array_check( global.gmlorder, 1472648720 );
global.gmlorder[__yy_gml_array_check_index_set(yyfminus(__yy_gml_errCheck(gmli),1))]=gml_loadOrder;
}
};
}
;}
;
if ( yyGetBool(file_exists( "gearsave.factory" ))) {{
var gml_buffer = buffer_load( "gearsave.factory" );
var gml_string = buffer_read( gml_buffer, 11 );
buffer_delete( gml_buffer );
var gml_loadData = json_parse( gml_string );
global.gmlxp_=array_pop( gml_loadData );
var gmli = 0 ; for (; yyfless(gmli,array_length( yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in )) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
var gml_loadGear_inStorage = array_pop( gml_loadData );
yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in = __yy_gml_array_check( yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in, 3164448915 );
yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in[__yy_gml_array_check_index_set(gmli)]=gml_loadGear_inStorage;
}
};
var gmli2 = 0 ; for (; yyfless(gmli2,yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlitem_amount) ; ( g_yyPrePostObject__ = gmli2, gmli2 = (g_yyPrePostObject__ instanceof Long ? gmli2.add(1) : ++gmli2), g_yyPrePostObject__)) {{
var gmli = 0 ; for (; yyfless(gmli,array_length( yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in )) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
var gml_loadGear_inSlot = array_shift( gml_loadData );
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in = __yy_gml_array_check( yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in, 903864995 );
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index_chain(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index_set(gmli2)]=gml_loadGear_inSlot;
}
};
}
};
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlamount_left=0;
var gmli = 0 ; for (; yyfless(gmli,yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[ ~~gmli ])],(-1))) {{
( g_yyPrePostObject__ = yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlamount_left, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlamount_left = (g_yyPrePostObject__ instanceof Long ? yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlamount_left.add(1) : ++yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlamount_left), g_yyPrePostObject__);
}
;}
;
}
};
}
;}
;
}

// #####################################################################################################
// draw_sprite(spr_paper,false,800*2,32*2); 
// draw_set_font(font1); 
// draw_text(824*2,32*2,item_database[0].item_amount); 
//  
// if (item_database[1].item_unlock == true) { 
// 	draw_sprite(spr_wood,false,800*2,64*2); 
// 	draw_text(824*2,64*2,item_database[1].item_amount); 
// }
function gml_Object_o_Storeplace_Draw_64( _inst, _other )
{
draw_sprite( _inst , YYASSET_REF(0x01000005), false, 1600, 64 );
draw_set_font( YYASSET_REF(0x07000000) );
draw_text( 1648, 64, yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(0, _inst.gmlitem_database)]).gmlitem_amount );
if ( yyfequal(yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_unlock,true)) {{
draw_sprite( _inst , YYASSET_REF(0x01000004), false, 1600, 128 );
draw_text( 1648, 128, yyInst(_inst,_other,_inst.gmlitem_database[__yy_gml_array_check_index(1, _inst.gmlitem_database)]).gmlitem_amount );
}
;}
;
}

// #####################################################################################################
// switch(window_get_fullscreen()) { 
// 	case true: 
// 		window_set_fullscreen(0); 
// 	break; 
// 	case false: 
// 		window_set_fullscreen(1); 
// 	break; 
// }
function gml_Object_o_Storeplace_KeyPress_112( _inst, _other )
{
var ___sw6___ = window_get_fullscreen(  ); 
var ___swc7___ = -1;
if (yyCompareVal(___sw6___,true,g_GMLMathEpsilon, false)==0) {
___swc7___ = 0;
}
else if (yyCompareVal(___sw6___,false,g_GMLMathEpsilon, false)==0) {
___swc7___ = 1;
}
switch( ___swc7___ ) {
case 0: {
window_set_fullscreen( 0 );
break;
}
case 1: {
window_set_fullscreen( 1 );
break;
}
}
;
}

// #####################################################################################################
// spawn_time = 60; 
// spawn_cooldown = false; 
//  
// amount_ = 0; 
//  
// global.order = array_create(10); 
//  
// for (var i = 0; i < array_length(global.order); i++) { 
// 	global.order[i] = 0;	 
// }
function gml_Object_o_spawner_Create_0( _inst, _other )
{
_inst.gmlspawn_time=60;
_inst.gmlspawn_cooldown=false;
_inst.gmlamount_=0;
global.gmlorder=array_create( 10 );
var gmli = 0 ; for (; yyfless(gmli,array_length( global.gmlorder )) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
global.gmlorder = __yy_gml_array_check( global.gmlorder, 1472648720 );
global.gmlorder[__yy_gml_array_check_index_set(gmli)]=0;
}
};
}

// #####################################################################################################
// spawn_cooldown = false;
function gml_Object_o_spawner_Alarm_0( _inst, _other )
{
_inst.gmlspawn_cooldown=false;
}

// #####################################################################################################
// if (spawn_cooldown == false && amount_ < 10 && instance_number(o_item) < 10) { 
// 	spawn_cooldown = true; 
// 	alarm_set(0,spawn_time); 
// 	var i = instance_create_layer(x,y,"Instances",o_item); 
// 	i.id_ = global.order[amount_]; 
// 	amount_++; 
// } 
//  
// if (amount_ == 10 && find_button(11).level == 1) { 
// 	amount_ = 0;	 
// }
function gml_Object_o_spawner_Step_0( _inst, _other )
{
if ( (yyGetBool(yyfequal(_inst.gmlspawn_cooldown,false))) && (yyGetBool(yyfless(_inst.gmlamount_,10))) && (yyGetBool(yyfless(instance_number( YYASSET_REF(0x00000006) ),10)))) {{
_inst.gmlspawn_cooldown=true;
alarm_set( _inst , 0, _inst.gmlspawn_time );
var gmli = instance_create_layer( _inst.x, _inst.y, "Instances", YYASSET_REF(0x00000006) );
yyInst(_inst,_other,gmli).gmlid_=global.gmlorder[__yy_gml_array_check_index(_inst.gmlamount_, global.gmlorder)];
( g_yyPrePostObject__ = _inst.gmlamount_, _inst.gmlamount_ = (g_yyPrePostObject__ instanceof Long ? _inst.gmlamount_.add(1) : ++_inst.gmlamount_), g_yyPrePostObject__);
}
;}
;
if ( (yyGetBool(yyfequal(_inst.gmlamount_,10))) && (yyGetBool(yyfequal(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 11 )).gmllevel,1)))) {{
_inst.gmlamount_=0;
}
;}
;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 20; 
// lock = 5;
function gml_Object_o_button_paper_20_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=20;
_inst.gmllock=5;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 14; 
// lock = 4;
function gml_Object_o_button_wood_14_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=14;
_inst.gmllock=4;
}

// #####################################################################################################
// base_y = y; 
// dir = 0; 
//  
// if (room_get_name(room) == "Room2") { 
// 	dir = 1; 
// 	image_angle = 180; 
// } 
// if (room_get_name(room) == "Room3") { 
// 	dir = 1; 
// 	image_angle = 270; 
// }
function gml_Object_o_ArrowToFactory_Create_0( _inst, _other )
{
_inst.gmlbase_y=_inst.y;
_inst.gmldir=0;
if ( yyfequal(room_get_name( g_pBuiltIn.get_current_room() ),"Room2")) {{
_inst.gmldir=1;
_inst.image_angle=180;
}
;}
;
if ( yyfequal(room_get_name( g_pBuiltIn.get_current_room() ),"Room3")) {{
_inst.gmldir=1;
_inst.image_angle=270;
}
;}
;
}

// #####################################################################################################
// if (dir == 0) { 
// 	y += 0.25;	 
// } 
// if (dir == 1) { 
// 	y -= 0.25;	 
// } 
//  
// if (y < base_y-5) { 
// 	dir = 0;	 
// }  
// if (y > base_y+5) { 
// 	dir = 1;	 
// }
function gml_Object_o_ArrowToFactory_Step_0( _inst, _other )
{
if ( yyfequal(_inst.gmldir,0)) {{
_inst.y=yyfplus(_inst.y,0.25);
}
;}
;
if ( yyfequal(_inst.gmldir,1)) {{
_inst.y=yyfminus(_inst.y,0.25);
}
;}
;
if ( yyfless(_inst.y,yyfminus(__yy_gml_errCheck(_inst.gmlbase_y),5))) {{
_inst.gmldir=0;
}
;}
;
if ( yyfgreater(_inst.y,yyfplus(__yy_gml_errCheck(_inst.gmlbase_y),5))) {{
_inst.gmldir=1;
}
;}
;
}

// #####################################################################################################
// room_goto(Room1);
function gml_Object_o_ArrowToFactory_Mouse_4( _inst, _other )
{
room_goto( YYASSET_REF(0x03000000) );
}

// #####################################################################################################
// image_speed = 0; 
// one_done = false;
function gml_Object_o_bg_crusher_Create_0( _inst, _other )
{
_inst.image_speed=0;
_inst.gmlone_done=false;
}

// #####################################################################################################
//  
// if (instance_exists(o_item)) { 
// 	var _item = instance_nearest(x+32,y+96,o_item).id_; 
// 	global.maximum_crush_needed = o_Storeplace.item_database[_item].item_crushing_power; 
//  
// 	if (instance_place(x,y,o_item)) { 
// 		var i = instance_place(x,y,o_item); 
// 		if (image_index >= 6 && image_index < 9) { 
// 			image_speed = 1; 
// 			global.crush_power = 0; 
// 			one_done = false; 
// 		} 
// 	 
// 		if (i.done == false && image_index >= 9 && one_done == false) { 
// 			i.done = true; 
// 			one_done = true; 
// 			if (find_button(20).level > 0) { 
// 				var chance = irandom_range(0,100) 
// 				if (find_button(20).level*5 >= chance) {  
// 					i.polished = 2; 
// 				} 
// 			} 
// 			image_speed = 1; 
// 		} 
// 	} 
// } 
//  
// if (image_index < 6) { 
// 	image_speed = 0; 
// 	var i = global.crush_power/global.maximum_crush_needed; 
// 	if (i > 1) { i = 0.9 }; 
// 	image_index = i*6; 
// }
function gml_Object_o_bg_crusher_Step_0( _inst, _other )
{
if ( yyGetBool(instance_exists( YYASSET_REF(0x00000006) ))) {{
var gml_item = yyInst(_inst,_other,instance_nearest( _inst , yyfplus(__yy_gml_errCheck(_inst.x),32), yyfplus(__yy_gml_errCheck(_inst.y),96), YYASSET_REF(0x00000006) )).gmlid_;
global.gmlmaximum_crush_needed=yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(gml_item, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_crushing_power;
if ( yyGetBool(instance_place( _inst , _inst.x, _inst.y, YYASSET_REF(0x00000006) ))) {{
var gmli = instance_place( _inst , _inst.x, _inst.y, YYASSET_REF(0x00000006) );
if ( (yyGetBool(yyfgreaterequal(_inst.image_index,6))) && (yyGetBool(yyfless(_inst.image_index,9)))) {{
_inst.image_speed=1;
global.gmlcrush_power=0;
_inst.gmlone_done=false;
}
;}
;
if ( (yyGetBool(yyfequal(yyInst(_inst,_other,gmli).gmldone,false))) && (yyGetBool(yyfgreaterequal(_inst.image_index,9))) && (yyGetBool(yyfequal(_inst.gmlone_done,false)))) {{
yyInst(_inst,_other,gmli).gmldone=true;
_inst.gmlone_done=true;
if ( yyfgreater(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 20 )).gmllevel,0)) {{
var gmlchance = irandom_range( 0, 100 );
if ( yyfgreaterequal(yyftime(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 20 )).gmllevel),5),gmlchance)) {{
yyInst(_inst,_other,gmli).gmlpolished=2;
}
;}
;
}
;}
;
_inst.image_speed=1;
}
;}
;
}
;}
;
}
;}
;
if ( yyfless(_inst.image_index,6)) {{
_inst.image_speed=0;
var gmli = yyfdivide(__yy_gml_errCheck(global.gmlcrush_power),__yy_gml_errCheck(global.gmlmaximum_crush_needed));
if ( yyfgreater(gmli,1)) {{
gmli=0.9;
}
;}
;
_inst.image_index=yyftime(__yy_gml_errCheck(gmli),6);
}
;}
;
}

// #####################################################################################################
// id_ = -1; 
// done = false; 
// polished = 1;
function gml_Object_o_item_Create_0( _inst, _other )
{
_inst.gmlid_=(-1);
_inst.gmldone=false;
_inst.gmlpolished=1;
}

// #####################################################################################################
// if (done == false and id_ != -1) { 
// 	var i = o_Storeplace.item_database[id_]; 
// 	sprite_index = i.item_sprite; 
// } 
//  
// if (done == true) { 
// 	var i = o_Storeplace.item_database[id_]; 
// 	sprite_index = i.item_sprite_crushed;	 
// } 
//  
// if (!instance_place(x,y,o_bg_conveyorbelt)) { 
// 	y += 3; 
// } 
//  
// if (instance_place(x,y,o_stop) || instance_place(x+9,y,o_item)) { 
// 	if (done = true) { 
// 		x += 4;	 
// 	} 
// } else { 
// 	x += 4;		 
// } 
//  
// // Adding Items 
// if (instance_place(x,y,o_destroyer)) { 
// 	var v = 0; 
// 	// Pressure Value 
// 	if (find_button(18).level > 0) { 
// 		v += floor(o_Storeplace.item_database[id_].item_crushing_power/100)	 
// 		 
// 		// Capping Pressure Value 
// 		if (v > find_button(18).level*25) { 
// 			v = find_button(18).level*25 + round((v-find_button(18).level*25)/(v*v*0.5)) 
// 		} 
// 	} 
// 	o_Storeplace.item_database[id_].item_amount += (floor(o_Storeplace.item_database[id_].item_value)+v)*polished; // Adding the items 
// 	 
// 	// Wooden Paper 
// 	if (find_button(10).level > 0 && id_ == 0) { 
// 		var i = irandom_range(find_button(10).level,10) 
// 		if (i == 10) { 
// 			o_Storeplace.item_database[1].item_amount += 1; 
// 		} 
// 	} 
// 	instance_destroy();	 
// }
function gml_Object_o_item_Step_0( _inst, _other )
{
if ( (yyGetBool(yyfequal(_inst.gmldone,false))) && (yyGetBool(yyfnotequal(_inst.gmlid_,(-1))))) {{
var gmli = yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(_inst.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)];
_inst.sprite_index=yyInst(_inst,_other,gmli).gmlitem_sprite;
}
;}
;
if ( yyfequal(_inst.gmldone,true)) {{
var gmli = yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(_inst.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)];
_inst.sprite_index=yyInst(_inst,_other,gmli).gmlitem_sprite_crushed;
}
;}
;
if ( !yyGetBool(instance_place( _inst , _inst.x, _inst.y, YYASSET_REF(0x0000001D) ))) {{
_inst.y=yyfplus(_inst.y,3);
}
;}
;
if ( (yyGetBool(instance_place( _inst , _inst.x, _inst.y, YYASSET_REF(0x00000011) ))) || (yyGetBool(instance_place( _inst , yyfplus(__yy_gml_errCheck(_inst.x),9), _inst.y, YYASSET_REF(0x00000006) )))) {{
if ( yyfequal(_inst.gmldone,true)) {{
_inst.x=yyfplus(_inst.x,4);
}
;}
;
}
;}
 else {{
_inst.x=yyfplus(_inst.x,4);
}
;};
if ( yyGetBool(instance_place( _inst , _inst.x, _inst.y, YYASSET_REF(0x0000002F) ))) {{
var gmlv = 0;
if ( yyfgreater(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 18 )).gmllevel,0)) {{
gmlv=yyfplus(gmlv,floor( yyfdivide(__yy_gml_errCheck(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(_inst.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_crushing_power),100) ));
if ( yyfgreater(gmlv,yyftime(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 18 )).gmllevel),25))) {{
gmlv=yyfplus(__yy_gml_errCheck(yyftime(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 18 )).gmllevel),25)),__yy_gml_errCheck(round( yyfdivide(__yy_gml_errCheck(yyfminus(__yy_gml_errCheck(gmlv),__yy_gml_errCheck(yyftime(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 18 )).gmllevel),25)))),__yy_gml_errCheck(yyftime(yyftime(__yy_gml_errCheck(gmlv),__yy_gml_errCheck(gmlv)),0.5))) )));
}
;}
;
}
;}
;
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(_inst.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfplus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(_inst.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,yyftime(__yy_gml_errCheck(yyfplus(__yy_gml_errCheck(floor( yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(_inst.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_value )),__yy_gml_errCheck(gmlv))),__yy_gml_errCheck(_inst.gmlpolished)));
if ( (yyGetBool(yyfgreater(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 10 )).gmllevel,0))) && (yyGetBool(yyfequal(_inst.gmlid_,0)))) {{
var gmli = irandom_range( yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 10 )).gmllevel, 10 );
if ( yyfequal(gmli,10)) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfplus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,1);
}
;}
;
}
;}
;
instance_destroy( _inst  );
}
;}
;
}

// #####################################################################################################
// draw_self(); 
//  
// if (polished > 1) { 
// 	draw_sprite_ext(sprite_index,image_index,x,y,image_xscale,image_yscale,image_angle,c_aqua,0.5);	 
// } 
// 
function gml_Object_o_item_Draw_0( _inst, _other )
{
draw_self( _inst  );
if ( yyfgreater(_inst.gmlpolished,1)) {{
draw_sprite_ext( _inst , _inst.sprite_index, _inst.image_index, _inst.x, _inst.y, _inst.image_xscale, _inst.image_yscale, _inst.image_angle, 16776960, 0.5 );
}
;}
;
}

// #####################################################################################################
// id_ = -1; 
// item_ = -1;
function gml_Object_o_Sorter_Create_0( _inst, _other )
{
_inst.gmlid_=(-1);
_inst.gmlitem_=(-1);
}

// #####################################################################################################
// if (item_ == -1) { 
// 	item_ = global.order[id_-1] 
// } 
//  
// if (id_ != -1) { 
// 	image_index = id_-1;	 
// } 
//  
// global.order[id_-1] = item_;
function gml_Object_o_Sorter_Step_0( _inst, _other )
{
if ( yyfequal(_inst.gmlitem_,(-1))) {{
_inst.gmlitem_=global.gmlorder[__yy_gml_array_check_index(yyfminus(__yy_gml_errCheck(_inst.gmlid_),1), global.gmlorder)];
}
;}
;
if ( yyfnotequal(_inst.gmlid_,(-1))) {{
_inst.image_index=yyfminus(__yy_gml_errCheck(_inst.gmlid_),1);
}
;}
;
global.gmlorder = __yy_gml_array_check( global.gmlorder, 1472648720 );
global.gmlorder[__yy_gml_array_check_index_set(yyfminus(__yy_gml_errCheck(_inst.gmlid_),1))]=_inst.gmlitem_;
}

// #####################################################################################################
// if (o_Giver.id_ > -1 && o_Giver.id_ != item_) { 
// 	item_ = o_Giver.id_; 
// 	o_Giver.id_ = -1; 
// }
function gml_Object_o_Sorter_Mouse_4( _inst, _other )
{
if ( (yyGetBool(yyfgreater(yyInst(_inst,_other,YYASSET_REF(0x00000024)).gmlid_,(-1)))) && (yyGetBool(yyfnotequal(yyInst(_inst,_other,YYASSET_REF(0x00000024)).gmlid_,_inst.gmlitem_)))) {{
_inst.gmlitem_=yyInst(_inst,_other,YYASSET_REF(0x00000024)).gmlid_;
yyInst(_inst,_other,YYASSET_REF(0x00000024)).gmlid_=(-1);
}
;}
;
}

// #####################################################################################################
// draw_self(); 
// draw_set_alpha(0.65); 
// draw_sprite(o_Storeplace.item_database[item_].item_sprite,0,x,y) 
// draw_set_alpha(1);
function gml_Object_o_Sorter_Draw_0( _inst, _other )
{
draw_self( _inst  );
draw_set_alpha( 0.65 );
draw_sprite( _inst , yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(_inst.gmlitem_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_sprite, 0, _inst.x, _inst.y );
draw_set_alpha( 1 );
}

// #####################################################################################################
// text = "";
function gml_Object_o_button_1_text_Create_0( _inst, _other )
{
_inst.gmltext="";
}

// #####################################################################################################
// image_alpha -= 0.05; 
// if (image_alpha <= 0) { 
// 	instance_destroy();	 
// } 
// y -= 3;
function gml_Object_o_button_1_text_Step_0( _inst, _other )
{
_inst.image_alpha=yyfminus(_inst.image_alpha,0.05);
if ( yyflessequal(_inst.image_alpha,0)) {{
instance_destroy( _inst  );
}
;}
;
_inst.y=yyfminus(_inst.y,3);
}

// #####################################################################################################
// draw_set_alpha(image_alpha); 
// draw_set_font(font2); 
// draw_text(x,y,"+" + string(text)); 
// draw_set_alpha(1);
function gml_Object_o_button_1_text_Draw_0( _inst, _other )
{
draw_set_alpha( _inst.image_alpha );
draw_set_font( YYASSET_REF(0x07000001) );
draw_text( _inst.x, _inst.y, yyfplus("+",__yy_gml_errCheck(string( _inst.gmltext ))) );
draw_set_alpha( 1 );
}

// #####################################################################################################
// clicks_ = 0; 
// og_ = image_xscale; 
// prestige_ = false; 
// minimum = 20;
function gml_Object_o_Pressurizer_Create_0( _inst, _other )
{
_inst.gmlclicks_=0;
_inst.gmlog_=_inst.image_xscale;
_inst.gmlprestige_=false;
_inst.gmlminimum=20;
}

// #####################################################################################################
// randomize(); 
//  
// if (global.xp_ >= minimum) { 
// 	var i = instance_create_layer(x,y-32,"Instances_1",o_Gears); 
// 	if (prestige_ = false) { 
// 		i.id_ = 4; 
// 		prestige_ = true; 
// 	} else { 
// 		i.id_ = irandom_range(1,4); 
// 	} 
// 	i.level_ = irandom_range(1+floor(global.xp_/1.5),global.xp_); 
//  
// 	global.xp_ -= i.level_; 
//  
// 	if (global.xp_ > 0) { 
// 		alarm_set(0,10); 
// 	} 
// }
function gml_Object_o_Pressurizer_Alarm_0( _inst, _other )
{
randomize(  );
if ( yyfgreaterequal(global.gmlxp_,_inst.gmlminimum)) {{
var gmli = instance_create_layer( _inst.x, yyfminus(__yy_gml_errCheck(_inst.y),32), "Instances_1", YYASSET_REF(0x00000034) );
if ( yyfequal(_inst.gmlprestige_,false)) {{
yyInst(_inst,_other,gmli).gmlid_=4;
_inst.gmlprestige_=true;
}
;}
 else {{
yyInst(_inst,_other,gmli).gmlid_=irandom_range( 1, 4 );
}
;};
yyInst(_inst,_other,gmli).gmllevel_=irandom_range( yyfplus(1,__yy_gml_errCheck(floor( yyfdivide(__yy_gml_errCheck(global.gmlxp_),1.5) ))), global.gmlxp_ );
global.gmlxp_=yyfminus(global.gmlxp_,yyInst(_inst,_other,gmli).gmllevel_);
if ( yyfgreater(global.gmlxp_,0)) {{
alarm_set( _inst , 0, 10 );
}
;}
;
}
;}
;
}

// #####################################################################################################
// if (image_xscale < og_) { 
// 	image_xscale += 0.05;	 
// }
function gml_Object_o_Pressurizer_Step_0( _inst, _other )
{
if ( yyfless(_inst.image_xscale,_inst.gmlog_)) {{
_inst.image_xscale=yyfplus(_inst.image_xscale,0.05);
}
;}
;
}

// #####################################################################################################
// clicks_ = 0;
function gml_Object_o_Pressurizer_Mouse_11( _inst, _other )
{
_inst.gmlclicks_=0;
}

// #####################################################################################################
// clicks_++; 
//  
// image_xscale -= 0.2; 
//  
// if (clicks_ > 9 && global.xp_ >= minimum) { 
// 	prestige_ = false; 
// 	//PRESTIGE 
// 	with (o_button) { 
// 		if (level != 0) { 
// 			level = 0;	 
// 		} 
// 		unlock = false; 
// 	} 
// 	for (var i = 0; i < array_length(o_Storeplace.item_database); i++) { 
// 		o_Storeplace.item_database[i].item_amount = 0; 
// 		o_Storeplace.item_database[i].item_belt = 0; 
// 	} 
// 	for (var i = 0; i < array_length(global.order); i++) { 
// 		global.order[i] = 0; 
// 	} 
// 	o_Storeplace.item_database[0].item_belt = 10; 
// 	 
// 	//NEW GEARS 
// 	alarm_set(0,10); 
// 	 
// 	clicks_ = 0; 
// } else if (clicks_ > 9) { 
// 	clicks_ = 0;	 
// }
function gml_Object_o_Pressurizer_Mouse_4( _inst, _other )
{
( g_yyPrePostObject__ = _inst.gmlclicks_, _inst.gmlclicks_ = (g_yyPrePostObject__ instanceof Long ? _inst.gmlclicks_.add(1) : ++_inst.gmlclicks_), g_yyPrePostObject__);
_inst.image_xscale=yyfminus(_inst.image_xscale,0.2);
if ( (yyGetBool(yyfgreater(_inst.gmlclicks_,9))) && (yyGetBool(yyfgreaterequal(global.gmlxp_,_inst.gmlminimum)))) {{
_inst.gmlprestige_=false;
{
var __yy__v22 = GetWithArray(YYASSET_REF(0x00000023) );
for( var __yy__v23 in __yy__v22 ) {
 if (!__yy__v22.hasOwnProperty(__yy__v23)) continue;
 var __yy__v24 = __yy__v22[__yy__v23];
{
if ( yyfnotequal(__yy__v24.gmllevel,0)) {{
__yy__v24.gmllevel=0;
}
;}
;
__yy__v24.gmlunlock=false;
}
}
}
;
var gmli = 0 ; for (; yyfless(gmli,array_length( yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database )) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=0;
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_belt=0;
}
};
var gmli = 0 ; for (; yyfless(gmli,array_length( global.gmlorder )) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
global.gmlorder = __yy_gml_array_check( global.gmlorder, 1472648720 );
global.gmlorder[__yy_gml_array_check_index_set(gmli)]=0;
}
};
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_belt=10;
alarm_set( _inst , 0, 10 );
_inst.gmlclicks_=0;
}
;}
 else {if ( yyfgreater(_inst.gmlclicks_,9)) {{
_inst.gmlclicks_=0;
}
;}
;};
}

// #####################################################################################################
// draw_sprite_ext(sprite_index,0,x,y,image_xscale,image_yscale,0,c_white,1); 
// draw_text(x-107,y+56,"Prestige XP: " + string(global.xp_) + "/" + string(minimum)); 
// draw_healthbar(x-56,y-144,x+56,y-144-16,(10-clicks_)*10,c_blue,c_aqua,c_aqua,0,1,0); 
// draw_text(x-64,y-144-32,"Click to Prestige");
function gml_Object_o_Pressurizer_Draw_0( _inst, _other )
{
draw_sprite_ext( _inst , _inst.sprite_index, 0, _inst.x, _inst.y, _inst.image_xscale, _inst.image_yscale, 0, 16777215, 1 );
draw_text( yyfminus(__yy_gml_errCheck(_inst.x),107), yyfplus(__yy_gml_errCheck(_inst.y),56), yyfplus(yyfplus(yyfplus("Prestige XP: ",__yy_gml_errCheck(string( global.gmlxp_ ))),"/"),__yy_gml_errCheck(string( _inst.gmlminimum ))) );
draw_healthbar( yyfminus(__yy_gml_errCheck(_inst.x),56), yyfminus(__yy_gml_errCheck(_inst.y),144), yyfplus(__yy_gml_errCheck(_inst.x),56), yyfminus(yyfminus(__yy_gml_errCheck(_inst.y),144),16), yyftime(__yy_gml_errCheck(yyfminus(10,__yy_gml_errCheck(_inst.gmlclicks_))),10), 16711680, 16776960, 16776960, 0, 1, 0 );
draw_text( yyfminus(__yy_gml_errCheck(_inst.x),64), yyfminus(yyfminus(__yy_gml_errCheck(_inst.y),144),32), "Click to Prestige" );
}

// #####################################################################################################
// event_inherited(); 
// lock = 0; 
//  
// activated_ = false;
function gml_Object_o_button_paper_menu_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmllock=0;
_inst.gmlactivated_=false;
}

// #####################################################################################################
// image_xscale = 0.5; 
// image_yscale = 0.5;
function gml_Object_o_button_paper_menu_Step_2( _inst, _other )
{
_inst.image_xscale=0.5;
_inst.image_yscale=0.5;
}

// #####################################################################################################
// if (unlock == true) { 
// 	switch(activated_) { 
// 		case true: 
// 			activated_ = false; 
// 			o_button_paper.on = false; 
// 		break; 
// 		case false: 
// 			activated_ = true; 
// 			o_button_paper.on = true; 
// 		break; 
// 	} 
//  
// 	if (o_button_auto_menu.activated_ == true) { 
// 		o_button_auto_menu.activated_ = false; 
// 		o_button_auto.on = false; 
// 	} 
// 	if (o_button_wood_menu.activated_ == true) { 
// 		o_button_wood_menu.activated_ = false; 
// 		o_button_wood.on = false; 
// 	} 
// }
function gml_Object_o_button_paper_menu_Mouse_4( _inst, _other )
{
if ( yyfequal(_inst.gmlunlock,true)) {{
var ___sw10___ = _inst.gmlactivated_; 
var ___swc11___ = -1;
if (yyCompareVal(___sw10___,true,g_GMLMathEpsilon, false)==0) {
___swc11___ = 0;
}
else if (yyCompareVal(___sw10___,false,g_GMLMathEpsilon, false)==0) {
___swc11___ = 1;
}
switch( ___swc11___ ) {
case 0: {
_inst.gmlactivated_=false;
yyInst(_inst,_other,YYASSET_REF(0x0000002A)).gmlon=false;
break;
}
case 1: {
_inst.gmlactivated_=true;
yyInst(_inst,_other,YYASSET_REF(0x0000002A)).gmlon=true;
break;
}
}
;
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000018)).gmlactivated_,true)) {{
yyInst(_inst,_other,YYASSET_REF(0x00000018)).gmlactivated_=false;
yyInst(_inst,_other,YYASSET_REF(0x0000001A)).gmlon=false;
}
;}
;
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000030)).gmlactivated_,true)) {{
yyInst(_inst,_other,YYASSET_REF(0x00000030)).gmlactivated_=false;
yyInst(_inst,_other,YYASSET_REF(0x00000010)).gmlon=false;
}
;}
;
}
;}
;
}

// #####################################################################################################
// if (activated_ == true) { 
// 	draw_set_color(c_black); 
// 	draw_rectangle(0,0,room_width,room_height,false); 
// 	draw_set_color(c_white); 
// } 
//  
// if (unlock == true) { 
// 	draw_self(); 
// 	var i = 0.75; 
// 	draw_sprite_ext(spr_paper,false,x+(32*i*image_xscale)+3,y+(32*i*image_yscale),i*image_xscale,i*image_xscale,0,c_white,1) 
// }
function gml_Object_o_button_paper_menu_Draw_0( _inst, _other )
{
if ( yyfequal(_inst.gmlactivated_,true)) {{
draw_set_color( 0 );
draw_rectangle( 0, 0, g_pBuiltIn.room_width, g_pBuiltIn.room_height, false );
draw_set_color( 16777215 );
}
;}
;
if ( yyfequal(_inst.gmlunlock,true)) {{
draw_self( _inst  );
var gmli = 0.75;
draw_sprite_ext( _inst , YYASSET_REF(0x01000005), false, yyfplus(yyfplus(__yy_gml_errCheck(_inst.x),__yy_gml_errCheck(yyftime(yyftime(32,__yy_gml_errCheck(gmli)),__yy_gml_errCheck(_inst.image_xscale)))),3), yyfplus(__yy_gml_errCheck(_inst.y),__yy_gml_errCheck(yyftime(yyftime(32,__yy_gml_errCheck(gmli)),__yy_gml_errCheck(_inst.image_yscale)))), yyftime(__yy_gml_errCheck(gmli),__yy_gml_errCheck(_inst.image_xscale)), yyftime(__yy_gml_errCheck(gmli),__yy_gml_errCheck(_inst.image_xscale)), 0, 16777215, 1 );
}
;}
;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 1; 
// lock = -1; 
// on = true;
function gml_Object_o_button_1_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=1;
_inst.gmllock=(-1);
_inst.gmlon=true;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 19; 
// lock = 4;
function gml_Object_o_button_auto_19_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=19;
_inst.gmllock=4;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 16; 
// lock = 5;
function gml_Object_o_button_paper_16_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=16;
_inst.gmllock=5;
}

// #####################################################################################################
// auto_crush_speed = 60; 
//  
// alarm_set(0,auto_crush_speed);
function gml_Object_o_Autoclicker_Create_0( _inst, _other )
{
_inst.gmlauto_crush_speed=60;
alarm_set( _inst , 0, _inst.gmlauto_crush_speed );
}

// #####################################################################################################
// var i = find_button(3).level + find_button(6).level*o_Storeplace.item_database[1].item_amount + find_button(19).level; 
//  
// if (global.crush_power + i >= global.maximum_crush_needed) { 
// 	global.crush_power = global.maximum_crush_needed; 
// } else { 
// 	global.crush_power += i; 
// } 
//  
// alarm_set(0,auto_crush_speed);
function gml_Object_o_Autoclicker_Alarm_0( _inst, _other )
{
var gmli = yyfplus(yyfplus(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 3 )).gmllevel),__yy_gml_errCheck(yyftime(__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 6 )).gmllevel),__yy_gml_errCheck(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount)))),__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 19 )).gmllevel));
if ( yyfgreaterequal(yyfplus(__yy_gml_errCheck(global.gmlcrush_power),__yy_gml_errCheck(gmli)),global.gmlmaximum_crush_needed)) {{
global.gmlcrush_power=global.gmlmaximum_crush_needed;
}
;}
 else {{
global.gmlcrush_power=yyfplus(global.gmlcrush_power,gmli);
}
;};
alarm_set( _inst , 0, _inst.gmlauto_crush_speed );
}

// #####################################################################################################
// event_inherited(); 
// id_ = 12; 
// lock = 3;
function gml_Object_o_button_paper_12_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=12;
_inst.gmllock=3;
}

// #####################################################################################################
// if (o_button_wood.on == true) { 
// 	on = true;	 
// } else { 
// 	on = false;	 
// }
function gml_Object_o_button_wood_Step_2( _inst, _other )
{
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000010)).gmlon,true)) {{
_inst.gmlon=true;
}
;}
 else {{
_inst.gmlon=false;
}
;};
}

// #####################################################################################################
// event_inherited(); 
// id_ = 2; 
// lock = -1; 
// on = true;
function gml_Object_o_button_2_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=2;
_inst.gmllock=(-1);
_inst.gmlon=true;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 6; 
// lock = 2;
function gml_Object_o_button_wood_6_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=6;
_inst.gmllock=2;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 15; 
// lock = 4;
function gml_Object_o_button_paper_15_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=15;
_inst.gmllock=4;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 9; 
// lock = 2;
function gml_Object_o_button_wood_9_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=9;
_inst.gmllock=2;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 18; 
// lock = 5; 
// prestige = false;
function gml_Object_o_button_wood_18_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=18;
_inst.gmllock=5;
_inst.gmlprestige=false;
}

// #####################################################################################################
// event_inherited(); 
// lock = -1; 
//  
// activated_ = false;
function gml_Object_o_button_auto_menu_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmllock=(-1);
_inst.gmlactivated_=false;
}

// #####################################################################################################
// image_xscale = 0.5; 
// image_yscale = 0.5;
function gml_Object_o_button_auto_menu_Step_2( _inst, _other )
{
_inst.image_xscale=0.5;
_inst.image_yscale=0.5;
}

// #####################################################################################################
// switch(activated_) { 
// 	case true: 
// 		activated_ = false; 
// 		o_button_auto.on = false; 
// 	break; 
// 	case false: 
// 		activated_ = true; 
// 		o_button_auto.on = true; 
// 	break; 
// } 
//  
// if (o_button_paper_menu.activated_ == true) { 
// 	o_button_paper_menu.activated_ = false; 
// 	o_button_paper.on = false; 
// } 
//  
// if (o_button_wood_menu.activated_ == true) { 
// 	o_button_wood_menu.activated_ = false; 
// 	o_button_wood.on = false; 
// }
function gml_Object_o_button_auto_menu_Mouse_4( _inst, _other )
{
var ___sw14___ = _inst.gmlactivated_; 
var ___swc15___ = -1;
if (yyCompareVal(___sw14___,true,g_GMLMathEpsilon, false)==0) {
___swc15___ = 0;
}
else if (yyCompareVal(___sw14___,false,g_GMLMathEpsilon, false)==0) {
___swc15___ = 1;
}
switch( ___swc15___ ) {
case 0: {
_inst.gmlactivated_=false;
yyInst(_inst,_other,YYASSET_REF(0x0000001A)).gmlon=false;
break;
}
case 1: {
_inst.gmlactivated_=true;
yyInst(_inst,_other,YYASSET_REF(0x0000001A)).gmlon=true;
break;
}
}
;
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x0000000A)).gmlactivated_,true)) {{
yyInst(_inst,_other,YYASSET_REF(0x0000000A)).gmlactivated_=false;
yyInst(_inst,_other,YYASSET_REF(0x0000002A)).gmlon=false;
}
;}
;
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000030)).gmlactivated_,true)) {{
yyInst(_inst,_other,YYASSET_REF(0x00000030)).gmlactivated_=false;
yyInst(_inst,_other,YYASSET_REF(0x00000010)).gmlon=false;
}
;}
;
}

// #####################################################################################################
// if (activated_ == true) { 
// 	draw_set_color(c_black); 
// 	draw_rectangle(0,0,room_width,room_height,false); 
// 	draw_set_color(c_white); 
// } 
//  
// if (unlock == true) { 
// 	draw_self(); 
// 	var i = 0.75; 
// 	draw_sprite_ext(spr_bg_conveyorbelt,false,x+(32*i*image_xscale)-8,y+(32*i*image_yscale)-8,i*image_xscale,i*image_xscale,0,c_white,1) 
// }
function gml_Object_o_button_auto_menu_Draw_0( _inst, _other )
{
if ( yyfequal(_inst.gmlactivated_,true)) {{
draw_set_color( 0 );
draw_rectangle( 0, 0, g_pBuiltIn.room_width, g_pBuiltIn.room_height, false );
draw_set_color( 16777215 );
}
;}
;
if ( yyfequal(_inst.gmlunlock,true)) {{
draw_self( _inst  );
var gmli = 0.75;
draw_sprite_ext( _inst , YYASSET_REF(0x01000010), false, yyfminus(yyfplus(__yy_gml_errCheck(_inst.x),__yy_gml_errCheck(yyftime(yyftime(32,__yy_gml_errCheck(gmli)),__yy_gml_errCheck(_inst.image_xscale)))),8), yyfminus(yyfplus(__yy_gml_errCheck(_inst.y),__yy_gml_errCheck(yyftime(yyftime(32,__yy_gml_errCheck(gmli)),__yy_gml_errCheck(_inst.image_yscale)))),8), yyftime(__yy_gml_errCheck(gmli),__yy_gml_errCheck(_inst.image_xscale)), yyftime(__yy_gml_errCheck(gmli),__yy_gml_errCheck(_inst.image_xscale)), 0, 16777215, 1 );
}
;}
;
}

// #####################################################################################################
// if (o_button_auto.on == true) { 
// 	on = true;	 
// } else { 
// 	on = false;	 
// }
function gml_Object_o_button_auto_Step_2( _inst, _other )
{
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x0000001A)).gmlon,true)) {{
_inst.gmlon=true;
}
;}
 else {{
_inst.gmlon=false;
}
;};
}

// #####################################################################################################
// event_inherited(); 
// id_ = 5; 
// lock = 1;
function gml_Object_o_button_paper_5_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=5;
_inst.gmllock=1;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 4; 
// lock = 0;
function gml_Object_o_button_paper_4_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=4;
_inst.gmllock=0;
}

// #####################################################################################################
// id_ = -1; 
// left_ = 0; 
// lock_ = true;
function gml_Object_o_SorterGiver_Create_0( _inst, _other )
{
_inst.gmlid_=(-1);
_inst.gmlleft_=0;
_inst.gmllock_=true;
}

// #####################################################################################################
// var id__ = id_; 
//  
// left_ = o_Storeplace.item_database[id_].item_belt; 
//  
// if (left_ > 0) { 
// 	lock_ = false;	 
// } 
//  
// for (var i = 0; i < array_length(global.order); i++) { 
// 	if (global.order[i] == id_) { 
// 		left_--;	 
// 	} 
// } 
// 
function gml_Object_o_SorterGiver_Step_0( _inst, _other )
{
var gmlid__ = _inst.gmlid_;
_inst.gmlleft_=yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(_inst.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_belt;
if ( yyfgreater(_inst.gmlleft_,0)) {{
_inst.gmllock_=false;
}
;}
;
var gmli = 0 ; for (; yyfless(gmli,array_length( global.gmlorder )) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfequal(global.gmlorder[__yy_gml_array_check_index(gmli, global.gmlorder)],_inst.gmlid_)) {{
( g_yyPrePostObject__ = _inst.gmlleft_, _inst.gmlleft_ = (g_yyPrePostObject__ instanceof Long ? _inst.gmlleft_.subtract(1) : --_inst.gmlleft_), g_yyPrePostObject__);
}
;}
;
}
};
}

// #####################################################################################################
// if (id_ > -1 && left_ > 0) { 
// 	o_Giver.id_ = id_; 
// }
function gml_Object_o_SorterGiver_Mouse_4( _inst, _other )
{
if ( (yyGetBool(yyfgreater(_inst.gmlid_,(-1)))) && (yyGetBool(yyfgreater(_inst.gmlleft_,0)))) {{
yyInst(_inst,_other,YYASSET_REF(0x00000024)).gmlid_=_inst.gmlid_;
}
;}
;
}

// #####################################################################################################
// if (lock_ == false) { 
// 	draw_self(); 
// 	draw_sprite(o_Storeplace.item_database[id_].item_sprite,0,x+32,y+32) 
// 	draw_text(x,y,string(left_) + "/" + string(o_Storeplace.item_database[id_].item_belt)) 
// }
function gml_Object_o_SorterGiver_Draw_0( _inst, _other )
{
if ( yyfequal(_inst.gmllock_,false)) {{
draw_self( _inst  );
draw_sprite( _inst , yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(_inst.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_sprite, 0, yyfplus(__yy_gml_errCheck(_inst.x),32), yyfplus(__yy_gml_errCheck(_inst.y),32) );
draw_text( _inst.x, _inst.y, yyfplus(yyfplus(__yy_gml_errCheck(string( _inst.gmlleft_ )),"/"),__yy_gml_errCheck(string( yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(_inst.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_belt ))) );
}
;}
;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 7; 
// lock = 2;
function gml_Object_o_button_paper_7_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=7;
_inst.gmllock=2;
}

// #####################################################################################################
// gear_slots = 100; 
//  
// gear = function(_x, _y, _id, _level, _value) constructor { 
// 	x_ = _x; 
// 	y_ = _y; 
// 	id_ = _id; 
// 	level_ = _level; 
// 	value_ = _value; 
// } 
//  
// gears_in[gear_slots-1] = -1; 
//  
// for (var i = 0; i < gear_slots; i++) { 
// 	gears_in[i] = -1; 
// } 
//  
// current_item = 0; 
// amount_left = 0;
function gml_Object_o_GearStorage_Create_0( _inst, _other )
{
_inst.gmlgear_slots=100;
_inst.gmlgear=__yy_method( _inst, gml_Script_anon_28_gml_Object_o_GearStorage_Create_0);
_inst.gmlgears_in = __yy_gml_array_check( _inst.gmlgears_in, 2816678625 );
_inst.gmlgears_in[__yy_gml_array_check_index_set(yyfminus(__yy_gml_errCheck(_inst.gmlgear_slots),1))]=(-1);
var gmli = 0 ; for (; yyfless(gmli,_inst.gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
_inst.gmlgears_in[__yy_gml_array_check_index_set(gmli)]=(-1);
}
};
_inst.gmlcurrent_item=0;
_inst.gmlamount_left=0;
}
function gml_Script_anon_28_gml_Object_o_GearStorage_Create_0( _inst, _other, argument0, argument1, argument2, argument3, argument4){ 
if (_inst.__yyIsGMLObject) { _inst.__type = "gml_Script_anon@28@gml_Object_o_GearStorage_Create_0"; }
if (gml_Script_anon_28_gml_Object_o_GearStorage_Create_0.prototype.__type === undefined) { gml_Script_anon_28_gml_Object_o_GearStorage_Create_0.prototype.__type = "gml_Script_anon@28@gml_Object_o_GearStorage_Create_0"; }{ 
if (_inst.__yyIsGMLObject) Object.setPrototypeOf( _inst, gml_Script_anon_28_gml_Object_o_GearStorage_Create_0.prototype);
{
_inst.gmlx_=argument0;
_inst.gmly_=argument1;
_inst.gmlid_=argument2;
_inst.gmllevel_=argument3;
_inst.gmlvalue_=argument4;
}
}
}


// #####################################################################################################
// if (room_get_name(room) == "Room2") { 
//  
// 	amount_left = 0; 
// 	for (var i = 0; i < gear_slots; i++) { 
// 		if (gears_in[i] == -1) { 
// 			amount_left++; 
// 		} 
// 	} 
// }
function gml_Object_o_GearStorage_Step_0( _inst, _other )
{
if ( yyfequal(room_get_name( g_pBuiltIn.get_current_room() ),"Room2")) {{
_inst.gmlamount_left=0;
var gmli = 0 ; for (; yyfless(gmli,_inst.gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfequal(_inst.gmlgears_in[__yy_gml_array_check_index(gmli, _inst.gmlgears_in)],(-1))) {{
( g_yyPrePostObject__ = _inst.gmlamount_left, _inst.gmlamount_left = (g_yyPrePostObject__ instanceof Long ? _inst.gmlamount_left.add(1) : ++_inst.gmlamount_left), g_yyPrePostObject__);
}
;}
;
}
};
}
;}
;
}

// #####################################################################################################
// if (room_get_name(room) == "Room2" && !instance_exists(o_Gears)) { 
//  
// for (var i = 0; i < gear_slots; i++) { 
// 	if (gears_in[i] != -1) { 
// 		var g = gears_in[i]; 
// 		var t = instance_create_layer(g.x_,g.y_,"Instances_1",o_Gears); 
// 		t.level_ = g.level_; 
// 		t.value_ = g.value_; 
// 		t.id_ = g.id_; 
// 		t.count_ = i; 
// 	} 
// 	gears_in[i] = -1; 
// } 
//  
// }
function gml_Object_o_GearStorage_Other_4( _inst, _other )
{
if ( (yyGetBool(yyfequal(room_get_name( g_pBuiltIn.get_current_room() ),"Room2"))) && (yyGetBool(!yyGetBool(instance_exists( YYASSET_REF(0x00000034) ))))) {{
var gmli = 0 ; for (; yyfless(gmli,_inst.gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfnotequal(_inst.gmlgears_in[__yy_gml_array_check_index(gmli, _inst.gmlgears_in)],(-1))) {{
var gmlg = _inst.gmlgears_in[__yy_gml_array_check_index(gmli, _inst.gmlgears_in)];
var gmlt = instance_create_layer( yyInst(_inst,_other,gmlg).gmlx_, yyInst(_inst,_other,gmlg).gmly_, "Instances_1", YYASSET_REF(0x00000034) );
yyInst(_inst,_other,gmlt).gmllevel_=yyInst(_inst,_other,gmlg).gmllevel_;
yyInst(_inst,_other,gmlt).gmlvalue_=yyInst(_inst,_other,gmlg).gmlvalue_;
yyInst(_inst,_other,gmlt).gmlid_=yyInst(_inst,_other,gmlg).gmlid_;
yyInst(_inst,_other,gmlt).gmlcount_=gmli;
}
;}
;
_inst.gmlgears_in = __yy_gml_array_check( _inst.gmlgears_in, 2816678625 );
_inst.gmlgears_in[__yy_gml_array_check_index_set(gmli)]=(-1);
}
};
}
;}
;
}

// #####################################################################################################
// if (room_get_name(room) == "Room2") { 
// 	draw_self(); 
// 	draw_text(x+18,y+18,"Gear Storage"); 
// }
function gml_Object_o_GearStorage_Draw_0( _inst, _other )
{
if ( yyfequal(room_get_name( g_pBuiltIn.get_current_room() ),"Room2")) {{
draw_self( _inst  );
draw_text( yyfplus(__yy_gml_errCheck(_inst.x),18), yyfplus(__yy_gml_errCheck(_inst.y),18), "Gear Storage" );
}
;}
;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 3; 
// lock = -1;
function gml_Object_o_button_auto_3_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=3;
_inst.gmllock=(-1);
}

// #####################################################################################################
// text = " "; 
// id_ = 0; 
//  
// texts = string_split(text,"\n")texts = string_split(text,"\n") 
//  
// length = 0; 
// texts_amount = array_length(texts) 
//  
// for (var i = 0; i < texts_amount; i++) { 
// 	if (length < string_width(texts[i])) { 
// 		length = string_width(texts[i]); 
// 	} 
// } 
//  
// image_xscale = length*2/(font_get_size(font1)*font_get_size(font1)); 
// image_yscale = texts_amount*4/font_get_size(font1); 
//  
// cost = 0; 
// level = 0; 
//  
// countdown = 1; 
// countdown_do = false; 
//  
// lock = -1; 
// unlock = false; 
//  
// on = false; 
//  
// prestige = true;
function gml_Object_o_button_Create_0( _inst, _other )
{
_inst.gmltext=" ";
_inst.gmlid_=0;
_inst.gmltexts=string_split( _inst.gmltext, "\n" );
_inst.gmltexts=string_split( _inst.gmltext, "\n" );
_inst.gmllength=0;
_inst.gmltexts_amount=array_length( _inst.gmltexts );
var gmli = 0 ; for (; yyfless(gmli,_inst.gmltexts_amount) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfless(_inst.gmllength,string_width( _inst.gmltexts[__yy_gml_array_check_index(gmli, _inst.gmltexts)] ))) {{
_inst.gmllength=string_width( _inst.gmltexts[__yy_gml_array_check_index(gmli, _inst.gmltexts)] );
}
;}
;
}
};
_inst.image_xscale=yyfdivide(yyftime(__yy_gml_errCheck(_inst.gmllength),2),__yy_gml_errCheck(yyftime(__yy_gml_errCheck(font_get_size( YYASSET_REF(0x07000000) )),__yy_gml_errCheck(font_get_size( YYASSET_REF(0x07000000) )))));
_inst.image_yscale=yyfdivide(yyftime(__yy_gml_errCheck(_inst.gmltexts_amount),4),__yy_gml_errCheck(font_get_size( YYASSET_REF(0x07000000) )));
_inst.gmlcost=0;
_inst.gmllevel=0;
_inst.gmlcountdown=1;
_inst.gmlcountdown_do=false;
_inst.gmllock=(-1);
_inst.gmlunlock=false;
_inst.gmlon=false;
_inst.gmlprestige=true;
}

// #####################################################################################################
// image_index = 0;
function gml_Object_o_button_Alarm_0( _inst, _other )
{
_inst.image_index=0;
}

// #####################################################################################################
// switch(id_) { 
// 	case 0: 
// 		text = "ERRORRRRRRRRRRRRRRRRRRR\nUNO\nDOS\nTRES"; 
// 	break; 
// 	case 1: 
// 		text = "Charge Press\n" + string(global.crush_power) + "/" + string(global.maximum_crush_needed); 
// 	break; 
// 	case 2: 
// 		text = "Restock\n" + string(o_spawner.amount_) + "/10"; 
// 	break; 
// 	case 3: 
// 		cost = 15+level*round(level/2); 
// 		text = "Auto Pressing [" + string(level) + "]\nCost: " + string(cost) + " Paper"; 
// 	break; 
// 	case 4: 
// 		cost = (20+level)*(2+level*4); 
// 		text = "Quality Paper [" + string(level) + "]\nCost: " + string(cost) + " Paper"; 
// 	break; 
// 	case 5: 
// 		cost = 124; 
// 		text = "Unlock Wood [" + string(level) + "/1]\nCost: " + string(cost) + " Paper"; 
// 	break; 
// 	case 6: 
// 		cost = 10+level*(level*10); 
// 		text = "Wood Pressure [" + string(level) + "]\nCost: " + string(cost) + " Wood"; 
// 	break; 
// 	case 7: 
// 		cost = 5+level*(level*find_button(4).level); 
// 		text = "Dequaliting Paper [" + string(level) + "]\nCost: " + string(cost) + " Wood"; 
// 	break; 
// 	case 8: 
// 		cost = 100+level*level*15; 
// 		text = "Quality Wood [" + string(level) + "]\nCost: " + string(cost) + " Paper"; 
// 	break; 
// 	case 9: 
// 		cost = 5+level*level*5; 
// 		text = "Pressure Clicking [" + string(level) + "]\nCost: " + string(cost) + " Wood"; 
// 	break; 
// 	case 10: 
// 		cost = 30+level*level*level*3; 
// 		text = "Wooden Paper [" + string(level) + "/10]\nCost: " + string(cost) + " Wood"; 
// 	break; 
// 	case 11: 
// 		cost = 100; 
// 		if (level < 1) { 
// 			text = "Auto Restocking [" + string(level) + "/1]\nCost: " + string(cost) + " Wood"; 
// 		} else if (level == 1) { 
// 			text = "Auto Restocking [ON]"; 
// 		} else { 
// 			text = "Auto Restocking [OFF]"; 
// 		} 
// 	break; 
// 	case 12: 
// 		cost = 250+(level+2)*(level+2)*(level+2); 
// 		text = "Paper Pressure Clicking [" + string(level) + "]\nCost: " + string(cost) + " Paper"; 
// 	break; 
// 	case 13: 
// 		cost = 1000; 
// 		text = "Unlock The Restocker [" + string(level) + "/1]\nCost: " + string(cost) + " Paper"; 
// 	break; 
// 	case 14: 
// 		cost = 10*(10*(level*level+1)); 
// 		text = "Wood Stock [" + string(level) + "/9]\nCost: " + string(cost) + " Wood"; 
// 	break; 
// 	case 15: 
// 		cost = 1; 
// 		text = "Gearing (Up) [" + string(level) + "/1]\nCost: " + string(cost) + " Paper"; 
// 	break; 
// 	case 16: 
// 		cost = 50*((level+1)*(level+1)); 
// 		text = "Pressurize - Paper [" + string(level) + "]\nCost: " + string(cost) + " Paper"; 
// 	break; 
// 	case 17: 
// 		cost = 10*((level+1)*(level+1)); 
// 		text = "Pressurize - Wood [" + string(level) + "]\nCost: " + string(cost) + " Wood"; 
// 	break; 
// 	case 18: 
// 		cost = 750; 
// 		text = "Pressure Value [" + string(level) + "/1]\nCost: " + string(cost) + " Wood"; 
// 	break; 
// 	case 19: 
// 		cost = 1000; 
// 		text = "Pressure Storage [" + string(level) + "]\nCost: " + string(cost) + " Paper"; 
// 	break; 
// 	case 20: 
// 		cost = (25+level)*(20+level)*(10+level*level); 
// 		text = "Paper Polishing [" + string(level) + "/20]\nCost: " + string(cost) + " Paper"; 
// 	break; 
// } 
//  
// texts = string_split(text,"\n") 
//  
// length = 0; 
// texts_amount = array_length(texts) 
//  
// for (var i = 0; i < texts_amount; i++) { 
// 	if (length < string_width(texts[i])) { 
// 		length = string_width(texts[i]); 
// 	} 
// } 
//  
// image_xscale = length*2/(font_get_size(font1)*font_get_size(font1)); 
// image_yscale = texts_amount*4/font_get_size(font1); 
//  
// if (countdown > 0 && countdown_do == true) { 
// 	countdown--;	 
// } 
//  
// if (unlock == false) { 
// 	if (lock == -1 || o_Storeplace.button_unlock[lock] == true) { 
// 		unlock = true;	 
// 	} 
// } 
//  
// /* 
// if (prestige == false) { 
// 	image_index = 1;	 
// } else { 
// 	image_index = 0;	 
// }
function gml_Object_o_button_Step_0( _inst, _other )
{
var ___sw18___ = _inst.gmlid_; 
var ___swc19___ = -1;
if (yyCompareVal(___sw18___,0,g_GMLMathEpsilon, false)==0) {
___swc19___ = 0;
}
else if (yyCompareVal(___sw18___,1,g_GMLMathEpsilon, false)==0) {
___swc19___ = 1;
}
else if (yyCompareVal(___sw18___,2,g_GMLMathEpsilon, false)==0) {
___swc19___ = 2;
}
else if (yyCompareVal(___sw18___,3,g_GMLMathEpsilon, false)==0) {
___swc19___ = 3;
}
else if (yyCompareVal(___sw18___,4,g_GMLMathEpsilon, false)==0) {
___swc19___ = 4;
}
else if (yyCompareVal(___sw18___,5,g_GMLMathEpsilon, false)==0) {
___swc19___ = 5;
}
else if (yyCompareVal(___sw18___,6,g_GMLMathEpsilon, false)==0) {
___swc19___ = 6;
}
else if (yyCompareVal(___sw18___,7,g_GMLMathEpsilon, false)==0) {
___swc19___ = 7;
}
else if (yyCompareVal(___sw18___,8,g_GMLMathEpsilon, false)==0) {
___swc19___ = 8;
}
else if (yyCompareVal(___sw18___,9,g_GMLMathEpsilon, false)==0) {
___swc19___ = 9;
}
else if (yyCompareVal(___sw18___,10,g_GMLMathEpsilon, false)==0) {
___swc19___ = 10;
}
else if (yyCompareVal(___sw18___,11,g_GMLMathEpsilon, false)==0) {
___swc19___ = 11;
}
else if (yyCompareVal(___sw18___,12,g_GMLMathEpsilon, false)==0) {
___swc19___ = 12;
}
else if (yyCompareVal(___sw18___,13,g_GMLMathEpsilon, false)==0) {
___swc19___ = 13;
}
else if (yyCompareVal(___sw18___,14,g_GMLMathEpsilon, false)==0) {
___swc19___ = 14;
}
else if (yyCompareVal(___sw18___,15,g_GMLMathEpsilon, false)==0) {
___swc19___ = 15;
}
else if (yyCompareVal(___sw18___,16,g_GMLMathEpsilon, false)==0) {
___swc19___ = 16;
}
else if (yyCompareVal(___sw18___,17,g_GMLMathEpsilon, false)==0) {
___swc19___ = 17;
}
else if (yyCompareVal(___sw18___,18,g_GMLMathEpsilon, false)==0) {
___swc19___ = 18;
}
else if (yyCompareVal(___sw18___,19,g_GMLMathEpsilon, false)==0) {
___swc19___ = 19;
}
else if (yyCompareVal(___sw18___,20,g_GMLMathEpsilon, false)==0) {
___swc19___ = 20;
}
switch( ___swc19___ ) {
case 0: {
_inst.gmltext="ERRORRRRRRRRRRRRRRRRRRR\nUNO\nDOS\nTRES";
break;
}
case 1: {
_inst.gmltext=yyfplus(yyfplus(yyfplus("Charge Press\n",__yy_gml_errCheck(string( global.gmlcrush_power ))),"/"),__yy_gml_errCheck(string( global.gmlmaximum_crush_needed )));
break;
}
case 2: {
_inst.gmltext=yyfplus(yyfplus("Restock\n",__yy_gml_errCheck(string( yyInst(_inst,_other,YYASSET_REF(0x00000001)).gmlamount_ ))),"/10");
break;
}
case 3: {
_inst.gmlcost=yyfplus(15,__yy_gml_errCheck(yyftime(__yy_gml_errCheck(_inst.gmllevel),__yy_gml_errCheck(round( yyfdivide(__yy_gml_errCheck(_inst.gmllevel),2) )))));
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Auto Pressing [",__yy_gml_errCheck(string( _inst.gmllevel ))),"]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Paper");
break;
}
case 4: {
_inst.gmlcost=yyftime(__yy_gml_errCheck(yyfplus(20,__yy_gml_errCheck(_inst.gmllevel))),__yy_gml_errCheck(yyfplus(2,__yy_gml_errCheck(yyftime(__yy_gml_errCheck(_inst.gmllevel),4)))));
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Quality Paper [",__yy_gml_errCheck(string( _inst.gmllevel ))),"]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Paper");
break;
}
case 5: {
_inst.gmlcost=124;
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Unlock Wood [",__yy_gml_errCheck(string( _inst.gmllevel ))),"/1]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Paper");
break;
}
case 6: {
_inst.gmlcost=yyfplus(10,__yy_gml_errCheck(yyftime(__yy_gml_errCheck(_inst.gmllevel),__yy_gml_errCheck(yyftime(__yy_gml_errCheck(_inst.gmllevel),10)))));
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Wood Pressure [",__yy_gml_errCheck(string( _inst.gmllevel ))),"]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Wood");
break;
}
case 7: {
_inst.gmlcost=yyfplus(5,__yy_gml_errCheck(yyftime(__yy_gml_errCheck(_inst.gmllevel),__yy_gml_errCheck(yyftime(__yy_gml_errCheck(_inst.gmllevel),__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 4 )).gmllevel))))));
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Dequaliting Paper [",__yy_gml_errCheck(string( _inst.gmllevel ))),"]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Wood");
break;
}
case 8: {
_inst.gmlcost=yyfplus(100,__yy_gml_errCheck(yyftime(yyftime(__yy_gml_errCheck(_inst.gmllevel),__yy_gml_errCheck(_inst.gmllevel)),15)));
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Quality Wood [",__yy_gml_errCheck(string( _inst.gmllevel ))),"]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Paper");
break;
}
case 9: {
_inst.gmlcost=yyfplus(5,__yy_gml_errCheck(yyftime(yyftime(__yy_gml_errCheck(_inst.gmllevel),__yy_gml_errCheck(_inst.gmllevel)),5)));
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Pressure Clicking [",__yy_gml_errCheck(string( _inst.gmllevel ))),"]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Wood");
break;
}
case 10: {
_inst.gmlcost=yyfplus(30,__yy_gml_errCheck(yyftime(yyftime(yyftime(__yy_gml_errCheck(_inst.gmllevel),__yy_gml_errCheck(_inst.gmllevel)),__yy_gml_errCheck(_inst.gmllevel)),3)));
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Wooden Paper [",__yy_gml_errCheck(string( _inst.gmllevel ))),"/10]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Wood");
break;
}
case 11: {
_inst.gmlcost=100;
if ( yyfless(_inst.gmllevel,1)) {{
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Auto Restocking [",__yy_gml_errCheck(string( _inst.gmllevel ))),"/1]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Wood");
}
;}
 else {if ( yyfequal(_inst.gmllevel,1)) {{
_inst.gmltext="Auto Restocking [ON]";
}
;}
 else {{
_inst.gmltext="Auto Restocking [OFF]";
}
;};};
break;
}
case 12: {
_inst.gmlcost=yyfplus(250,__yy_gml_errCheck(yyftime(yyftime(__yy_gml_errCheck(yyfplus(__yy_gml_errCheck(_inst.gmllevel),2)),__yy_gml_errCheck(yyfplus(__yy_gml_errCheck(_inst.gmllevel),2))),__yy_gml_errCheck(yyfplus(__yy_gml_errCheck(_inst.gmllevel),2)))));
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Paper Pressure Clicking [",__yy_gml_errCheck(string( _inst.gmllevel ))),"]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Paper");
break;
}
case 13: {
_inst.gmlcost=1000;
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Unlock The Restocker [",__yy_gml_errCheck(string( _inst.gmllevel ))),"/1]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Paper");
break;
}
case 14: {
_inst.gmlcost=yyftime(10,__yy_gml_errCheck(yyftime(10,__yy_gml_errCheck(yyfplus(__yy_gml_errCheck(yyftime(__yy_gml_errCheck(_inst.gmllevel),__yy_gml_errCheck(_inst.gmllevel))),1)))));
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Wood Stock [",__yy_gml_errCheck(string( _inst.gmllevel ))),"/9]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Wood");
break;
}
case 15: {
_inst.gmlcost=1;
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Gearing (Up) [",__yy_gml_errCheck(string( _inst.gmllevel ))),"/1]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Paper");
break;
}
case 16: {
_inst.gmlcost=yyftime(50,__yy_gml_errCheck(yyftime(__yy_gml_errCheck(yyfplus(__yy_gml_errCheck(_inst.gmllevel),1)),__yy_gml_errCheck(yyfplus(__yy_gml_errCheck(_inst.gmllevel),1)))));
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Pressurize - Paper [",__yy_gml_errCheck(string( _inst.gmllevel ))),"]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Paper");
break;
}
case 17: {
_inst.gmlcost=yyftime(10,__yy_gml_errCheck(yyftime(__yy_gml_errCheck(yyfplus(__yy_gml_errCheck(_inst.gmllevel),1)),__yy_gml_errCheck(yyfplus(__yy_gml_errCheck(_inst.gmllevel),1)))));
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Pressurize - Wood [",__yy_gml_errCheck(string( _inst.gmllevel ))),"]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Wood");
break;
}
case 18: {
_inst.gmlcost=750;
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Pressure Value [",__yy_gml_errCheck(string( _inst.gmllevel ))),"/1]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Wood");
break;
}
case 19: {
_inst.gmlcost=1000;
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Pressure Storage [",__yy_gml_errCheck(string( _inst.gmllevel ))),"]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Paper");
break;
}
case 20: {
_inst.gmlcost=yyftime(yyftime(__yy_gml_errCheck(yyfplus(25,__yy_gml_errCheck(_inst.gmllevel))),__yy_gml_errCheck(yyfplus(20,__yy_gml_errCheck(_inst.gmllevel)))),__yy_gml_errCheck(yyfplus(10,__yy_gml_errCheck(yyftime(__yy_gml_errCheck(_inst.gmllevel),__yy_gml_errCheck(_inst.gmllevel))))));
_inst.gmltext=yyfplus(yyfplus(yyfplus(yyfplus("Paper Polishing [",__yy_gml_errCheck(string( _inst.gmllevel ))),"/20]\nCost: "),__yy_gml_errCheck(string( _inst.gmlcost )))," Paper");
break;
}
}
;
_inst.gmltexts=string_split( _inst.gmltext, "\n" );
_inst.gmllength=0;
_inst.gmltexts_amount=array_length( _inst.gmltexts );
var gmli = 0 ; for (; yyfless(gmli,_inst.gmltexts_amount) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfless(_inst.gmllength,string_width( _inst.gmltexts[__yy_gml_array_check_index(gmli, _inst.gmltexts)] ))) {{
_inst.gmllength=string_width( _inst.gmltexts[__yy_gml_array_check_index(gmli, _inst.gmltexts)] );
}
;}
;
}
};
_inst.image_xscale=yyfdivide(yyftime(__yy_gml_errCheck(_inst.gmllength),2),__yy_gml_errCheck(yyftime(__yy_gml_errCheck(font_get_size( YYASSET_REF(0x07000000) )),__yy_gml_errCheck(font_get_size( YYASSET_REF(0x07000000) )))));
_inst.image_yscale=yyfdivide(yyftime(__yy_gml_errCheck(_inst.gmltexts_amount),4),__yy_gml_errCheck(font_get_size( YYASSET_REF(0x07000000) )));
if ( (yyGetBool(yyfgreater(_inst.gmlcountdown,0))) && (yyGetBool(yyfequal(_inst.gmlcountdown_do,true)))) {{
( g_yyPrePostObject__ = _inst.gmlcountdown, _inst.gmlcountdown = (g_yyPrePostObject__ instanceof Long ? _inst.gmlcountdown.subtract(1) : --_inst.gmlcountdown), g_yyPrePostObject__);
}
;}
;
if ( yyfequal(_inst.gmlunlock,false)) {{
if ( (yyGetBool(yyfequal(_inst.gmllock,(-1)))) || (yyGetBool(yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock[__yy_gml_array_check_index(_inst.gmllock, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock)],true)))) {{
_inst.gmlunlock=true;
}
;}
;
}
;}
;
}

// #####################################################################################################
// if (unlock == true && on == true) { 
// 	switch(id_) { 
// 		case 0: 
// 			show_debug_message("ERROR"); 
// 		break; 
// 		case 1: 
// 			var popup = global.crush_power; 
// 			global.crush_power += o_Storeplace.clicking_power; 
// 			var i = irandom_range(0,global.crit_chance_); 
// 			var i2 = irandom_range(1,100); 
// 			if (i >= i2) { 
// 				global.crush_power += o_Storeplace.clicking_power*global.crit_damage_; 
// 			} 
// 			if (global.crush_power > global.maximum_crush_needed) { 
// 				global.crush_power = global.maximum_crush_needed; 
// 			} 
// 			popup = global.crush_power - popup; 
// 			var instance = instance_create_layer(x+irandom_range(0,image_xscale*32),y,"Instances",o_button_1_text); 
// 			instance.text = popup; 
// 		break; 
// 		case 2: 
// 			if (o_spawner.amount_ == 10) { 
// 				o_spawner.amount_ = 0; 
// 			} 
// 		break; 
// 		case 3: 
// 			if (check_cost(0,cost)) { 
// 				o_Storeplace.item_database[0].item_amount -= cost; 
// 				level++; 
// 				unlock_button(0); 
// 			} 
// 		break; 
// 		case 4: 
// 			if (check_cost(0,cost)) { 
// 				o_Storeplace.item_database[0].item_amount -= cost; 
// 				level++; 
// 				unlock_button(1); 
// 			} 
// 		break; 
// 		case 5: 
// 			if (check_cost(0,cost) && level < 1) { 
// 				o_Storeplace.item_database[0].item_amount -= cost; 
// 				level++; 
// 				o_Storeplace.item_database[1].item_unlock = true; 
// 				o_Storeplace.item_database[1].item_belt++; 
// 				global.order[0] = 1; 
// 				unlock_button(2); 
// 			} 
// 		break; 
// 		case 6: 
// 			if (check_cost(1,cost)) { 
// 				o_Storeplace.item_database[1].item_amount -= cost; 
// 				level++; 
// 			} 
// 		break; 
// 		case 7: 
// 			if (check_cost(1,cost)) { 
// 				o_Storeplace.item_database[1].item_amount -= cost; 
// 				level++; 
// 			} 
// 		break; 
// 		case 8: 
// 			if (check_cost(0,cost)) { 
// 				o_Storeplace.item_database[0].item_amount -= cost; 
// 				level++; 
// 			} 
// 		break; 
// 		case 9: 
// 			if (check_cost(1,cost)) { 
// 				o_Storeplace.item_database[1].item_amount -= cost; 
// 				level++; 
// 			} 
// 		break; 
// 		case 10: 
// 			if (check_cost(1,cost) && level < 10) { 
// 				o_Storeplace.item_database[1].item_amount -= cost; 
// 				level++; 
// 			} 
// 		break; 
// 		case 11: 
// 			if (check_cost(1,cost) && level < 1) { 
// 				o_Storeplace.item_database[1].item_amount -= cost; 
// 				level++; 
// 				unlock_button(3); 
// 			} else if (level > 0) { 
// 				switch(level) { 
// 					case 1: 
// 						level = 2; 
// 					break; 
// 					case 2: 
// 						level = 1; 
// 					break; 
// 				} 
// 			} 
// 		break; 
// 		case 12: 
// 			if (check_cost(0,cost)) { 
// 				o_Storeplace.item_database[0].item_amount -= cost; 
// 				level++; 
// 			} 
// 		break; 
// 		case 13: 
// 			if (check_cost(0,cost) && level < 1) { 
// 				o_Storeplace.item_database[0].item_amount -= cost; 
// 				level++; 
// 				unlock_button(4); 
// 			} 
// 		break; 
// 		case 14: 
// 			if (check_cost(1,cost) && level < 9) { 
// 				o_Storeplace.item_database[1].item_amount -= cost; 
// 				level++; 
// 				o_Storeplace.item_database[1].item_belt += 1; 
// 			} 
// 		break; 
// 		case 15: 
// 			if (check_cost(0,cost) && level < 1) { 
// 				o_Storeplace.item_database[0].item_amount -= cost; 
// 				level++; 
// 				unlock_button(5); 
// 			} 
// 		break; 
// 		case 16: 
// 			if (check_cost(0,cost)) { 
// 				o_Storeplace.item_database[0].item_amount -= cost; 
// 				level++; 
// 				global.xp_ += 1; 
// 			} 
// 		break; 
// 		case 17: 
// 			if (check_cost(1,cost)) { 
// 				o_Storeplace.item_database[1].item_amount -= cost; 
// 				level++; 
// 				global.xp_ += 2; 
// 			} 
// 		break; 
// 		case 18: 
// 			if (check_cost(1,cost) && level < 1) { 
// 				o_Storeplace.item_database[1].item_amount -= cost; 
// 				level++; 
// 			} 
// 		break; 
// 		case 19: 
// 			if (check_cost(0,cost)) { 
// 				o_Storeplace.item_database[0].item_amount -= cost; 
// 				level += find_button(3).level; 
// 				find_button(3).level = 0; 
// 			} 
// 		break; 
// 		case 20: 
// 			if (check_cost(0,cost) && level < 20) { 
// 				o_Storeplace.item_database[0].item_amount -= cost; 
// 				level += 1; 
// 			} 
// 		break; 
// 	} 
// } 
//  
// image_index = 1; 
// alarm_set(0,5)
function gml_Object_o_button_Mouse_4( _inst, _other )
{
if ( (yyGetBool(yyfequal(_inst.gmlunlock,true))) && (yyGetBool(yyfequal(_inst.gmlon,true)))) {{
var ___sw24___ = _inst.gmlid_; 
var ___swc25___ = -1;
if (yyCompareVal(___sw24___,0,g_GMLMathEpsilon, false)==0) {
___swc25___ = 0;
}
else if (yyCompareVal(___sw24___,1,g_GMLMathEpsilon, false)==0) {
___swc25___ = 1;
}
else if (yyCompareVal(___sw24___,2,g_GMLMathEpsilon, false)==0) {
___swc25___ = 2;
}
else if (yyCompareVal(___sw24___,3,g_GMLMathEpsilon, false)==0) {
___swc25___ = 3;
}
else if (yyCompareVal(___sw24___,4,g_GMLMathEpsilon, false)==0) {
___swc25___ = 4;
}
else if (yyCompareVal(___sw24___,5,g_GMLMathEpsilon, false)==0) {
___swc25___ = 5;
}
else if (yyCompareVal(___sw24___,6,g_GMLMathEpsilon, false)==0) {
___swc25___ = 6;
}
else if (yyCompareVal(___sw24___,7,g_GMLMathEpsilon, false)==0) {
___swc25___ = 7;
}
else if (yyCompareVal(___sw24___,8,g_GMLMathEpsilon, false)==0) {
___swc25___ = 8;
}
else if (yyCompareVal(___sw24___,9,g_GMLMathEpsilon, false)==0) {
___swc25___ = 9;
}
else if (yyCompareVal(___sw24___,10,g_GMLMathEpsilon, false)==0) {
___swc25___ = 10;
}
else if (yyCompareVal(___sw24___,11,g_GMLMathEpsilon, false)==0) {
___swc25___ = 11;
}
else if (yyCompareVal(___sw24___,12,g_GMLMathEpsilon, false)==0) {
___swc25___ = 12;
}
else if (yyCompareVal(___sw24___,13,g_GMLMathEpsilon, false)==0) {
___swc25___ = 13;
}
else if (yyCompareVal(___sw24___,14,g_GMLMathEpsilon, false)==0) {
___swc25___ = 14;
}
else if (yyCompareVal(___sw24___,15,g_GMLMathEpsilon, false)==0) {
___swc25___ = 15;
}
else if (yyCompareVal(___sw24___,16,g_GMLMathEpsilon, false)==0) {
___swc25___ = 16;
}
else if (yyCompareVal(___sw24___,17,g_GMLMathEpsilon, false)==0) {
___swc25___ = 17;
}
else if (yyCompareVal(___sw24___,18,g_GMLMathEpsilon, false)==0) {
___swc25___ = 18;
}
else if (yyCompareVal(___sw24___,19,g_GMLMathEpsilon, false)==0) {
___swc25___ = 19;
}
else if (yyCompareVal(___sw24___,20,g_GMLMathEpsilon, false)==0) {
___swc25___ = 20;
}
switch( ___swc25___ ) {
case 0: {
show_debug_message( "ERROR" );
break;
}
case 1: {
var gmlpopup = global.gmlcrush_power;
global.gmlcrush_power=yyfplus(global.gmlcrush_power,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlclicking_power);
var gmli = irandom_range( 0, global.gmlcrit_chance_ );
var gmli2 = irandom_range( 1, 100 );
if ( yyfgreaterequal(gmli,gmli2)) {{
global.gmlcrush_power=yyfplus(global.gmlcrush_power,yyftime(__yy_gml_errCheck(yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlclicking_power),__yy_gml_errCheck(global.gmlcrit_damage_)));
}
;}
;
if ( yyfgreater(global.gmlcrush_power,global.gmlmaximum_crush_needed)) {{
global.gmlcrush_power=global.gmlmaximum_crush_needed;
}
;}
;
gmlpopup=yyfminus(__yy_gml_errCheck(global.gmlcrush_power),__yy_gml_errCheck(gmlpopup));
var gmlinstance = instance_create_layer( yyfplus(__yy_gml_errCheck(_inst.x),__yy_gml_errCheck(irandom_range( 0, yyftime(__yy_gml_errCheck(_inst.image_xscale),32) ))), _inst.y, "Instances", YYASSET_REF(0x00000008) );
yyInst(_inst,_other,gmlinstance).gmltext=gmlpopup;
break;
}
case 2: {
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000001)).gmlamount_,10)) {{
yyInst(_inst,_other,YYASSET_REF(0x00000001)).gmlamount_=0;
}
;}
;
break;
}
case 3: {
if ( yyGetBool(gml_Script_check_cost( _inst , _other , 0, _inst.gmlcost ))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
gml_Script_unlock_button( _inst , _other , 0 );
}
;}
;
break;
}
case 4: {
if ( yyGetBool(gml_Script_check_cost( _inst , _other , 0, _inst.gmlcost ))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
gml_Script_unlock_button( _inst , _other , 1 );
}
;}
;
break;
}
case 5: {
if ( (yyGetBool(gml_Script_check_cost( _inst , _other , 0, _inst.gmlcost ))) && (yyGetBool(yyfless(_inst.gmllevel,1)))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_unlock=true;
( g_yyPrePostObject__ = yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_belt, yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_belt = (g_yyPrePostObject__ instanceof Long ? yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_belt.add(1) : ++yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_belt), g_yyPrePostObject__);
global.gmlorder = __yy_gml_array_check( global.gmlorder, 1472648720 );
global.gmlorder[__yy_gml_array_check_index_set(0)]=1;
gml_Script_unlock_button( _inst , _other , 2 );
}
;}
;
break;
}
case 6: {
if ( yyGetBool(gml_Script_check_cost( _inst , _other , 1, _inst.gmlcost ))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
}
;}
;
break;
}
case 7: {
if ( yyGetBool(gml_Script_check_cost( _inst , _other , 1, _inst.gmlcost ))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
}
;}
;
break;
}
case 8: {
if ( yyGetBool(gml_Script_check_cost( _inst , _other , 0, _inst.gmlcost ))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
}
;}
;
break;
}
case 9: {
if ( yyGetBool(gml_Script_check_cost( _inst , _other , 1, _inst.gmlcost ))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
}
;}
;
break;
}
case 10: {
if ( (yyGetBool(gml_Script_check_cost( _inst , _other , 1, _inst.gmlcost ))) && (yyGetBool(yyfless(_inst.gmllevel,10)))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
}
;}
;
break;
}
case 11: {
if ( (yyGetBool(gml_Script_check_cost( _inst , _other , 1, _inst.gmlcost ))) && (yyGetBool(yyfless(_inst.gmllevel,1)))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
gml_Script_unlock_button( _inst , _other , 3 );
}
;}
 else {if ( yyfgreater(_inst.gmllevel,0)) {{
var ___sw26___ = _inst.gmllevel; 
var ___swc27___ = -1;
if (yyCompareVal(___sw26___,1,g_GMLMathEpsilon, false)==0) {
___swc27___ = 0;
}
else if (yyCompareVal(___sw26___,2,g_GMLMathEpsilon, false)==0) {
___swc27___ = 1;
}
switch( ___swc27___ ) {
case 0: {
_inst.gmllevel=2;
break;
}
case 1: {
_inst.gmllevel=1;
break;
}
}
;
}
;}
;};
break;
}
case 12: {
if ( yyGetBool(gml_Script_check_cost( _inst , _other , 0, _inst.gmlcost ))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
}
;}
;
break;
}
case 13: {
if ( (yyGetBool(gml_Script_check_cost( _inst , _other , 0, _inst.gmlcost ))) && (yyGetBool(yyfless(_inst.gmllevel,1)))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
gml_Script_unlock_button( _inst , _other , 4 );
}
;}
;
break;
}
case 14: {
if ( (yyGetBool(gml_Script_check_cost( _inst , _other , 1, _inst.gmlcost ))) && (yyGetBool(yyfless(_inst.gmllevel,9)))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_belt=yyfplus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_belt,1);
}
;}
;
break;
}
case 15: {
if ( (yyGetBool(gml_Script_check_cost( _inst , _other , 0, _inst.gmlcost ))) && (yyGetBool(yyfless(_inst.gmllevel,1)))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
gml_Script_unlock_button( _inst , _other , 5 );
}
;}
;
break;
}
case 16: {
if ( yyGetBool(gml_Script_check_cost( _inst , _other , 0, _inst.gmlcost ))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
global.gmlxp_=yyfplus(global.gmlxp_,1);
}
;}
;
break;
}
case 17: {
if ( yyGetBool(gml_Script_check_cost( _inst , _other , 1, _inst.gmlcost ))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
global.gmlxp_=yyfplus(global.gmlxp_,2);
}
;}
;
break;
}
case 18: {
if ( (yyGetBool(gml_Script_check_cost( _inst , _other , 1, _inst.gmlcost ))) && (yyGetBool(yyfless(_inst.gmllevel,1)))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
( g_yyPrePostObject__ = _inst.gmllevel, _inst.gmllevel = (g_yyPrePostObject__ instanceof Long ? _inst.gmllevel.add(1) : ++_inst.gmllevel), g_yyPrePostObject__);
}
;}
;
break;
}
case 19: {
if ( yyGetBool(gml_Script_check_cost( _inst , _other , 0, _inst.gmlcost ))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
_inst.gmllevel=yyfplus(_inst.gmllevel,yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 3 )).gmllevel);
yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 3 )).gmllevel=0;
}
;}
;
break;
}
case 20: {
if ( (yyGetBool(gml_Script_check_cost( _inst , _other , 0, _inst.gmlcost ))) && (yyGetBool(yyfless(_inst.gmllevel,20)))) {{
yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount=yyfminus(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount,_inst.gmlcost);
_inst.gmllevel=yyfplus(_inst.gmllevel,1);
}
;}
;
break;
}
}
;
}
;}
;
_inst.image_index=1;
alarm_set( _inst , 0, 5 );
}

// #####################################################################################################
// countdown_do = true;
function gml_Object_o_button_Mouse_10( _inst, _other )
{
_inst.gmlcountdown_do=true;
}

// #####################################################################################################
// countdown_do = false; 
// countdown = 1;
function gml_Object_o_button_Mouse_11( _inst, _other )
{
_inst.gmlcountdown_do=false;
_inst.gmlcountdown=1;
}

// #####################################################################################################
// if (unlock == true && on == true) { 
// 	draw_self(); 
// 	draw_set_font(font1); 
// 	draw_text(x+8,y+8,text); 
// }
function gml_Object_o_button_Draw_0( _inst, _other )
{
if ( (yyGetBool(yyfequal(_inst.gmlunlock,true))) && (yyGetBool(yyfequal(_inst.gmlon,true)))) {{
draw_self( _inst  );
draw_set_font( YYASSET_REF(0x07000000) );
draw_text( yyfplus(__yy_gml_errCheck(_inst.x),8), yyfplus(__yy_gml_errCheck(_inst.y),8), _inst.gmltext );
}
;}
;
}

// #####################################################################################################
// if (countdown == 0 && unlock == true && on == true) { 
// 	var description = "ERROR"; 
// 	switch(id_) { 
// 		case 0: 
// 			description = "ERRORRRRRRRRRRRRRRRRRRR\nUNO\nDOS\nTRES"; 
// 		break; 
// 		case 1: 
// 			description = "Charge the Press by clicking on it. \nIt activates once it is fully maxed out."; 
// 		break; 
// 		case 2: 
// 			description = "Restock the belt by clicking on it. \nYou can only restock once you have fully emptied the previous stock."; 
// 		break; 
// 		case 3: 
// 			description = "Every " + string(round(o_Autoclicker.auto_crush_speed/fps)) + " second(s), the Press will charge by " + string(level + find_button(19).level) + "."; 
// 		break; 
// 		case 4: 
// 			description = "Increases the quality of the paper, causing it to become stronger, \nbut give more paper!\nStrength: " + string(o_Storeplace.item_database[0].item_crushing_power) + "\nValue: " + string(o_Storeplace.item_database[0].item_value); 
// 		break; 
// 		case 5: 
// 			description = "Paper is getting boring, time to get a better resource."; 
// 		break; 
// 		case 6: 
// 			description = "The amount of Wood you have, increases the speed of the Press,\n but it strengthens the Wood. \nThe increase is: " + string(level*o_Storeplace.item_database[1].item_amount) + "\nStrength: " + string(o_Storeplace.item_database[1].item_crushing_power); 
// 		break; 
// 		case 7: 
// 			description = "The paper will lose a bit of its quality, making it weaker!\nStrength: " + string(o_Storeplace.item_database[0].item_crushing_power) + "\nThe price of this upgrade scales with 'Quality Paper'\nThis upgrade does not affect the value of the paper."; 
// 		break; 
// 		case 8: 
// 			description = "Increases the quality of the Wood, causing it to become stronger, \nbut give more Wood!\nStrength: " + string(o_Storeplace.item_database[1].item_crushing_power) + "\nValue: " + string(o_Storeplace.item_database[1].item_value); 
// 		break; 
// 		case 9: 
// 			description = "Your clicks will Pressure more with this one!\nClick Strength: " + string(o_Storeplace.clicking_power); 
// 		break; 
// 		case 10: 
// 			description = "Upon using the Press on Paper, you might be able to take\nout some wood from it!\nChance: " + string(level*10) + "%"; 
// 		break; 
// 		case 11: 
// 			description = "You hate restocking, don't you?"; 
// 		break; 
// 		case 12: 
// 			description = "Your clicks will Pressure more with this one!\nMultiplies by: " + string(level+1) + "\nClick Strength: " + string(o_Storeplace.clicking_power); 
// 		break; 
// 		case 13: 
// 			description = "Unlock the Restocker... whatever it is."; 
// 		break; 
// 		case 14: 
// 			description = "Get 1 More Wood Stock."; 
// 		break; 
// 		case 15: 
// 			description = "Gears... the heart of materials."; 
// 		break; 
// 		case 16: 
// 			description = "Adds 1 XP to Pressurize"; 
// 		break; 
// 		case 17: 
// 			description = "Adds 2 XP to Pressurize"; 
// 		break; 
// 		case 18: 
// 			description = "Strength = Value\nEvery 100 Strength a Material has, it gains 1 Value.\nSoftcapped at: " + string(level*25) + " Value."; 
// 		break; 
// 		case 19: 
// 			description = "Reset Auto Pressing, but all of its levels are kept in this upgrade.\nThe price of this upgrade never changes.\nThe levels are still active to the Auto Pressing."; 
// 		break; 
// 		case 20: 
// 			description = "Strengthen Paper by +" + string(level*level*125) + " but give it a " + string(level*5) + "% chance to be Polished.\nA Polished Material has double the value."; 
// 		break; 
// 	} 
//  
// 	var descriptions = string_split(description,"\n") 
//  
// 	var _length = 0; 
// 	var _texts_amount = array_length(descriptions) 
//  
// 	for (var i = 0; i < _texts_amount; i++) { 
// 		if (_length < string_length(descriptions[i])) { 
// 			_length = string_length(descriptions[i]); 
// 		} 
// 	} 
// 	 
// 	draw_set_color(c_black); 
// 	if (os_browser == browser_not_a_browser) { 
// 		var m_x = window_mouse_get_x(); 
// 		var m_y = window_mouse_get_y(); 
// 	} else if (os_browser != browser_not_a_browser) { 
// 		var m_x = display_mouse_get_x(); 
// 		var m_y = display_mouse_get_y(); 
// 	} 
// 	draw_rectangle(m_x,m_y,m_x+_length*font_get_size(font2),m_y+_texts_amount*2*font_get_size(font2), false) 
// 	draw_set_color(c_white); 
// 	draw_set_font(font2); 
// 	draw_text(m_x,m_y,description); 
// 	draw_set_font(font1); 
// }
function gml_Object_o_button_Draw_64( _inst, _other )
{
if ( (yyGetBool(yyfequal(_inst.gmlcountdown,0))) && (yyGetBool(yyfequal(_inst.gmlunlock,true))) && (yyGetBool(yyfequal(_inst.gmlon,true)))) {{
var gmldescription = "ERROR";
var ___sw30___ = _inst.gmlid_; 
var ___swc31___ = -1;
if (yyCompareVal(___sw30___,0,g_GMLMathEpsilon, false)==0) {
___swc31___ = 0;
}
else if (yyCompareVal(___sw30___,1,g_GMLMathEpsilon, false)==0) {
___swc31___ = 1;
}
else if (yyCompareVal(___sw30___,2,g_GMLMathEpsilon, false)==0) {
___swc31___ = 2;
}
else if (yyCompareVal(___sw30___,3,g_GMLMathEpsilon, false)==0) {
___swc31___ = 3;
}
else if (yyCompareVal(___sw30___,4,g_GMLMathEpsilon, false)==0) {
___swc31___ = 4;
}
else if (yyCompareVal(___sw30___,5,g_GMLMathEpsilon, false)==0) {
___swc31___ = 5;
}
else if (yyCompareVal(___sw30___,6,g_GMLMathEpsilon, false)==0) {
___swc31___ = 6;
}
else if (yyCompareVal(___sw30___,7,g_GMLMathEpsilon, false)==0) {
___swc31___ = 7;
}
else if (yyCompareVal(___sw30___,8,g_GMLMathEpsilon, false)==0) {
___swc31___ = 8;
}
else if (yyCompareVal(___sw30___,9,g_GMLMathEpsilon, false)==0) {
___swc31___ = 9;
}
else if (yyCompareVal(___sw30___,10,g_GMLMathEpsilon, false)==0) {
___swc31___ = 10;
}
else if (yyCompareVal(___sw30___,11,g_GMLMathEpsilon, false)==0) {
___swc31___ = 11;
}
else if (yyCompareVal(___sw30___,12,g_GMLMathEpsilon, false)==0) {
___swc31___ = 12;
}
else if (yyCompareVal(___sw30___,13,g_GMLMathEpsilon, false)==0) {
___swc31___ = 13;
}
else if (yyCompareVal(___sw30___,14,g_GMLMathEpsilon, false)==0) {
___swc31___ = 14;
}
else if (yyCompareVal(___sw30___,15,g_GMLMathEpsilon, false)==0) {
___swc31___ = 15;
}
else if (yyCompareVal(___sw30___,16,g_GMLMathEpsilon, false)==0) {
___swc31___ = 16;
}
else if (yyCompareVal(___sw30___,17,g_GMLMathEpsilon, false)==0) {
___swc31___ = 17;
}
else if (yyCompareVal(___sw30___,18,g_GMLMathEpsilon, false)==0) {
___swc31___ = 18;
}
else if (yyCompareVal(___sw30___,19,g_GMLMathEpsilon, false)==0) {
___swc31___ = 19;
}
else if (yyCompareVal(___sw30___,20,g_GMLMathEpsilon, false)==0) {
___swc31___ = 20;
}
switch( ___swc31___ ) {
case 0: {
gmldescription="ERRORRRRRRRRRRRRRRRRRRR\nUNO\nDOS\nTRES";
break;
}
case 1: {
gmldescription="Charge the Press by clicking on it. \nIt activates once it is fully maxed out.";
break;
}
case 2: {
gmldescription="Restock the belt by clicking on it. \nYou can only restock once you have fully emptied the previous stock.";
break;
}
case 3: {
gmldescription=yyfplus(yyfplus(yyfplus(yyfplus("Every ",__yy_gml_errCheck(string( round( yyfdivide(__yy_gml_errCheck(yyInst(_inst,_other,YYASSET_REF(0x0000000E)).gmlauto_crush_speed),__yy_gml_errCheck(g_pBuiltIn.fps)) ) )))," second(s), the Press will charge by "),__yy_gml_errCheck(string( yyfplus(__yy_gml_errCheck(_inst.gmllevel),__yy_gml_errCheck(yyInst(_inst,_other,gml_Script_find_button( _inst , _other , 19 )).gmllevel)) ))),".");
break;
}
case 4: {
gmldescription=yyfplus(yyfplus(yyfplus("Increases the quality of the paper, causing it to become stronger, \nbut give more paper!\nStrength: ",__yy_gml_errCheck(string( yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_crushing_power ))),"\nValue: "),__yy_gml_errCheck(string( yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_value )));
break;
}
case 5: {
gmldescription="Paper is getting boring, time to get a better resource.";
break;
}
case 6: {
gmldescription=yyfplus(yyfplus(yyfplus("The amount of Wood you have, increases the speed of the Press,\n but it strengthens the Wood. \nThe increase is: ",__yy_gml_errCheck(string( yyftime(__yy_gml_errCheck(_inst.gmllevel),__yy_gml_errCheck(yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_amount)) ))),"\nStrength: "),__yy_gml_errCheck(string( yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_crushing_power )));
break;
}
case 7: {
gmldescription=yyfplus(yyfplus("The paper will lose a bit of its quality, making it weaker!\nStrength: ",__yy_gml_errCheck(string( yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(0, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_crushing_power ))),"\nThe price of this upgrade scales with 'Quality Paper'\nThis upgrade does not affect the value of the paper.");
break;
}
case 8: {
gmldescription=yyfplus(yyfplus(yyfplus("Increases the quality of the Wood, causing it to become stronger, \nbut give more Wood!\nStrength: ",__yy_gml_errCheck(string( yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_crushing_power ))),"\nValue: "),__yy_gml_errCheck(string( yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(1, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_value )));
break;
}
case 9: {
gmldescription=yyfplus("Your clicks will Pressure more with this one!\nClick Strength: ",__yy_gml_errCheck(string( yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlclicking_power )));
break;
}
case 10: {
gmldescription=yyfplus(yyfplus("Upon using the Press on Paper, you might be able to take\nout some wood from it!\nChance: ",__yy_gml_errCheck(string( yyftime(__yy_gml_errCheck(_inst.gmllevel),10) ))),"%");
break;
}
case 11: {
gmldescription="You hate restocking, don't you?";
break;
}
case 12: {
gmldescription=yyfplus(yyfplus(yyfplus("Your clicks will Pressure more with this one!\nMultiplies by: ",__yy_gml_errCheck(string( yyfplus(__yy_gml_errCheck(_inst.gmllevel),1) ))),"\nClick Strength: "),__yy_gml_errCheck(string( yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlclicking_power )));
break;
}
case 13: {
gmldescription="Unlock the Restocker... whatever it is.";
break;
}
case 14: {
gmldescription="Get 1 More Wood Stock.";
break;
}
case 15: {
gmldescription="Gears... the heart of materials.";
break;
}
case 16: {
gmldescription="Adds 1 XP to Pressurize";
break;
}
case 17: {
gmldescription="Adds 2 XP to Pressurize";
break;
}
case 18: {
gmldescription=yyfplus(yyfplus("Strength = Value\nEvery 100 Strength a Material has, it gains 1 Value.\nSoftcapped at: ",__yy_gml_errCheck(string( yyftime(__yy_gml_errCheck(_inst.gmllevel),25) )))," Value.");
break;
}
case 19: {
gmldescription="Reset Auto Pressing, but all of its levels are kept in this upgrade.\nThe price of this upgrade never changes.\nThe levels are still active to the Auto Pressing.";
break;
}
case 20: {
gmldescription=yyfplus(yyfplus(yyfplus(yyfplus("Strengthen Paper by +",__yy_gml_errCheck(string( yyftime(yyftime(__yy_gml_errCheck(_inst.gmllevel),__yy_gml_errCheck(_inst.gmllevel)),125) )))," but give it a "),__yy_gml_errCheck(string( yyftime(__yy_gml_errCheck(_inst.gmllevel),5) ))),"% chance to be Polished.\nA Polished Material has double the value.");
break;
}
}
;
var gmldescriptions = string_split( gmldescription, "\n" );
var gml_length = 0;
var gml_texts_amount = array_length( gmldescriptions );
var gmli = 0 ; for (; yyfless(gmli,gml_texts_amount) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfless(gml_length,string_length( gmldescriptions[__yy_gml_array_check_index(gmli, gmldescriptions)] ))) {{
gml_length=string_length( gmldescriptions[__yy_gml_array_check_index(gmli, gmldescriptions)] );
}
;}
;
}
};
draw_set_color( 0 );
if ( yyfequal(g_pBuiltIn.get_os_browser(),(-1))) {{
var gmlm_x = window_mouse_get_x(  );
var gmlm_y = window_mouse_get_y(  );
}
;}
 else {if ( yyfnotequal(g_pBuiltIn.get_os_browser(),(-1))) {{
var gmlm_x = display_mouse_get_x(  );
var gmlm_y = display_mouse_get_y(  );
}
;}
;};
draw_rectangle( gmlm_x, gmlm_y, yyfplus(__yy_gml_errCheck(gmlm_x),__yy_gml_errCheck(yyftime(__yy_gml_errCheck(gml_length),__yy_gml_errCheck(font_get_size( YYASSET_REF(0x07000001) ))))), yyfplus(__yy_gml_errCheck(gmlm_y),__yy_gml_errCheck(yyftime(yyftime(__yy_gml_errCheck(gml_texts_amount),2),__yy_gml_errCheck(font_get_size( YYASSET_REF(0x07000001) ))))), false );
draw_set_color( 16777215 );
draw_set_font( YYASSET_REF(0x07000001) );
draw_text( gmlm_x, gmlm_y, gmldescription );
draw_set_font( YYASSET_REF(0x07000000) );
}
;}
;
}

// #####################################################################################################
// id_ = -1;
function gml_Object_o_Giver_Create_0( _inst, _other )
{
_inst.gmlid_=(-1);
}

// #####################################################################################################
// x = mouse_x; 
// y = mouse_y;
function gml_Object_o_Giver_Step_0( _inst, _other )
{
_inst.x=g_pBuiltIn.get_mouse_x();
_inst.y=g_pBuiltIn.get_mouse_y();
}

// #####################################################################################################
// if (id_ > -1) { 
// 	draw_sprite(o_Storeplace.item_database[id_].item_sprite,0,x,y) 
// }
function gml_Object_o_Giver_Draw_0( _inst, _other )
{
if ( yyfgreater(_inst.gmlid_,(-1))) {{
draw_sprite( _inst , yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(_inst.gmlid_, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_sprite, 0, _inst.x, _inst.y );
}
;}
;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 13; 
// lock = 3; 
// prestige = false;
function gml_Object_o_button_paper_13_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=13;
_inst.gmllock=3;
_inst.gmlprestige=false;
}

// #####################################################################################################
// image_xscale = 3; 
// image_yscale = 3; 
//  
// gear_slots = 4; 
//  
// gear = function(_x, _y, _id, _level, _value) constructor { 
// 	x_ = _x; 
// 	y_ = _y; 
// 	id_ = _id; 
// 	level_ = _level; 
// 	value_ = _value; 
// } 
//  
// item_amount = array_length(o_Storeplace.item_database); 
//  
// gears_in[gear_slots-1][item_amount] = -1; 
//  
// for (var i = 0; i < gear_slots; i++) { 
// 	for (var i2 = 0; i2 < item_amount; i2++) { 
// 		gears_in[i][i2] = -1; 
// 	}	 
// } 
//  
// current_item = 0; 
// amount_left = 0;
function gml_Object_o_GearSlot_Create_0( _inst, _other )
{
_inst.image_xscale=3;
_inst.image_yscale=3;
_inst.gmlgear_slots=4;
_inst.gmlgear=__yy_method( _inst, gml_Script_anon_66_gml_Object_o_GearSlot_Create_0);
_inst.gmlitem_amount=array_length( yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database );
_inst.gmlgears_in = __yy_gml_array_check( _inst.gmlgears_in, 2816678625 );
_inst.gmlgears_in[__yy_gml_array_check_index_chain(yyfminus(__yy_gml_errCheck(_inst.gmlgear_slots),1), _inst.gmlgears_in)][__yy_gml_array_check_index_set(_inst.gmlitem_amount)]=(-1);
var gmli = 0 ; for (; yyfless(gmli,_inst.gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
var gmli2 = 0 ; for (; yyfless(gmli2,_inst.gmlitem_amount) ; ( g_yyPrePostObject__ = gmli2, gmli2 = (g_yyPrePostObject__ instanceof Long ? gmli2.add(1) : ++gmli2), g_yyPrePostObject__)) {{
_inst.gmlgears_in[__yy_gml_array_check_index_chain(gmli, _inst.gmlgears_in)][__yy_gml_array_check_index_set(gmli2)]=(-1);
}
};
}
};
_inst.gmlcurrent_item=0;
_inst.gmlamount_left=0;
}
function gml_Script_anon_66_gml_Object_o_GearSlot_Create_0( _inst, _other, argument0, argument1, argument2, argument3, argument4){ 
if (_inst.__yyIsGMLObject) { _inst.__type = "gml_Script_anon@66@gml_Object_o_GearSlot_Create_0"; }
if (gml_Script_anon_66_gml_Object_o_GearSlot_Create_0.prototype.__type === undefined) { gml_Script_anon_66_gml_Object_o_GearSlot_Create_0.prototype.__type = "gml_Script_anon@66@gml_Object_o_GearSlot_Create_0"; }{ 
if (_inst.__yyIsGMLObject) Object.setPrototypeOf( _inst, gml_Script_anon_66_gml_Object_o_GearSlot_Create_0.prototype);
{
_inst.gmlx_=argument0;
_inst.gmly_=argument1;
_inst.gmlid_=argument2;
_inst.gmllevel_=argument3;
_inst.gmlvalue_=argument4;
}
}
}


// #####################################################################################################
// if (room_get_name(room) == "Room2") { 
// 	sprite_index = o_Storeplace.item_database[current_item].item_sprite; 
//  
// 	amount_left = 0; 
// 	for (var i = 0; i < o_GearSlot.gear_slots; i++) { 
// 		if (gears_in[i][o_GearSlot.current_item] == -1) { 
// 			amount_left++; 
// 		} 
// 	} 
// }
function gml_Object_o_GearSlot_Step_0( _inst, _other )
{
if ( yyfequal(room_get_name( g_pBuiltIn.get_current_room() ),"Room2")) {{
_inst.sprite_index=yyInst(_inst,_other,yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database[__yy_gml_array_check_index(_inst.gmlcurrent_item, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlitem_database)]).gmlitem_sprite;
_inst.gmlamount_left=0;
var gmli = 0 ; for (; yyfless(gmli,yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfequal(_inst.gmlgears_in[__yy_gml_array_check_index(gmli, _inst.gmlgears_in)][__yy_gml_array_check_index(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item, _inst.gmlgears_in[ ~~gmli ])],(-1))) {{
( g_yyPrePostObject__ = _inst.gmlamount_left, _inst.gmlamount_left = (g_yyPrePostObject__ instanceof Long ? _inst.gmlamount_left.add(1) : ++_inst.gmlamount_left), g_yyPrePostObject__);
}
;}
;
}
};
}
;}
;
}

// #####################################################################################################
// if (room_get_name(room) == "Room2") { 
// 	draw_set_color(c_black); 
// 	draw_set_alpha(0.5); 
// 	draw_rectangle(x-96,y-96,x+96,y+96,0) 
// 	draw_set_alpha(1); 
// 	draw_set_color(c_white); 
// 	draw_self(); 
//  
// 	draw_healthbar(x-96,y+128,x+96,y+(128+16),(amount_left/gear_slots)*100,c_black,c_red,c_lime,0,1,1); 
// }
function gml_Object_o_GearSlot_Draw_0( _inst, _other )
{
if ( yyfequal(room_get_name( g_pBuiltIn.get_current_room() ),"Room2")) {{
draw_set_color( 0 );
draw_set_alpha( 0.5 );
draw_rectangle( yyfminus(__yy_gml_errCheck(_inst.x),96), yyfminus(__yy_gml_errCheck(_inst.y),96), yyfplus(__yy_gml_errCheck(_inst.x),96), yyfplus(__yy_gml_errCheck(_inst.y),96), 0 );
draw_set_alpha( 1 );
draw_set_color( 16777215 );
draw_self( _inst  );
draw_healthbar( yyfminus(__yy_gml_errCheck(_inst.x),96), yyfplus(__yy_gml_errCheck(_inst.y),128), yyfplus(__yy_gml_errCheck(_inst.x),96), yyfplus(__yy_gml_errCheck(_inst.y),144), yyftime(__yy_gml_errCheck(yyfdivide(__yy_gml_errCheck(_inst.gmlamount_left),__yy_gml_errCheck(_inst.gmlgear_slots))),100), 0, 255, 65280, 0, 1, 1 );
}
;}
;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 10; 
// lock = 2;
function gml_Object_o_button_wood_10_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=10;
_inst.gmllock=2;
}

// #####################################################################################################
// image_angle = 180;
function gml_Object_o_GearSlotDown_Create_0( _inst, _other )
{
_inst.image_angle=180;
}

// #####################################################################################################
// if (o_GearSlot.current_item > 0) { 
// 	 
// //SAVE 
// if (instance_exists(o_Gears)) { 
// 	with (o_Gears) { 
// 		if (instance_place(x,y,o_GearSlot)) { 
// 			instance_destroy();	 
// 		} 
// 	} 
// } 
//  
// // TRANSITION 
// o_GearSlot.current_item--;	 
//  
// //LOAD 
// for (var i = 0; i < o_GearSlot.gear_slots; i++) { 
// 	if (o_GearSlot.gears_in[i][o_GearSlot.current_item] != -1) { 
// 		var g = o_GearSlot.gears_in[i][o_GearSlot.current_item]; 
// 		var t = instance_create_layer(g.x_,g.y_,"Instances_1",o_Gears); 
// 		t.level_ = g.level_; 
// 		t.value_ = g.value_; 
// 		t.id_ = g.id_; 
// 		t.count_ = i; 
// 	} 
// 	o_GearSlot.gears_in[i][o_GearSlot.current_item] = -1; 
// } 
//  
// }
function gml_Object_o_GearSlotDown_Mouse_4( _inst, _other )
{
if ( yyfgreater(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item,0)) {{
if ( yyGetBool(instance_exists( YYASSET_REF(0x00000034) ))) {{
{
var __yy__v25 = GetWithArray(YYASSET_REF(0x00000034) );
for( var __yy__v26 in __yy__v25 ) {
 if (!__yy__v25.hasOwnProperty(__yy__v26)) continue;
 var __yy__v27 = __yy__v25[__yy__v26];
{
if ( yyGetBool(instance_place( __yy__v27 , __yy__v27.x, __yy__v27.y, YYASSET_REF(0x00000026) ))) {{
instance_destroy( __yy__v27  );
}
;}
;
}
}
}
;
}
;}
;
( g_yyPrePostObject__ = yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item = (g_yyPrePostObject__ instanceof Long ? yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item.subtract(1) : --yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item), g_yyPrePostObject__);
var gmli = 0 ; for (; yyfless(gmli,yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfnotequal(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[ ~~gmli ])],(-1))) {{
var gmlg = yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[ ~~gmli ])];
var gmlt = instance_create_layer( yyInst(_inst,_other,gmlg).gmlx_, yyInst(_inst,_other,gmlg).gmly_, "Instances_1", YYASSET_REF(0x00000034) );
yyInst(_inst,_other,gmlt).gmllevel_=yyInst(_inst,_other,gmlg).gmllevel_;
yyInst(_inst,_other,gmlt).gmlvalue_=yyInst(_inst,_other,gmlg).gmlvalue_;
yyInst(_inst,_other,gmlt).gmlid_=yyInst(_inst,_other,gmlg).gmlid_;
yyInst(_inst,_other,gmlt).gmlcount_=gmli;
}
;}
;
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in = __yy_gml_array_check( yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in, 903864995 );
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index_chain(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index_set(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item)]=(-1);
}
};
}
;}
;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 17; 
// lock = 5;
function gml_Object_o_button_wood_17_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=17;
_inst.gmllock=5;
}

// #####################################################################################################
// if (o_button_paper.on == true) { 
// 	on = true;	 
// } else { 
// 	on = false;	 
// }
function gml_Object_o_button_paper_Step_2( _inst, _other )
{
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x0000002A)).gmlon,true)) {{
_inst.gmlon=true;
}
;}
 else {{
_inst.gmlon=false;
}
;};
}

// #####################################################################################################
// base_y = y; 
// dir = 0; 
// image_angle = 90;
function gml_Object_o_ArrowToSorting_Create_0( _inst, _other )
{
_inst.gmlbase_y=_inst.y;
_inst.gmldir=0;
_inst.image_angle=90;
}

// #####################################################################################################
// if (dir == 0) { 
// 	y += 0.25;	 
// } 
// if (dir == 1) { 
// 	y -= 0.25;	 
// } 
//  
// if (y < base_y-5) { 
// 	dir = 0;	 
// }  
// if (y > base_y+5) { 
// 	dir = 1;	 
// }
function gml_Object_o_ArrowToSorting_Step_0( _inst, _other )
{
if ( yyfequal(_inst.gmldir,0)) {{
_inst.y=yyfplus(_inst.y,0.25);
}
;}
;
if ( yyfequal(_inst.gmldir,1)) {{
_inst.y=yyfminus(_inst.y,0.25);
}
;}
;
if ( yyfless(_inst.y,yyfminus(__yy_gml_errCheck(_inst.gmlbase_y),5))) {{
_inst.gmldir=0;
}
;}
;
if ( yyfgreater(_inst.y,yyfplus(__yy_gml_errCheck(_inst.gmlbase_y),5))) {{
_inst.gmldir=1;
}
;}
;
}

// #####################################################################################################
// if (o_Storeplace.button_unlock[4] == true) { 
// 	room_goto(Room3); 
// } 
//  
// 
function gml_Object_o_ArrowToSorting_Mouse_4( _inst, _other )
{
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock[__yy_gml_array_check_index(4, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock)],true)) {{
room_goto( YYASSET_REF(0x03000003) );
}
;}
;
}

// #####################################################################################################
// if (o_Storeplace.button_unlock[4] == true) { 
// 	draw_self(); 
// }
function gml_Object_o_ArrowToSorting_Draw_0( _inst, _other )
{
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock[__yy_gml_array_check_index(4, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock)],true)) {{
draw_self( _inst  );
}
;}
;
}

// #####################################################################################################
// base_y = y; 
// dir = 0;
function gml_Object_o_ArrowToGearing_Create_0( _inst, _other )
{
_inst.gmlbase_y=_inst.y;
_inst.gmldir=0;
}

// #####################################################################################################
// if (dir == 0) { 
// 	y += 0.25;	 
// } 
// if (dir == 1) { 
// 	y -= 0.25;	 
// } 
//  
// if (y < base_y-5) { 
// 	dir = 0;	 
// }  
// if (y > base_y+5) { 
// 	dir = 1;	 
// }
function gml_Object_o_ArrowToGearing_Step_0( _inst, _other )
{
if ( yyfequal(_inst.gmldir,0)) {{
_inst.y=yyfplus(_inst.y,0.25);
}
;}
;
if ( yyfequal(_inst.gmldir,1)) {{
_inst.y=yyfminus(_inst.y,0.25);
}
;}
;
if ( yyfless(_inst.y,yyfminus(__yy_gml_errCheck(_inst.gmlbase_y),5))) {{
_inst.gmldir=0;
}
;}
;
if ( yyfgreater(_inst.y,yyfplus(__yy_gml_errCheck(_inst.gmlbase_y),5))) {{
_inst.gmldir=1;
}
;}
;
}

// #####################################################################################################
// if (o_Storeplace.button_unlock[5] == true) { 
// 	room_goto(Room2); 
// } 
//  
// 
function gml_Object_o_ArrowToGearing_Mouse_4( _inst, _other )
{
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock[__yy_gml_array_check_index(5, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock)],true)) {{
room_goto( YYASSET_REF(0x03000002) );
}
;}
;
}

// #####################################################################################################
// if (o_Storeplace.button_unlock[5] == true) { 
// 	draw_self();	 
// }
function gml_Object_o_ArrowToGearing_Draw_0( _inst, _other )
{
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock[__yy_gml_array_check_index(5, yyInst(_inst,_other,YYASSET_REF(0x00000000)).gmlbutton_unlock)],true)) {{
draw_self( _inst  );
}
;}
;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 8; 
// lock = 2;
function gml_Object_o_button_wood_8_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=8;
_inst.gmllock=2;
}

// #####################################################################################################
// //LOAD 
// for (var i = 0; i < o_GearSlot.gear_slots; i++) { 
// 	if (o_GearSlot.gears_in[i][o_GearSlot.current_item] != -1) { 
// 		var g = o_GearSlot.gears_in[i][o_GearSlot.current_item]; 
// 		var t = instance_create_layer(g.x_,g.y_,"Instances_1",o_Gears); 
// 		t.level_ = g.level_; 
// 		t.value_ = g.value_; 
// 		t.id_ = g.id_; 
// 		t.count_ = i; 
// 	} 
// 	o_GearSlot.gears_in[i][o_GearSlot.current_item] = -1; 
// }
function gml_Object_o_GearSlotUp_Create_0( _inst, _other )
{
var gmli = 0 ; for (; yyfless(gmli,yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfnotequal(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[ ~~gmli ])],(-1))) {{
var gmlg = yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[ ~~gmli ])];
var gmlt = instance_create_layer( yyInst(_inst,_other,gmlg).gmlx_, yyInst(_inst,_other,gmlg).gmly_, "Instances_1", YYASSET_REF(0x00000034) );
yyInst(_inst,_other,gmlt).gmllevel_=yyInst(_inst,_other,gmlg).gmllevel_;
yyInst(_inst,_other,gmlt).gmlvalue_=yyInst(_inst,_other,gmlg).gmlvalue_;
yyInst(_inst,_other,gmlt).gmlid_=yyInst(_inst,_other,gmlg).gmlid_;
yyInst(_inst,_other,gmlt).gmlcount_=gmli;
}
;}
;
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in = __yy_gml_array_check( yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in, 903864995 );
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index_chain(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index_set(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item)]=(-1);
}
};
}

// #####################################################################################################
// if (o_GearSlot.current_item+1 < o_GearSlot.item_amount) { 
// 	 
// //SAVE 
// if (instance_exists(o_Gears)) { 
// 	with (o_Gears) { 
// 		if (instance_place(x,y,o_GearSlot)) { 
// 			instance_destroy();	 
// 		} 
// 	} 
// } 
//  
// // TRANSITION 
// o_GearSlot.current_item++;	 
//  
// //LOAD 
// for (var i = 0; i < o_GearSlot.gear_slots; i++) { 
// 	if (o_GearSlot.gears_in[i][o_GearSlot.current_item] != -1) { 
// 		var g = o_GearSlot.gears_in[i][o_GearSlot.current_item]; 
// 		var t = instance_create_layer(g.x_,g.y_,"Instances_1",o_Gears); 
// 		t.level_ = g.level_; 
// 		t.value_ = g.value_; 
// 		t.id_ = g.id_; 
// 		t.count_ = i; 
// 	} 
// 	o_GearSlot.gears_in[i][o_GearSlot.current_item] = -1; 
// } 
//  
// }
function gml_Object_o_GearSlotUp_Mouse_4( _inst, _other )
{
if ( yyfless(yyfplus(__yy_gml_errCheck(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item),1),yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlitem_amount)) {{
if ( yyGetBool(instance_exists( YYASSET_REF(0x00000034) ))) {{
{
var __yy__v28 = GetWithArray(YYASSET_REF(0x00000034) );
for( var __yy__v29 in __yy__v28 ) {
 if (!__yy__v28.hasOwnProperty(__yy__v29)) continue;
 var __yy__v30 = __yy__v28[__yy__v29];
{
if ( yyGetBool(instance_place( __yy__v30 , __yy__v30.x, __yy__v30.y, YYASSET_REF(0x00000026) ))) {{
instance_destroy( __yy__v30  );
}
;}
;
}
}
}
;
}
;}
;
( g_yyPrePostObject__ = yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item = (g_yyPrePostObject__ instanceof Long ? yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item.add(1) : ++yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item), g_yyPrePostObject__);
var gmli = 0 ; for (; yyfless(gmli,yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfnotequal(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[ ~~gmli ])],(-1))) {{
var gmlg = yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[ ~~gmli ])];
var gmlt = instance_create_layer( yyInst(_inst,_other,gmlg).gmlx_, yyInst(_inst,_other,gmlg).gmly_, "Instances_1", YYASSET_REF(0x00000034) );
yyInst(_inst,_other,gmlt).gmllevel_=yyInst(_inst,_other,gmlg).gmllevel_;
yyInst(_inst,_other,gmlt).gmlvalue_=yyInst(_inst,_other,gmlg).gmlvalue_;
yyInst(_inst,_other,gmlt).gmlid_=yyInst(_inst,_other,gmlg).gmlid_;
yyInst(_inst,_other,gmlt).gmlcount_=gmli;
}
;}
;
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in = __yy_gml_array_check( yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in, 903864995 );
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index_chain(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index_set(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item)]=(-1);
}
};
}
;}
;
}

// #####################################################################################################
// event_inherited(); 
// lock = 2; 
//  
// activated_ = false;
function gml_Object_o_button_wood_menu_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmllock=2;
_inst.gmlactivated_=false;
}

// #####################################################################################################
// image_xscale = 0.5; 
// image_yscale = 0.5;
function gml_Object_o_button_wood_menu_Step_2( _inst, _other )
{
_inst.image_xscale=0.5;
_inst.image_yscale=0.5;
}

// #####################################################################################################
// if (unlock == true) { 
// 	switch(activated_) { 
// 		case true: 
// 			activated_ = false; 
// 			o_button_wood.on = false; 
// 		break; 
// 		case false: 
// 			activated_ = true; 
// 			o_button_wood.on = true; 
// 		break; 
// 	} 
//  
// 	if (o_button_auto_menu.activated_ == true) { 
// 		o_button_auto_menu.activated_ = false; 
// 		o_button_auto.on = false; 
// 	} 
// 	if (o_button_paper_menu.activated_ == true) { 
// 		o_button_paper_menu.activated_ = false; 
// 		o_button_paper.on = false; 
// 	} 
// }
function gml_Object_o_button_wood_menu_Mouse_4( _inst, _other )
{
if ( yyfequal(_inst.gmlunlock,true)) {{
var ___sw34___ = _inst.gmlactivated_; 
var ___swc35___ = -1;
if (yyCompareVal(___sw34___,true,g_GMLMathEpsilon, false)==0) {
___swc35___ = 0;
}
else if (yyCompareVal(___sw34___,false,g_GMLMathEpsilon, false)==0) {
___swc35___ = 1;
}
switch( ___swc35___ ) {
case 0: {
_inst.gmlactivated_=false;
yyInst(_inst,_other,YYASSET_REF(0x00000010)).gmlon=false;
break;
}
case 1: {
_inst.gmlactivated_=true;
yyInst(_inst,_other,YYASSET_REF(0x00000010)).gmlon=true;
break;
}
}
;
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000018)).gmlactivated_,true)) {{
yyInst(_inst,_other,YYASSET_REF(0x00000018)).gmlactivated_=false;
yyInst(_inst,_other,YYASSET_REF(0x0000001A)).gmlon=false;
}
;}
;
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x0000000A)).gmlactivated_,true)) {{
yyInst(_inst,_other,YYASSET_REF(0x0000000A)).gmlactivated_=false;
yyInst(_inst,_other,YYASSET_REF(0x0000002A)).gmlon=false;
}
;}
;
}
;}
;
}

// #####################################################################################################
// if (activated_ == true) { 
// 	draw_set_color(c_black); 
// 	draw_rectangle(0,0,room_width,room_height,false); 
// 	draw_set_color(c_white); 
// } 
//  
// if (unlock == true) { 
// 	draw_self(); 
// 	var i = 0.75; 
// 	draw_sprite_ext(spr_wood,false,x+(32*i*image_xscale)+4,y+(32*i*image_yscale)+4,i*image_xscale,i*image_xscale,0,c_white,1) 
// }
function gml_Object_o_button_wood_menu_Draw_0( _inst, _other )
{
if ( yyfequal(_inst.gmlactivated_,true)) {{
draw_set_color( 0 );
draw_rectangle( 0, 0, g_pBuiltIn.room_width, g_pBuiltIn.room_height, false );
draw_set_color( 16777215 );
}
;}
;
if ( yyfequal(_inst.gmlunlock,true)) {{
draw_self( _inst  );
var gmli = 0.75;
draw_sprite_ext( _inst , YYASSET_REF(0x01000004), false, yyfplus(yyfplus(__yy_gml_errCheck(_inst.x),__yy_gml_errCheck(yyftime(yyftime(32,__yy_gml_errCheck(gmli)),__yy_gml_errCheck(_inst.image_xscale)))),4), yyfplus(yyfplus(__yy_gml_errCheck(_inst.y),__yy_gml_errCheck(yyftime(yyftime(32,__yy_gml_errCheck(gmli)),__yy_gml_errCheck(_inst.image_yscale)))),4), yyftime(__yy_gml_errCheck(gmli),__yy_gml_errCheck(_inst.image_xscale)), yyftime(__yy_gml_errCheck(gmli),__yy_gml_errCheck(_inst.image_xscale)), 0, 16777215, 1 );
}
;}
;
}

// #####################################################################################################
// event_inherited(); 
// id_ = 11; 
// lock = 2; 
// prestige = false;
function gml_Object_o_button_auto_11_Create_0( _inst, _other )
{
event_inherited( _inst , _other  );
_inst.gmlid_=11;
_inst.gmllock=2;
_inst.gmlprestige=false;
}

// #####################################################################################################
// held_ = false; 
// spd = 5; 
// on = true;
function gml_Object_o_Throwables_Create_0( _inst, _other )
{
_inst.gmlheld_=false;
_inst.gmlspd=5;
_inst.gmlon=true;
}

// #####################################################################################################
// var i = true; 
// if (instance_place(x,y+spd,o_Throwables)) { 
// 	if (instance_place(x,y+spd,o_Throwables).on == true) { 
// 		i = false;	 
// 	} 
// } 
// if (y+spd+16 < room_height && i == true && held_ == false) { 
// 	spd += 0.25; 
// } else { 
// 	spd = 0;	 
// } 
//  
// if (held_ == true) { 
// 	x = mouse_x; 
// 	y = mouse_y; 
// }
function gml_Object_o_Throwables_Step_0( _inst, _other )
{
var gmli = true;
if ( yyGetBool(instance_place( _inst , _inst.x, yyfplus(__yy_gml_errCheck(_inst.y),__yy_gml_errCheck(_inst.gmlspd)), YYASSET_REF(0x00000032) ))) {{
if ( yyfequal(yyInst(_inst,_other,instance_place( _inst , _inst.x, yyfplus(__yy_gml_errCheck(_inst.y),__yy_gml_errCheck(_inst.gmlspd)), YYASSET_REF(0x00000032) )).gmlon,true)) {{
gmli=false;
}
;}
;
}
;}
;
if ( (yyGetBool(yyfless(yyfplus(yyfplus(__yy_gml_errCheck(_inst.y),__yy_gml_errCheck(_inst.gmlspd)),16),g_pBuiltIn.room_height))) && (yyGetBool(yyfequal(gmli,true))) && (yyGetBool(yyfequal(_inst.gmlheld_,false)))) {{
_inst.gmlspd=yyfplus(_inst.gmlspd,0.25);
}
;}
 else {{
_inst.gmlspd=0;
}
;};
if ( yyfequal(_inst.gmlheld_,true)) {{
_inst.x=g_pBuiltIn.get_mouse_x();
_inst.y=g_pBuiltIn.get_mouse_y();
}
;}
;
}

// #####################################################################################################
// switch (held_) { 
// 	case true: 
// 		held_ = false; 
// 	break; 
// 	case false: 
// 		held_ = true; 
// 	break; 
// } 
//  
// if (instance_place(x,y,o_Throwables)) { 
// 	var i = instance_place(x,y,o_Throwables); 
// 	if (i.held_ == true) { 
// 		i.held_ = false; 
// 		i.x -= 10; 
// 	} 
// }
function gml_Object_o_Throwables_Mouse_4( _inst, _other )
{
var ___sw38___ = _inst.gmlheld_; 
var ___swc39___ = -1;
if (yyCompareVal(___sw38___,true,g_GMLMathEpsilon, false)==0) {
___swc39___ = 0;
}
else if (yyCompareVal(___sw38___,false,g_GMLMathEpsilon, false)==0) {
___swc39___ = 1;
}
switch( ___swc39___ ) {
case 0: {
_inst.gmlheld_=false;
break;
}
case 1: {
_inst.gmlheld_=true;
break;
}
}
;
if ( yyGetBool(instance_place( _inst , _inst.x, _inst.y, YYASSET_REF(0x00000032) ))) {{
var gmli = instance_place( _inst , _inst.x, _inst.y, YYASSET_REF(0x00000032) );
if ( yyfequal(yyInst(_inst,_other,gmli).gmlheld_,true)) {{
yyInst(_inst,_other,gmli).gmlheld_=false;
yyInst(_inst,_other,gmli).x=yyfminus(yyInst(_inst,_other,gmli).x,10);
}
;}
;
}
;}
;
}

// #####################################################################################################
// id_ = 0 
// level_ = 0 
// value_ = 0; 
//  
// min_value_ = 0; 
// max_value_ = 0; 
// range_ = 0; 
//  
// countdown_do = false; 
// countdown = 60; 
// 
// // Inherit the parent event
// event_inherited();
// 
// 
function gml_Object_o_GearSystem_Create_0( _inst, _other )
{
_inst.gmlid_=0;
_inst.gmllevel_=0;
_inst.gmlvalue_=0;
_inst.gmlmin_value_=0;
_inst.gmlmax_value_=0;
_inst.gmlrange_=0;
_inst.gmlcountdown_do=false;
_inst.gmlcountdown=60;
event_inherited( _inst , _other  );
}

// #####################################################################################################
// // Inherit the parent event
// event_inherited();
// 
// if (countdown > 0 && countdown_do == true) { 
// 	countdown--;	 
// }
function gml_Object_o_GearSystem_Step_0( _inst, _other )
{
event_inherited( _inst , _other  );
if ( (yyGetBool(yyfgreater(_inst.gmlcountdown,0))) && (yyGetBool(yyfequal(_inst.gmlcountdown_do,true)))) {{
( g_yyPrePostObject__ = _inst.gmlcountdown, _inst.gmlcountdown = (g_yyPrePostObject__ instanceof Long ? _inst.gmlcountdown.subtract(1) : --_inst.gmlcountdown), g_yyPrePostObject__);
}
;}
;
}

// #####################################################################################################
// countdown_do = true;
function gml_Object_o_GearSystem_Mouse_10( _inst, _other )
{
_inst.gmlcountdown_do=true;
}

// #####################################################################################################
// countdown_do = false; 
// countdown = 60;
function gml_Object_o_GearSystem_Mouse_11( _inst, _other )
{
_inst.gmlcountdown_do=false;
_inst.gmlcountdown=60;
}

// #####################################################################################################
// if (countdown == 0) { 
// 	var description = "ERROR"; 
// 	switch(id_) { 
// 		case 0: 
// 			description = "ERRORRRRRRRRRRRRRRRRRRR\nUNO\nDOS\nTRES"; 
// 		break; 
// 		case 1: 
// 			description = "Strength Gear [" + string(level_) + "]\nBuffs the Strength of the Resource by: " + string(value_); 
// 		break; 
// 		case 2: 
// 			description = "Critical Gear [" + string(level_) + "]\nBuffs Critical Clicking Chance by: " + string(value_); 
// 		break; 
// 		case 3: 
// 			description = "Clicking Gear [" + string(level_) + "]\nBuffs Clicking Strength by: " + string(value_); 
// 		break; 
// 		case 4: 
// 			description = "Gear of Value [" + string(level_) + "]\nBuffs the Value of the Material by: " + string(value_); 
// 		break; 
// 	} 
//  
// 	var descriptions = string_split(description,"\n") 
//  
// 	var _length = 0; 
// 	var _texts_amount = array_length(descriptions) 
//  
// 	for (var i = 0; i < _texts_amount; i++) { 
// 		if (_length < string_length(descriptions[i])) { 
// 			_length = string_length(descriptions[i]); 
// 		} 
// 	} 
// 	 
// 	draw_set_color(c_black); 
// 	var m_x = window_mouse_get_x(); 
// 	var m_y = window_mouse_get_y(); 
// 	draw_rectangle(m_x,m_y,m_x+_length*font_get_size(font2),m_y+_texts_amount*2*font_get_size(font2), false) 
// 	draw_set_color(c_white); 
// 	draw_set_font(font2); 
// 	draw_text(m_x,m_y,description); 
// 	draw_set_font(font1); 
// }
function gml_Object_o_GearSystem_Draw_64( _inst, _other )
{
if ( yyfequal(_inst.gmlcountdown,0)) {{
var gmldescription = "ERROR";
var ___sw42___ = _inst.gmlid_; 
var ___swc43___ = -1;
if (yyCompareVal(___sw42___,0,g_GMLMathEpsilon, false)==0) {
___swc43___ = 0;
}
else if (yyCompareVal(___sw42___,1,g_GMLMathEpsilon, false)==0) {
___swc43___ = 1;
}
else if (yyCompareVal(___sw42___,2,g_GMLMathEpsilon, false)==0) {
___swc43___ = 2;
}
else if (yyCompareVal(___sw42___,3,g_GMLMathEpsilon, false)==0) {
___swc43___ = 3;
}
else if (yyCompareVal(___sw42___,4,g_GMLMathEpsilon, false)==0) {
___swc43___ = 4;
}
switch( ___swc43___ ) {
case 0: {
gmldescription="ERRORRRRRRRRRRRRRRRRRRR\nUNO\nDOS\nTRES";
break;
}
case 1: {
gmldescription=yyfplus(yyfplus(yyfplus("Strength Gear [",__yy_gml_errCheck(string( _inst.gmllevel_ ))),"]\nBuffs the Strength of the Resource by: "),__yy_gml_errCheck(string( _inst.gmlvalue_ )));
break;
}
case 2: {
gmldescription=yyfplus(yyfplus(yyfplus("Critical Gear [",__yy_gml_errCheck(string( _inst.gmllevel_ ))),"]\nBuffs Critical Clicking Chance by: "),__yy_gml_errCheck(string( _inst.gmlvalue_ )));
break;
}
case 3: {
gmldescription=yyfplus(yyfplus(yyfplus("Clicking Gear [",__yy_gml_errCheck(string( _inst.gmllevel_ ))),"]\nBuffs Clicking Strength by: "),__yy_gml_errCheck(string( _inst.gmlvalue_ )));
break;
}
case 4: {
gmldescription=yyfplus(yyfplus(yyfplus("Gear of Value [",__yy_gml_errCheck(string( _inst.gmllevel_ ))),"]\nBuffs the Value of the Material by: "),__yy_gml_errCheck(string( _inst.gmlvalue_ )));
break;
}
}
;
var gmldescriptions = string_split( gmldescription, "\n" );
var gml_length = 0;
var gml_texts_amount = array_length( gmldescriptions );
var gmli = 0 ; for (; yyfless(gmli,gml_texts_amount) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfless(gml_length,string_length( gmldescriptions[__yy_gml_array_check_index(gmli, gmldescriptions)] ))) {{
gml_length=string_length( gmldescriptions[__yy_gml_array_check_index(gmli, gmldescriptions)] );
}
;}
;
}
};
draw_set_color( 0 );
var gmlm_x = window_mouse_get_x(  );
var gmlm_y = window_mouse_get_y(  );
draw_rectangle( gmlm_x, gmlm_y, yyfplus(__yy_gml_errCheck(gmlm_x),__yy_gml_errCheck(yyftime(__yy_gml_errCheck(gml_length),__yy_gml_errCheck(font_get_size( YYASSET_REF(0x07000001) ))))), yyfplus(__yy_gml_errCheck(gmlm_y),__yy_gml_errCheck(yyftime(yyftime(__yy_gml_errCheck(gml_texts_amount),2),__yy_gml_errCheck(font_get_size( YYASSET_REF(0x07000001) ))))), false );
draw_set_color( 16777215 );
draw_set_font( YYASSET_REF(0x07000001) );
draw_text( gmlm_x, gmlm_y, gmldescription );
draw_set_font( YYASSET_REF(0x07000000) );
}
;}
;
}

// #####################################################################################################
// count_ = -1; 
// 
// // Inherit the parent event
// event_inherited();
// 
// image_xscale = 0.75; 
// image_yscale = 0.75; 
//  
// alarm_set(0,60);
function gml_Object_o_Gears_Create_0( _inst, _other )
{
_inst.gmlcount_=(-1);
event_inherited( _inst , _other  );
_inst.image_xscale=0.75;
_inst.image_yscale=0.75;
alarm_set( _inst , 0, 60 );
}

// #####################################################################################################
// switch(id_) { 
// 	case 1: 
// 		min_value_ = level_/5; 
// 		max_value_ = min_value_*2*floor(level_/10); 
// 	break; 
// 	case 2: 
// 		min_value_ = level_/5; 
// 		max_value_ = min_value_+(level_/9); 
// 	break; 
// 	case 3: 
// 		min_value_ = level_/5; 
// 		max_value_ = min_value_*level_; 
// 	break; 
// 	case 4: 
// 		min_value_ = level_/20; 
// 		max_value_ = min_value_*floor(level_/10); 
// 	break; 
// } 
//  
// value_ = (1-range_)*min_value_+(range_*max_value_); 
// alarm_set(0,60); 
//  
//  
// 
function gml_Object_o_Gears_Alarm_0( _inst, _other )
{
var ___sw46___ = _inst.gmlid_; 
var ___swc47___ = -1;
if (yyCompareVal(___sw46___,1,g_GMLMathEpsilon, false)==0) {
___swc47___ = 0;
}
else if (yyCompareVal(___sw46___,2,g_GMLMathEpsilon, false)==0) {
___swc47___ = 1;
}
else if (yyCompareVal(___sw46___,3,g_GMLMathEpsilon, false)==0) {
___swc47___ = 2;
}
else if (yyCompareVal(___sw46___,4,g_GMLMathEpsilon, false)==0) {
___swc47___ = 3;
}
switch( ___swc47___ ) {
case 0: {
_inst.gmlmin_value_=yyfdivide(__yy_gml_errCheck(_inst.gmllevel_),5);
_inst.gmlmax_value_=yyftime(yyftime(__yy_gml_errCheck(_inst.gmlmin_value_),2),__yy_gml_errCheck(floor( yyfdivide(__yy_gml_errCheck(_inst.gmllevel_),10) )));
break;
}
case 1: {
_inst.gmlmin_value_=yyfdivide(__yy_gml_errCheck(_inst.gmllevel_),5);
_inst.gmlmax_value_=yyfplus(__yy_gml_errCheck(_inst.gmlmin_value_),__yy_gml_errCheck(yyfdivide(__yy_gml_errCheck(_inst.gmllevel_),9)));
break;
}
case 2: {
_inst.gmlmin_value_=yyfdivide(__yy_gml_errCheck(_inst.gmllevel_),5);
_inst.gmlmax_value_=yyftime(__yy_gml_errCheck(_inst.gmlmin_value_),__yy_gml_errCheck(_inst.gmllevel_));
break;
}
case 3: {
_inst.gmlmin_value_=yyfdivide(__yy_gml_errCheck(_inst.gmllevel_),20);
_inst.gmlmax_value_=yyftime(__yy_gml_errCheck(_inst.gmlmin_value_),__yy_gml_errCheck(floor( yyfdivide(__yy_gml_errCheck(_inst.gmllevel_),10) )));
break;
}
}
;
_inst.gmlvalue_=yyfplus(__yy_gml_errCheck(yyftime(__yy_gml_errCheck(yyfminus(1,__yy_gml_errCheck(_inst.gmlrange_))),__yy_gml_errCheck(_inst.gmlmin_value_))),__yy_gml_errCheck(yyftime(__yy_gml_errCheck(_inst.gmlrange_),__yy_gml_errCheck(_inst.gmlmax_value_))));
alarm_set( _inst , 0, 60 );
}

// #####################################################################################################
// // Inherit the parent event
// event_inherited(); 
// 
// //PUTTING GEARS INTO GEAR SLOTS 
// if (instance_place(x,y,o_GearSlot) && held_ == false) { 
// 	if (count_ > -1) { 
// 		spd = 0; 
// 		o_GearSlot.gears_in[count_][o_GearSlot.current_item] = new o_GearSlot.gear(x,y,id_,level_,value_); 
// 		image_angle++; 
// 		on = false; 
// 	} else { 
// 		for (var i = 0; i < o_GearSlot.gear_slots; i++) { 
// 			if (o_GearSlot.gears_in[i][o_GearSlot.current_item] == -1) { 
// 				count_ = i; 
// 				break; 
// 			} 
// 		} 
// 	} 
// // PUTTING GEARS INTO THE STORAGE 
// } else if (instance_place(x,y,o_GearStorage) && held_ == false) { 
// 	if (count_ > -1) { 
// 		spd = 0; 
// 		o_GearStorage.gears_in[count_] = new o_GearStorage.gear(x,y,id_,level_,value_); 
// 		image_angle += 0.25; 
// 		on = false; 
// 	} else { 
// 		for (var i = 0; i < o_GearStorage.gear_slots; i++) { 
// 			if (o_GearStorage.gears_in[i] == -1) { 
// 				count_ = i; 
// 				break; 
// 			} 
// 		} 
// 	} 
// // SCRAPPING GEARS 
// } else if (instance_place(x,y,o_ScrapBin) && held_ == false) { 
// 	instance_destroy(); 
// 	global.xp_ += level_/10; 
// } else { 
// 	count_ = -1; 
// 	image_angle = 0; 
// 	on = true; 
// } 
//  
// y += spd; // MAKING THEM FALL
function gml_Object_o_Gears_Step_0( _inst, _other )
{
event_inherited( _inst , _other  );
if ( (yyGetBool(instance_place( _inst , _inst.x, _inst.y, YYASSET_REF(0x00000026) ))) && (yyGetBool(yyfequal(_inst.gmlheld_,false)))) {{
if ( yyfgreater(_inst.gmlcount_,(-1))) {{
_inst.gmlspd=0;
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in = __yy_gml_array_check( yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in, 903864995 );
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index_chain(_inst.gmlcount_, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index_set(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item)]=__yy_gml_object_create( _inst, __yyg_call_method((yythis2=yyInst(_inst,_other,YYASSET_REF(0x00000026)), yythis2).gmlgear),_inst.x,_inst.y,_inst.gmlid_,_inst.gmllevel_,_inst.gmlvalue_);
var yythis2;
( g_yyPrePostObject__ = _inst.image_angle, _inst.image_angle = (g_yyPrePostObject__ instanceof Long ? _inst.image_angle.add(1) : ++_inst.image_angle), g_yyPrePostObject__);
_inst.gmlon=false;
}
;}
 else {{
var gmli = 0 ; for (; yyfless(gmli,yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[ ~~gmli ])],(-1))) {{
_inst.gmlcount_=gmli;
break;
}
;}
;
}
};
}
;};
}
;}
 else {if ( (yyGetBool(instance_place( _inst , _inst.x, _inst.y, YYASSET_REF(0x00000020) ))) && (yyGetBool(yyfequal(_inst.gmlheld_,false)))) {{
if ( yyfgreater(_inst.gmlcount_,(-1))) {{
_inst.gmlspd=0;
yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in = __yy_gml_array_check( yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in, 3164448915 );
yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in[__yy_gml_array_check_index_set(_inst.gmlcount_)]=__yy_gml_object_create( _inst, __yyg_call_method((yythis3=yyInst(_inst,_other,YYASSET_REF(0x00000020)), yythis3).gmlgear),_inst.x,_inst.y,_inst.gmlid_,_inst.gmllevel_,_inst.gmlvalue_);
var yythis3;
_inst.image_angle=yyfplus(_inst.image_angle,0.25);
_inst.gmlon=false;
}
;}
 else {{
var gmli = 0 ; for (; yyfless(gmli,yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgear_slots) ; ( g_yyPrePostObject__ = gmli, gmli = (g_yyPrePostObject__ instanceof Long ? gmli.add(1) : ++gmli), g_yyPrePostObject__)) {{
if ( yyfequal(yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in[__yy_gml_array_check_index(gmli, yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in)],(-1))) {{
_inst.gmlcount_=gmli;
break;
}
;}
;
}
};
}
;};
}
;}
 else {if ( (yyGetBool(instance_place( _inst , _inst.x, _inst.y, YYASSET_REF(0x00000022) ))) && (yyGetBool(yyfequal(_inst.gmlheld_,false)))) {{
instance_destroy( _inst  );
global.gmlxp_=yyfplus(global.gmlxp_,yyfdivide(__yy_gml_errCheck(_inst.gmllevel_),10));
}
;}
 else {{
_inst.gmlcount_=(-1);
_inst.image_angle=0;
_inst.gmlon=true;
}
;};};};
_inst.y=yyfplus(_inst.y,_inst.gmlspd);
}

// #####################################################################################################
// // Inherit the parent event
// event_inherited();
// 
// if (instance_place(x,y,o_GearSlot) && count_ != -1) { 
// 	o_GearSlot.gears_in[count_][o_GearSlot.current_item] = -1; 
// } 
//  
// if (instance_place(x,y,o_GearStorage) && count_ != -1) { 
// 	o_GearStorage.gears_in[count_] = -1; 
// } 
// 
function gml_Object_o_Gears_Mouse_4( _inst, _other )
{
event_inherited( _inst , _other  );
if ( (yyGetBool(instance_place( _inst , _inst.x, _inst.y, YYASSET_REF(0x00000026) ))) && (yyGetBool(yyfnotequal(_inst.gmlcount_,(-1))))) {{
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in = __yy_gml_array_check( yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in, 903864995 );
yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in[__yy_gml_array_check_index_chain(_inst.gmlcount_, yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlgears_in)][__yy_gml_array_check_index_set(yyInst(_inst,_other,YYASSET_REF(0x00000026)).gmlcurrent_item)]=(-1);
}
;}
;
if ( (yyGetBool(instance_place( _inst , _inst.x, _inst.y, YYASSET_REF(0x00000020) ))) && (yyGetBool(yyfnotequal(_inst.gmlcount_,(-1))))) {{
yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in = __yy_gml_array_check( yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in, 3164448915 );
yyInst(_inst,_other,YYASSET_REF(0x00000020)).gmlgears_in[__yy_gml_array_check_index_set(_inst.gmlcount_)]=(-1);
}
;}
;
}

// #####################################################################################################
// id_ = 1;
function gml_RoomCC_Room3_1_Create( _inst, _other )
{
_inst.gmlid_=1;
}

// #####################################################################################################
// id_ = 2;
function gml_RoomCC_Room3_2_Create( _inst, _other )
{
_inst.gmlid_=2;
}

// #####################################################################################################
// id_ = 3;
function gml_RoomCC_Room3_3_Create( _inst, _other )
{
_inst.gmlid_=3;
}

// #####################################################################################################
// id_ = 4;
function gml_RoomCC_Room3_4_Create( _inst, _other )
{
_inst.gmlid_=4;
}

// #####################################################################################################
// id_ = 5;
function gml_RoomCC_Room3_5_Create( _inst, _other )
{
_inst.gmlid_=5;
}

// #####################################################################################################
// id_ = 6;
function gml_RoomCC_Room3_6_Create( _inst, _other )
{
_inst.gmlid_=6;
}

// #####################################################################################################
// id_ = 7;
function gml_RoomCC_Room3_7_Create( _inst, _other )
{
_inst.gmlid_=7;
}

// #####################################################################################################
// id_ = 8;
function gml_RoomCC_Room3_8_Create( _inst, _other )
{
_inst.gmlid_=8;
}

// #####################################################################################################
// id_ = 9;
function gml_RoomCC_Room3_9_Create( _inst, _other )
{
_inst.gmlid_=9;
}

// #####################################################################################################
// id_ = 10;
function gml_RoomCC_Room3_10_Create( _inst, _other )
{
_inst.gmlid_=10;
}

// #####################################################################################################
// id_ = 0;
function gml_RoomCC_Room3_11_Create( _inst, _other )
{
_inst.gmlid_=0;
}

// #####################################################################################################
// id_ = 1;
function gml_RoomCC_Room3_12_Create( _inst, _other )
{
_inst.gmlid_=1;
}
function compile_if_weak_ref() {}
function compile_if_used() {}
function gmlInitGlobal() {
global.__yyIsGMLObject = true;

gml_GlobalScript_Script_Gears( global, global );
gml_GlobalScript_Script_Storeplace( global, global );
gml_GlobalScript_Script_Button( global, global );
compile_if_weak_ref(move_random, move_random.__yy_onlySelfNoOther = true);
compile_if_weak_ref(place_free, place_free.__yy_onlySelfNoOther = true);
compile_if_weak_ref(place_empty, place_empty.__yy_onlySelfNoOther = true);
compile_if_weak_ref(place_meeting, place_meeting.__yy_onlySelfNoOther = true);
compile_if_weak_ref(place_snapped, place_snapped.__yy_onlySelfNoOther = true);
compile_if_weak_ref(move_snap, move_snap.__yy_onlySelfNoOther = true);
compile_if_weak_ref(move_towards_point, move_towards_point.__yy_onlySelfNoOther = true);
compile_if_weak_ref(move_contact_solid, move_contact_solid.__yy_onlySelfNoOther = true);
compile_if_weak_ref(move_contact_all, move_contact_all.__yy_onlySelfNoOther = true);
compile_if_weak_ref(move_outside_solid, move_outside_solid.__yy_onlySelfNoOther = true);
compile_if_weak_ref(move_outside_all, move_outside_all.__yy_onlySelfNoOther = true);
compile_if_weak_ref(move_and_collide, move_and_collide.__yy_onlySelfNoOther = true);
compile_if_weak_ref(move_bounce_solid, move_bounce_solid.__yy_onlySelfNoOther = true);
compile_if_weak_ref(move_bounce_all, move_bounce_all.__yy_onlySelfNoOther = true);
compile_if_weak_ref(move_wrap, move_wrap.__yy_onlySelfNoOther = true);
compile_if_weak_ref(motion_set, motion_set.__yy_onlySelfNoOther = true);
compile_if_weak_ref(motion_add, motion_add.__yy_onlySelfNoOther = true);
compile_if_weak_ref(distance_to_point, distance_to_point.__yy_onlySelfNoOther = true);
compile_if_weak_ref(distance_to_object, distance_to_object.__yy_onlySelfNoOther = true);
compile_if_weak_ref(path_start, path_start.__yy_onlySelfNoOther = true);
compile_if_weak_ref(path_end, path_end.__yy_onlySelfNoOther = true);
compile_if_weak_ref(mp_linear_step, mp_linear_step.__yy_onlySelfNoOther = true);
compile_if_weak_ref(mp_linear_path, mp_linear_path.__yy_onlySelfNoOther = true);
compile_if_weak_ref(mp_linear_step_object, mp_linear_step_object.__yy_onlySelfNoOther = true);
compile_if_weak_ref(mp_linear_path_object, mp_linear_path_object.__yy_onlySelfNoOther = true);
compile_if_weak_ref(mp_potential_settings, mp_potential_settings.__yy_onlySelfNoOther = true);
compile_if_weak_ref(mp_potential_step, mp_potential_step.__yy_onlySelfNoOther = true);
compile_if_weak_ref(mp_potential_path, mp_potential_path.__yy_onlySelfNoOther = true);
compile_if_weak_ref(mp_potential_step_object, mp_potential_step_object.__yy_onlySelfNoOther = true);
compile_if_weak_ref(mp_potential_path_object, mp_potential_path_object.__yy_onlySelfNoOther = true);
compile_if_weak_ref(mp_grid_add_instances, mp_grid_add_instances.__yy_onlySelfNoOther = true);
compile_if_weak_ref(mp_grid_path, mp_grid_path.__yy_onlySelfNoOther = true);
compile_if_weak_ref(collision_point, collision_point.__yy_onlySelfNoOther = true);
compile_if_weak_ref(collision_point_list, collision_point_list.__yy_onlySelfNoOther = true);
compile_if_weak_ref(collision_rectangle, collision_rectangle.__yy_onlySelfNoOther = true);
compile_if_weak_ref(collision_rectangle_list, collision_rectangle_list.__yy_onlySelfNoOther = true);
compile_if_weak_ref(collision_circle, collision_circle.__yy_onlySelfNoOther = true);
compile_if_weak_ref(collision_circle_list, collision_circle_list.__yy_onlySelfNoOther = true);
compile_if_weak_ref(collision_ellipse, collision_ellipse.__yy_onlySelfNoOther = true);
compile_if_weak_ref(collision_ellipse_list, collision_ellipse_list.__yy_onlySelfNoOther = true);
compile_if_weak_ref(collision_line, collision_line.__yy_onlySelfNoOther = true);
compile_if_weak_ref(collision_line_list, collision_line_list.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_nearest, instance_nearest.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_furthest, instance_furthest.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_place, instance_place.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_place_list, instance_place_list.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_copy, instance_copy.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_change, instance_change.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_destroy, instance_destroy.__yy_onlySelfNoOther = true);
compile_if_weak_ref(position_empty, position_empty.__yy_onlySelfNoOther = true);
compile_if_weak_ref(position_meeting, position_meeting.__yy_onlySelfNoOther = true);
compile_if_weak_ref(position_destroy, position_destroy.__yy_onlySelfNoOther = true);
compile_if_weak_ref(position_change, position_change.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_id_get, instance_id_get.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_deactivate_all, instance_deactivate_all.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_deactivate_object, instance_deactivate_object.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_deactivate_region, instance_deactivate_region.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_deactivate_layer, instance_deactivate_layer.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_activate_all, instance_activate_all.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_activate_object, instance_activate_object.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_activate_region, instance_activate_region.__yy_onlySelfNoOther = true);
compile_if_weak_ref(instance_activate_layer, instance_activate_layer.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_self, draw_self.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_sprite, draw_sprite.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_sprite_pos, draw_sprite_pos.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_sprite_ext, draw_sprite_ext.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_sprite_stretched, draw_sprite_stretched.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_sprite_stretched_ext, draw_sprite_stretched_ext.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_sprite_part, draw_sprite_part.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_sprite_part_ext, draw_sprite_part_ext.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_sprite_general, draw_sprite_general.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_sprite_tiled, draw_sprite_tiled.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_sprite_tiled_ext, draw_sprite_tiled_ext.__yy_onlySelfNoOther = true);
compile_if_weak_ref(event_inherited, event_inherited.__yy_bothSelfAndOther = true);
compile_if_weak_ref(event_perform, event_perform.__yy_bothSelfAndOther = true);
compile_if_weak_ref(event_perform_async, event_perform_async.__yy_bothSelfAndOther = true);
compile_if_weak_ref(event_user, event_user.__yy_bothSelfAndOther = true);
compile_if_weak_ref(event_perform_object, event_perform_object.__yy_bothSelfAndOther = true);
compile_if_weak_ref(alarm_get, alarm_get.__yy_onlySelfNoOther = true);
compile_if_weak_ref(alarm_set, alarm_set.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_fixture_bind, physics_fixture_bind.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_fixture_bind_ext, physics_fixture_bind_ext.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_apply_force, physics_apply_force.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_apply_impulse, physics_apply_impulse.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_apply_angular_impulse, physics_apply_angular_impulse.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_apply_local_force, physics_apply_local_force.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_apply_local_impulse, physics_apply_local_impulse.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_apply_torque, physics_apply_torque.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_mass_properties, physics_mass_properties.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_draw_debug, physics_draw_debug.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_test_overlap, physics_test_overlap.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_get_friction, physics_get_friction.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_get_density, physics_get_density.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_get_restitution, physics_get_restitution.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_set_friction, physics_set_friction.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_set_density, physics_set_density.__yy_onlySelfNoOther = true);
compile_if_weak_ref(physics_set_restitution, physics_set_restitution.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_set, skeleton_animation_set.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_get, skeleton_animation_get.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_mix, skeleton_animation_mix.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_set_ext, skeleton_animation_set_ext.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_get_ext, skeleton_animation_get_ext.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_get_duration, skeleton_animation_get_duration.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_get_frames, skeleton_animation_get_frames.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_clear, skeleton_animation_clear.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_skin_set, skeleton_skin_set.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_skin_get, skeleton_skin_get.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_skin_create, skeleton_skin_create.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_attachment_set, skeleton_attachment_set.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_attachment_get, skeleton_attachment_get.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_attachment_create, skeleton_attachment_create.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_attachment_create_colour, skeleton_attachment_create_colour.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_attachment_create_color, skeleton_attachment_create_color.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_attachment_replace, skeleton_attachment_replace.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_attachment_replace_colour, skeleton_attachment_replace_colour.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_attachment_replace_color, skeleton_attachment_replace_color.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_attachment_destroy, skeleton_attachment_destroy.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_attachment_exists, skeleton_attachment_exists.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_collision_draw_set, skeleton_collision_draw_set.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_bone_data_get, skeleton_bone_data_get.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_bone_data_set, skeleton_bone_data_set.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_bone_state_get, skeleton_bone_state_get.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_bone_state_set, skeleton_bone_state_set.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_slot_data_instance, skeleton_slot_data_instance.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_slot_colour_set, skeleton_slot_colour_set.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_slot_color_set, skeleton_slot_color_set.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_slot_colour_get, skeleton_slot_colour_get.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_slot_color_get, skeleton_slot_color_get.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_slot_alpha_get, skeleton_slot_alpha_get.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_get_frame, skeleton_animation_get_frame.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_set_frame, skeleton_animation_set_frame.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_is_looping, skeleton_animation_is_looping.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_is_finished, skeleton_animation_is_finished.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_get_position, skeleton_animation_get_position.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_set_position, skeleton_animation_set_position.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_animation_get_event_frames, skeleton_animation_get_event_frames.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_get_minmax, skeleton_get_minmax.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_get_num_bounds, skeleton_get_num_bounds.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_get_bounds, skeleton_get_bounds.__yy_onlySelfNoOther = true);
compile_if_weak_ref(skeleton_find_slot, skeleton_find_slot.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_tilemap, draw_tilemap.__yy_onlySelfNoOther = true);
compile_if_weak_ref(draw_tile, draw_tile.__yy_onlySelfNoOther = true);
}
function gmlGameEndScripts() {
}
	Tags = [  ];
	IDToTagList = [
	];
JSON_game.ScriptNames = [
"gml_GlobalScript_Script_Gears", 
"gml_Script_gear_activate", 
"gml_GlobalScript_Script_Storeplace", 
"gml_Script_load", 
"gml_Script_find_button", 
"gml_GlobalScript_Script_Button", 
"gml_Script_check_cost", 
"gml_Script_unlock_button", 
"gml_Script_anon@148@gml_Object_o_Storeplace_Create_0", 
"gml_Script____struct___0@gml_Object_o_Storeplace_Other_3", 
"gml_Script____struct___1@gml_Object_o_Storeplace_Other_3", 
"gml_Script____struct___2@gml_Object_o_Storeplace_Other_3", 
"gml_Script_anon@28@gml_Object_o_GearStorage_Create_0", 
"gml_Script_anon@66@gml_Object_o_GearSlot_Create_0"	];
JSON_game.Scripts = [
gml_GlobalScript_Script_Gears, 
gml_Script_gear_activate, 
gml_GlobalScript_Script_Storeplace, 
gml_Script_load, 
gml_Script_find_button, 
gml_GlobalScript_Script_Button, 
gml_Script_check_cost, 
gml_Script_unlock_button, 
gml_Script_anon_148_gml_Object_o_Storeplace_Create_0, 
gml_Script____struct___0_gml_Object_o_Storeplace_Other_3, 
gml_Script____struct___1_gml_Object_o_Storeplace_Other_3, 
gml_Script____struct___2_gml_Object_o_Storeplace_Other_3, 
gml_Script_anon_28_gml_Object_o_GearStorage_Create_0, 
gml_Script_anon_66_gml_Object_o_GearSlot_Create_0	];
const kgml_GlobalScript_Script_Gears = 100000;
const kgml_Script_gear_activate = 100001;
const kgml_GlobalScript_Script_Storeplace = 100002;
const kgml_Script_load = 100003;
const kgml_Script_find_button = 100004;
const kgml_GlobalScript_Script_Button = 100005;
const kgml_Script_check_cost = 100006;
const kgml_Script_unlock_button = 100007;
const kgml_Script_anon_148_gml_Object_o_Storeplace_Create_0 = 100008;
const kgml_Script____struct___0_gml_Object_o_Storeplace_Other_3 = 100009;
const kgml_Script____struct___1_gml_Object_o_Storeplace_Other_3 = 100010;
const kgml_Script____struct___2_gml_Object_o_Storeplace_Other_3 = 100011;
const kgml_Script_anon_28_gml_Object_o_GearStorage_Create_0 = 100012;
const kgml_Script_anon_66_gml_Object_o_GearSlot_Create_0 = 100013;
gml_Script_anon_148_gml_Object_o_Storeplace_Create_0.__yyg__is_constructor = true;
gml_Script____struct___0_gml_Object_o_Storeplace_Other_3.__yyg__is_constructor = true;
gml_Script____struct___1_gml_Object_o_Storeplace_Other_3.__yyg__is_constructor = true;
gml_Script____struct___2_gml_Object_o_Storeplace_Other_3.__yyg__is_constructor = true;
gml_Script_anon_28_gml_Object_o_GearStorage_Create_0.__yyg__is_constructor = true;
gml_Script_anon_66_gml_Object_o_GearSlot_Create_0.__yyg__is_constructor = true;
var g_instance_names={"x": [true, true, true, null, null],"y": [true, true, true, null, null],"xprevious": [true, true, true, null, null],"yprevious": [true, true, true, null, null],"xstart": [true, true, true, null, null],"ystart": [true, true, true, null, null],"hspeed": [true, true, true, null, null],"vspeed": [true, true, true, null, null],"direction": [true, true, true, null, null],"speed": [true, true, true, null, null],"friction": [true, true, true, null, null],"gravity": [true, true, true, null, null],"gravity_direction": [true, true, true, null, null],"in_collision_tree": [true, false, true, null, null],"object_index": [true, false, false, "GetObjectIndex", null],"id": [true, false, false, null, null],"alarm": [true, true, true, null, null],"solid": [true, true, true, null, null],"visible": [true, true, true, null, null],"persistent": [true, true, true, null, null],"managed": [true, false, true, null, null],"depth": [true, true, true, null, null],"bbox_left": [true, false, false, null, null],"bbox_right": [true, false, false, null, null],"bbox_top": [true, false, false, null, null],"bbox_bottom": [true, false, false, null, null],"sprite_index": [true, true, true, null, null],"image_index": [true, true, true, null, null],"image_single": [true, true, true, null, null],"image_number": [true, false, false, null, null],"sprite_width": [true, false, false, null, null],"sprite_height": [true, false, false, null, null],"sprite_xoffset": [true, false, false, null, null],"sprite_yoffset": [true, false, false, null, null],"image_xscale": [true, true, true, null, null],"image_yscale": [true, true, true, null, null],"image_angle": [true, true, true, null, null],"image_alpha": [true, true, true, null, null],"image_blend": [true, true, true, null, null],"image_speed": [true, true, true, null, null],"mask_index": [true, true, true, null, null],"path_index": [true, false, false, null, null],"path_position": [true, true, true, null, null],"path_positionprevious": [true, true, true, null, null],"path_speed": [true, true, true, null, null],"path_scale": [true, true, true, null, null],"path_orientation": [true, true, true, null, null],"path_endaction": [true, true, true, null, null],"timeline_index": [true, true, true, null, null],"timeline_position": [true, true, true, null, null],"timeline_speed": [true, true, true, null, null],"timeline_running": [true, true, true, null, null],"timeline_loop": [true, true, true, null, null],"phy_rotation": [true, true, true, null, null],"phy_position_x": [true, true, true, null, null],"phy_position_y": [true, true, true, null, null],"phy_angular_velocity": [true, true, true, null, null],"phy_linear_velocity_x": [true, true, true, null, null],"phy_linear_velocity_y": [true, true, true, null, null],"phy_speed_x": [true, true, true, null, null],"phy_speed_y": [true, true, true, null, null],"phy_speed": [true, false, true, null, null],"phy_angular_damping": [true, true, true, null, null],"phy_linear_damping": [true, true, true, null, null],"phy_bullet": [true, true, true, null, null],"phy_fixed_rotation": [true, true, true, null, null],"phy_active": [true, true, true, null, null],"phy_mass": [true, false, true, null, null],"phy_inertia": [true, false, true, null, null],"phy_com_x": [true, false, true, null, null],"phy_com_y": [true, false, true, null, null],"phy_dynamic": [true, false, true, null, null],"phy_kinematic": [true, false, true, null, null],"phy_sleeping": [true, false, true, null, null],"phy_position_xprevious": [true, true, true, null, null],"phy_position_yprevious": [true, true, true, null, null],"phy_collision_points": [true, false, true, null, null],"layer": [true, true, true, null, null],"in_sequence": [true, false, true, null, null],"sequence_instance": [true, false, true, null, null],"drawn_by_sequence": [true, false, true, null, null],"phy_collision_x": [true, false, true, null, null],"phy_collision_y": [true, false, true, null, null],"phy_col_normal_x": [true, false, true, null, null],"phy_col_normal_y": [true, false, true, null, null]};
var g_global_names={"argument_relative": [true, false, false, "get_argument_relative", null],"argument_count": [true, false, false, null, null],"argument": [true, true, true, null, null],"argument0": [true, true, true, null, null],"argument1": [true, true, true, null, null],"argument2": [true, true, true, null, null],"argument3": [true, true, true, null, null],"argument4": [true, true, true, null, null],"argument5": [true, true, true, null, null],"argument6": [true, true, true, null, null],"argument7": [true, true, true, null, null],"argument8": [true, true, true, null, null],"argument9": [true, true, true, null, null],"argument10": [true, true, true, null, null],"argument11": [true, true, true, null, null],"argument12": [true, true, true, null, null],"argument13": [true, true, true, null, null],"argument14": [true, true, true, null, null],"argument15": [true, true, true, null, null],"debug_mode": [true, false, true, null, null],"pointer_invalid": [true, false, false, null, null],"pointer_null": [true, false, false, null, null],"undefined": [true, false, false, null, null],"NaN": [true, false, false, null, null],"infinity": [true, false, false, null, null],"room": [true, true, true, "get_current_room", "set_current_room"],"room_first": [true, false, false, null, null],"room_last": [true, false, false, null, null],"transition_kind": [true, true, true, null, null],"transition_steps": [true, true, true, null, null],"score": [true, true, true, null, null],"lives": [true, true, true, null, "set_lives_function"],"health": [true, true, true, null, "set_health_function"],"game_id": [true, false, false, null, null],"game_display_name": [true, false, true, null, null],"game_project_name": [true, false, true, null, null],"game_save_id": [true, false, true, null, null],"working_directory": [true, false, false, null, null],"temp_directory": [true, false, false, null, null],"cache_directory": [true, false, false, null, null],"program_directory": [true, false, false, null, null],"instance_count": [true, false, false, "get_instance_count", null],"instance_id": [true, false, false, null, null],"room_width": [true, true, false, null, "set_room_width"],"room_height": [true, true, false, null, "set_room_height"],"room_caption": [true, true, true, null, "set_room_caption"],"room_speed": [true, true, true, "get_room_speed", "set_room_speed"],"room_persistent": [true, true, true, null, "set_room_persistent"],"background_color": [true, true, true, "getbackground_color", "setbackground_color"],"background_showcolor": [true, true, true, "getbackground_showcolor", "setbackground_showcolor"],"background_colour": [true, true, true, "getbackground_color", "setbackground_color"],"background_showcolour": [true, true, true, "getbackground_showcolor", "setbackground_showcolor"],"view_enabled": [true, true, true, "get_view_enable", "set_view_enable"],"view_current": [true, false, false, null, null],"view_visible": [true, true, true, null, null],"mouse_x": [true, false, false, "get_mouse_x", null],"mouse_y": [true, false, false, "get_mouse_y", null],"mouse_button": [true, true, true, null, null],"mouse_lastbutton": [true, true, true, null, null],"keyboard_key": [true, true, true, null, null],"keyboard_lastkey": [true, true, true, null, null],"keyboard_lastchar": [true, true, true, null, null],"keyboard_string": [true, true, true, null, null],"show_score": [true, true, true, null, null],"show_lives": [true, true, true, null, null],"show_health": [true, true, true, null, null],"caption_score": [true, true, true, null, null],"caption_lives": [true, true, true, null, null],"caption_health": [true, true, true, null, null],"fps": [true, false, false, null, null],"fps_real": [true, false, false, null, null],"current_time": [true, false, false, "get_current_time", null],"current_year": [true, false, false, "get_current_year", null],"current_month": [true, false, false, "get_current_month", null],"current_day": [true, false, false, "get_current_day", null],"current_weekday": [true, false, false, "get_current_weekday", null],"current_hour": [true, false, false, "get_current_hour", null],"current_minute": [true, false, false, "get_current_minute", null],"current_second": [true, false, false, "get_current_second", null],"event_type": [true, false, false, "get_current_event_type", null],"event_number": [true, false, false, "get_current_event_number", null],"event_object": [true, false, false, "get_current_event_object", null],"event_action": [true, false, false, null, null],"error_occurred": [true, true, true, null, null],"error_last": [true, true, true, null, null],"gamemaker_registered": [true, false, false, null, null],"gamemaker_pro": [true, false, false, null, null],"application_surface": [true, false, false, null, null],"font_texture_page_size": [true, true, false, null, null],"os_type": [true, false, false, "get_os_type", null],"os_device": [true, false, false, "get_os_device", null],"os_browser": [true, false, false, "get_os_browser", null],"os_version": [true, false, false, "get_os_version", null],"browser_width": [true, false, false, "get_browser_width", null],"browser_height": [true, false, false, "get_browser_height", null],"async_load": [true, false, false, "get_async_load", null],"event_data": [true, false, false, "get_event_data", null],"display_aa": [true, false, false, "get_display_aa", null],"iap_data": [true, false, false, "get_iap_data", null],"cursor_sprite": [true, true, false, "get_cursor_sprite", "set_cursor_sprite"],"delta_time": [true, true, false, "get_delta_time", null],"webgl_enabled": [true, false, false, null, null],"audio_bus_main": [true, true, true, null, null],"rollback_current_frame": [true, false, false, null, null],"rollback_confirmed_frame": [true, false, false, null, null],"rollback_event_id": [true, false, false, null, null],"rollback_event_param": [true, false, false, null, null],"rollback_game_running": [true, false, false, null, null],"rollback_api_server": [true, false, false, null, null],"wallpaper_config": [true, false, false, null, null],"wallpaper_subscription_data": [true, false, false, null, null],"view_xview": [true, true, true, null, null],"view_yview": [true, true, true, null, null],"view_wview": [true, true, true, null, null],"view_hview": [true, true, true, null, null],"view_angle": [true, true, true, null, null],"view_hborder": [true, true, true, null, null],"view_vborder": [true, true, true, null, null],"view_hspeed": [true, true, true, null, null],"view_vspeed": [true, true, true, null, null],"view_object": [true, true, true, null, null],"view_xport": [true, true, true, null, null],"view_yport": [true, true, true, null, null],"view_wport": [true, true, true, null, null],"view_hport": [true, true, true, null, null],"view_surface_id": [true, true, true, null, null],"view_camera": [true, true, true, null, null],"marked": [false, false, false, null, null],"active": [false, false, false, null, null]};
